'use strict';

const WS_URL = 'wss://www.kcex.com/fapi/edge';
const DEALS_URL = 'https://www.kcex.com/fapi/v1/contract/deals/';
const PING_MS = 10000;
const sessions = new Map();

function toKcexSymbol(tvSymbol) {
  if (typeof tvSymbol !== 'string') return null;
  let s = tvSymbol.trim().toUpperCase();
  s = s.replace(/^KCEX:/, '').replace(/\.P$/, '').replace(/\.PERP$/, '');
  s = s.replace(/[^A-Z0-9_]/g, '');
  if (!s) return null;
  if (s.includes('_')) return s;
  if (s.endsWith('USDT') && s.length > 4) return s.slice(0, -4) + '_USDT';
  return null;
}

function sendToTab(tabId, message) {
  chrome.tabs.sendMessage(tabId, message).catch(() => {});
}

function setBadge(tabId, text, color = '#2e9d66') {
  chrome.action.setBadgeText({ tabId, text }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ tabId, color }).catch(() => {});
}

function stopSession(tabId, reason = 'stopped') {
  const session = sessions.get(tabId);
  if (!session) return;
  session.stopped = true;
  clearInterval(session.pingTimer);
  clearTimeout(session.reconnectTimer);
  try {
    if (session.ws && session.ws.readyState <= WebSocket.OPEN) {
      session.ws.close(1000, reason.slice(0, 120));
    }
  } catch (_) {}
  sessions.delete(tabId);
  setBadge(tabId, '');
  sendToTab(tabId, { type: 'TVE_FEED_STATE', state: 'stopped', reason });
}

async function loadRecentDeals(tabId, symbol, session) {
  try {
    const url = DEALS_URL + encodeURIComponent(symbol) + '?__tve_internal=1';
    const response = await fetch(url, {
      method: 'GET',
      credentials: 'omit',
      cache: 'no-store',
      referrerPolicy: 'no-referrer'
    });
    if (!response.ok) throw new Error('HTTP ' + response.status);
    const json = await response.json();
    if (!json || json.success !== true || !Array.isArray(json.data)) {
      throw new Error('Unexpected deals response shape');
    }
    if (sessions.get(tabId) !== session || session.stopped) return;
    const trades = json.data.map(normalizeDeal).filter(Boolean);
    sendToTab(tabId, {
      type: 'TVE_HISTORY',
      symbol,
      trades,
      receivedAt: Date.now(),
      count: trades.length
    });
    session.historyCount = trades.length;
    sendToTab(tabId, {
      type: 'TVE_FEED_STATE',
      state: 'history-loaded',
      symbol,
      count: trades.length
    });
  } catch (error) {
    session.historyError = String(error && error.message || error);
    sendToTab(tabId, {
      type: 'TVE_FEED_STATE',
      state: 'history-error',
      symbol,
      error: session.historyError
    });
  }
}

function normalizeDeal(d) {
  if (!d || typeof d !== 'object') return null;
  const price = Number(d.p);
  const volume = Number(d.v);
  const timestamp = Number(d.t);
  if (!Number.isFinite(price) || price <= 0 ||
      !Number.isFinite(volume) || volume < 0 ||
      !Number.isFinite(timestamp) || timestamp < 1e11) return null;
  return {
    price,
    volume,
    timestamp,
    tradeType: d.T ?? null,
    orderType: d.O ?? null,
    makerFlag: d.M ?? null
  };
}

function openSession(tabId, tvSymbol, intervalSeconds) {
  const symbol = toKcexSymbol(tvSymbol);
  if (!symbol) {
    sendToTab(tabId, {
      type: 'TVE_FEED_STATE',
      state: 'symbol-error',
      error: 'نماد TradingView قابل تبدیل به KCEX نیست: ' + String(tvSymbol)
    });
    return;
  }
  stopSession(tabId, 'symbol or interval changed');
  const session = {
    tabId,
    tvSymbol,
    symbol,
    intervalSeconds,
    stopped: false,
    ws: null,
    pingTimer: null,
    reconnectTimer: null,
    reconnectDelay: 1000,
    receivedTrades: 0,
    historyCount: 0,
    openedAt: null
  };
  sessions.set(tabId, session);
  sendToTab(tabId, { type: 'TVE_FEED_STATE', state: 'connecting', symbol, intervalSeconds });
  loadRecentDeals(tabId, symbol, session);
  connectSession(session);
}

function connectSession(session) {
  if (session.stopped || sessions.get(session.tabId) !== session) return;
  let ws;
  try {
    ws = new WebSocket(WS_URL);
    session.ws = ws;
  } catch (error) {
    handleSocketFailure(session, 'creation', error);
    return;
  }
  ws.onopen = () => {
    if (session.stopped || sessions.get(session.tabId) !== session) {
      try { ws.close(); } catch (_) {}
      return;
    }
    session.openedAt = Date.now();
    session.reconnectDelay = 1000;
    try {
      ws.send(JSON.stringify({
        method: 'sub.deal',
        param: { symbol: session.symbol, compress: true }
      }));
    } catch (error) {
      handleSocketFailure(session, 'subscribe', error);
      return;
    }
    session.pingTimer = setInterval(() => {
      if (session.stopped || ws.readyState !== WebSocket.OPEN) return;
      try { ws.send(JSON.stringify({ method: 'ping' })); } catch (_) {}
    }, PING_MS);
    setBadge(session.tabId, 'ON');
    sendToTab(session.tabId, {
      type: 'TVE_FEED_STATE',
      state: 'connected',
      symbol: session.symbol,
      intervalSeconds: session.intervalSeconds
    });
  };
  ws.onmessage = event => {
    if (session.stopped || sessions.get(session.tabId) !== session) return;
    if (typeof event.data !== 'string') return;
    let message;
    try { message = JSON.parse(event.data); } catch (_) { return; }
    const channel = String(message.channel || '');
    if (channel === 'rs.sub.deal') {
      sendToTab(session.tabId, {
        type: 'TVE_FEED_STATE',
        state: message.data === 'success' ? 'subscribed' : 'subscription-response',
        symbol: session.symbol,
        response: message.data
      });
      return;
    }
    if (channel === 'pong') return;
    if (channel !== 'push.deal' || message.symbol !== session.symbol) return;
    const list = Array.isArray(message.data) ? message.data : [message.data];
    for (const row of list) {
      const trade = normalizeDeal(row);
      if (!trade) continue;
      session.receivedTrades++;
      sendToTab(session.tabId, {
        type: 'TVE_TRADE',
        symbol: session.symbol,
        trade,
        receivedAt: Date.now()
      });
    }
  };
  ws.onerror = () => {
    sendToTab(session.tabId, {
      type: 'TVE_FEED_STATE',
      state: 'socket-error',
      symbol: session.symbol,
      message: 'WebSocket error; the browser does not expose handshake details.'
    });
  };
  ws.onclose = event => {
    clearInterval(session.pingTimer);
    session.pingTimer = null;
    if (session.stopped || sessions.get(session.tabId) !== session) return;
    sendToTab(session.tabId, {
      type: 'TVE_FEED_STATE',
      state: 'reconnecting',
      symbol: session.symbol,
      closeCode: event.code,
      closeReason: event.reason || ''
    });
    scheduleReconnect(session);
  };
}

function handleSocketFailure(session, stage, error) {
  sendToTab(session.tabId, {
    type: 'TVE_FEED_STATE',
    state: 'socket-error',
    stage,
    error: String(error && error.message || error)
  });
  scheduleReconnect(session);
}

function scheduleReconnect(session) {
  if (session.stopped || sessions.get(session.tabId) !== session) return;
  clearTimeout(session.reconnectTimer);
  const delay = Math.min(20000, session.reconnectDelay);
  session.reconnectDelay = Math.min(20000, Math.round(delay * 1.8));
  session.reconnectTimer = setTimeout(() => connectSession(session), delay);
}

async function ensureMainWorldBridge(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      files: ['page-bridge.js']
    });
    sendToTab(tabId, { type: 'TVE_BRIDGE_INJECTED' });
  } catch (error) {
    sendToTab(tabId, {
      type: 'TVE_FEED_STATE',
      state: 'bridge-error',
      error: String(error && error.message || error)
    });
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender && sender.tab && sender.tab.id;
  if (message?.type === 'TVE_BOOTSTRAP' && Number.isInteger(tabId)) {
    ensureMainWorldBridge(tabId);
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === 'TVE_START_FEED' && Number.isInteger(tabId)) {
    openSession(tabId, message.tvSymbol, Number(message.intervalSeconds) || 1);
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === 'TVE_STOP_FEED' && Number.isInteger(tabId)) {
    stopSession(tabId, 'user stopped feed');
    sendResponse({ ok: true });
    return false;
  }
  if (message?.type === 'TVE_POPUP_STATUS') {
    const tab = sender?.tab;
    const session = tab?.id != null ? sessions.get(tab.id) : null;
    sendResponse({
      ok: true,
      connected: !!session?.ws && session.ws.readyState === WebSocket.OPEN,
      symbol: session?.symbol || null,
      trades: session?.receivedTrades || 0,
      history: session?.historyCount || 0
    });
    return false;
  }
  return false;
});

chrome.tabs.onRemoved.addListener(tabId => stopSession(tabId, 'tab closed'));
