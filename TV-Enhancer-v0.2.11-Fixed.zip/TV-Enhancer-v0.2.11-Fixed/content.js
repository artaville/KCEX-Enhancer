(() => {
  'use strict';
  if (window.__TV_ENHANCER_CONTENT_V0211__) return;
  window.__TV_ENHANCER_CONTENT_V0211__ = true;
  const CHANNEL = 'TV_ENHANCER_BRIDGE_V0211';
  const INTERVALS = [1, 5, 10, 15, 20, 30, 45];
  let toolbar = null;
  let statusEl = null;
  let statsEl = null;
  let selectedSeconds = 5;
  let currentTvSymbol = null;
  let bridgeReady = false;
  let feedStarted = false;
  let currentFeedState = 'idle';
  let continuousOpen = true;
  let applied = false;
  let chartLockedForReload = false;
  let intervalSelectionPending = false;
  let realCandleCount = 0;
  let totalCandleCount = 0;
  let applyButton = null;
  let resolutionBadge = null;

  function sendBridge(type, detail = {}) {
    window.postMessage({ channel: CHANNEL, from: 'content', type, detail }, '*');
  }
  function sendRuntime(message) {
    try {
      return chrome.runtime.sendMessage(message).catch(() => null);
    } catch (_) { return Promise.resolve(null); }
  }
  function detectSymbolFromPage() {
    const canvas = document.querySelector('canvas[aria-label^="Chart for "]');
    const label = canvas?.getAttribute('aria-label') || '';
    const m = label.match(/Chart for\s+([^,]+)/i);
    if (m) return m[1].trim();
    const ticker = document.querySelector('[data-name="legend-source-title"]');
    const text = ticker?.textContent?.trim();
    if (text && /:/.test(text)) return text;
    return null;
  }
  function setStatus(text, state = '') {
    if (!statusEl) return;
    statusEl.textContent = text;
    statusEl.dataset.state = state;
  }
  function setStats(text) {
    if (statsEl) statsEl.textContent = text;
  }
  function createButton(label, className, title, onClick) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = className;
    b.textContent = label;
    b.title = title || label;
    b.addEventListener('click', onClick);
    return b;
  }
  function placeToolbar() {
    if (!toolbar || !document.body) return;
    if (toolbar.parentElement !== document.body) {
      document.body.appendChild(toolbar);
    }
    toolbar.classList.remove('tve-inline');
    toolbar.classList.add('tve-floating');
  }
  function refreshApplyAvailability() {
    if (!applyButton) return;
    const safetyBlocked = chartLockedForReload || applied || !bridgeReady;
    applyButton.disabled = safetyBlocked || intervalSelectionPending || realCandleCount < 20;
    applyButton.title = safetyBlocked
      ? 'برای تغییر مجدد، صفحه TradingView را Reload کنید'
      : intervalSelectionPending
        ? 'در حال دریافت معاملات...'
        : realCandleCount < 20
          ? `برای Apply حداقل ۲۰ کندل واقعی لازم است (فعلی: ${realCandleCount})`
          : 'اعمال کندل‌های ثانیه‌ای روی چارت اصلی TradingView';
  }
  function updateActiveButtons() {
    if (!toolbar) return;
    toolbar.querySelectorAll('[data-tve-seconds]').forEach(button => {
      button.classList.toggle('tve-active', Number(button.dataset.tveSeconds) === selectedSeconds);
      button.disabled = chartLockedForReload;
    });
  }
  async function startInterval(seconds) {
    if (applied || chartLockedForReload) {
      setStatus('نیاز به Reload صفحه', 'error');
      return;
    }
    selectedSeconds = seconds;
    intervalSelectionPending = true;
    refreshApplyAvailability();
    updateActiveButtons();
    const symbol = detectSymbolFromPage() || currentTvSymbol;
    currentTvSymbol = symbol;
    if (!symbol) {
      intervalSelectionPending = false;
      refreshApplyAvailability();
      setStatus('نماد پیدا نشد', 'error');
      sendBridge('TVE_DISCOVER');
      return;
    }
    sendBridge('TVE_SELECT_INTERVAL', { seconds });
    setStatus('اتصال به KCEX...', 'connecting');
    setStats('در حال بارگذاری معاملات...');
    feedStarted = true;
    await sendRuntime({ type: 'TVE_START_FEED', tvSymbol: symbol, intervalSeconds: seconds });
  }
  function buildToolbar() {
    if (toolbar && toolbar.isConnected) return;
    toolbar = document.createElement('div');
    toolbar.id = 'tve-toolbar';
    toolbar.setAttribute('role', 'group');
    toolbar.setAttribute('aria-label', 'TV Enhancer seconds timeframes');
    const brand = document.createElement('span');
    brand.className = 'tve-brand';
    const logo = document.createElement('img');
    logo.src = chrome.runtime.getURL('icons/icon32.png');
    logo.alt = 'TV Enhancer';
    logo.addEventListener('error', () => { logo.style.display = 'none'; }, { once: true });
    brand.appendChild(logo);
    const brandText = document.createElement('span');
    brandText.textContent = 'TVE';
    brand.appendChild(brandText);
    toolbar.appendChild(brand);

    const group = document.createElement('div');
    group.className = 'tve-intervals';
    for (const seconds of INTERVALS) {
      const button = createButton(
        seconds + 's',
        'tve-interval',
        'دریافت معاملات KCEX با تایم‌فریم ' + seconds + ' ثانیه',
        () => startInterval(seconds)
      );
      button.dataset.tveSeconds = String(seconds);
      group.appendChild(button);
    }
    toolbar.appendChild(group);

    applyButton = createButton(
      'Apply',
      'tve-apply',
      'اعمال روی چارت TradingView',
      () => {
        if (chartLockedForReload || applied) {
          setStatus('نیاز به Reload صفحه', 'error');
          return;
        }
        if (realCandleCount < 20) {
          setStatus('کندل واقعی کافی نیست', 'error');
          return;
        }
        setStatus('در حال اعمال...', 'connecting');
        applyButton.disabled = true;
        sendBridge('TVE_APPLY');
      }
    );
    applyButton.disabled = true;
    toolbar.appendChild(applyButton);

    const restore = createButton(
      'Reload',
      'tve-restore',
      'بازگردانی چارت اصلی TradingView با Reload',
      () => {
        location.reload();
      }
    );
    toolbar.appendChild(restore);

    resolutionBadge = document.createElement('span');
    resolutionBadge.className = 'tve-resolution';
    resolutionBadge.textContent = 'TV: --';
    toolbar.appendChild(resolutionBadge);

    statusEl = document.createElement('span');
    statusEl.className = 'tve-status';
    statusEl.textContent = 'آماده';
    toolbar.appendChild(statusEl);

    statsEl = document.createElement('span');
    statsEl.className = 'tve-stats';
    statsEl.textContent = '';
    toolbar.appendChild(statsEl);

    placeToolbar();
    updateActiveButtons();
    refreshApplyAvailability();
  }
  function setChartLockedForReload() {
    chartLockedForReload = true;
    if (applyButton) applyButton.disabled = true;
    if (toolbar) {
      toolbar.querySelectorAll('[data-tve-seconds]').forEach(button => { button.disabled = true; });
    }
  }
  function onBridgeMessage(message) {
    const d = message.detail || {};
    switch (message.type) {
      case 'TVE_CONTEXT':
        bridgeReady = !!d.found;
        if (d.tvSymbol) currentTvSymbol = d.tvSymbol;
        if (resolutionBadge && d.found) {
          resolutionBadge.textContent = 'TV: ' + (d.interval || '--');
          resolutionBadge.title = 'SeriesSource: ' + (d.sourceResolution || '--');
        }
        if (d.reloadRequired) setChartLockedForReload();
        refreshApplyAvailability();
        if (!d.found) setStatus('چارت یافت نشد', 'error');
        else if (chartLockedForReload) setStatus('نیاز به Reload', 'error');
        else setStatus('آماده', 'ready');
        break;
      case 'TVE_BRIDGE_STATE': {
        currentFeedState = d.feedState || currentFeedState;
        applied = !!d.applied;
        if (d.reloadRequired || d.chartLockedForReload || d.mainChartMutated) setChartLockedForReload();
        const c = d.candles || {};
        if (Number(c.intervalSeconds) === selectedSeconds) intervalSelectionPending = false;
        realCandleCount = Number(c.real || 0);
        totalCandleCount = Number(c.total || 0);
        refreshApplyAvailability();
        if (resolutionBadge && d.appliedResolution && d.applied) {
          resolutionBadge.textContent = 'TVE: ' + d.appliedResolution;
        } else if (resolutionBadge && d.actualResolution) {
          resolutionBadge.textContent = 'TV: ' + d.actualResolution;
        }
        const statusText = d.applied
          ? 'فعال (' + (d.appliedResolution || '') + ')'
          : chartLockedForReload
            ? 'نیاز به Reload'
            : currentFeedState === 'subscribed' || currentFeedState === 'connected'
              ? 'متصل به KCEX'
              : currentFeedState === 'history-loaded'
                ? 'تاریخچه آماده'
                : currentFeedState === 'connecting'
                  ? 'در حال اتصال...'
                  : currentFeedState === 'socket-error' || currentFeedState === 'history-error'
                    ? 'خطای فید'
                    : bridgeReady ? 'آماده' : 'در انتظار چارت';
        setStatus(statusText, d.applied ? 'applied' : chartLockedForReload ? 'error' : currentFeedState);
        setStats(
          (d.tradeCount ?? 0) + ' معامله · ' +
          realCandleCount + ' واقعی · ' +
          totalCandleCount + ' کل'
        );
        break;
      }
      case 'TVE_APPLY_RESULT':
        if (d.success) {
          applied = true;
          setChartLockedForReload();
          if (applyButton) applyButton.disabled = true;
          if (resolutionBadge) {
            resolutionBadge.textContent = 'TVE: ' + (d.sourceResolution || '--');
            resolutionBadge.title = 'MainSeries: ' + (d.seriesInterval || '1') + ' / Source: ' + (d.sourceResolution || '--');
          }
          setStatus('اعمال شد (' + (d.sourceResolution || '') + ')', 'applied');
          setStats(
            'کندل‌ها: ' + d.barStoreCount +
            ' · آخرین زمان: ' + d.timeScaleLastPoint
          );
        } else {
          setStatus('خطا در اعمال', 'error');
          setStats(String(d.message || '').slice(0, 220));
          if (d.reloadRequired || d.chartLockedForReload) setChartLockedForReload();
          refreshApplyAvailability();
        }
        break;
      case 'TVE_APPLY_ERROR':
      case 'TVE_BRIDGE_ERROR':
        setStatus(d.reloadRequired ? 'نیاز به Reload' : 'خطا', 'error');
        setStats(String(d.message || '').slice(0, 220));
        if (d.reloadRequired) {
          applied = true;
          setChartLockedForReload();
          if (applyButton) applyButton.disabled = true;
        }
        break;
      case 'TVE_LIVE_UPDATE':
        break;
      case 'TVE_RELOAD_REQUIRED':
        if (d.reloadRequired) setChartLockedForReload();
        setStatus(d.reloadRequired ? 'نیاز به Reload' : 'آماده', d.reloadRequired ? 'error' : 'ready');
        break;
    }
  }
  window.addEventListener('message', event => {
    if (event.source !== window || !event.data || event.data.channel !== CHANNEL || event.data.from !== 'page') return;
    onBridgeMessage(event.data);
  });
  chrome.runtime.onMessage.addListener(message => {
    if (!message || !message.type) return;
    if (message.type === 'TVE_BRIDGE_INJECTED') {
      sendBridge('TVE_DISCOVER');
      return;
    }
    if (message.type === 'TVE_HISTORY') {
      sendBridge('TVE_HISTORY', { trades: message.trades || [] });
      setStatus('تاریخچه KCEX دریافت شد', 'ready');
      return;
    }
    if (message.type === 'TVE_TRADE') {
      sendBridge('TVE_TRADE', { trade: message.trade });
      return;
    }
    if (message.type === 'TVE_FEED_STATE') {
      currentFeedState = message.state || currentFeedState;
      sendBridge('TVE_FEED_STATE', { ...message });
      if (message.state === 'socket-error' || message.state === 'history-error' || message.state === 'symbol-error') {
        setStatus('خطای KCEX', 'error');
        setStats(String(message.error || message.message || 'خطا').slice(0, 220));
      } else if (message.state === 'subscribed') {
        setStatus('فید زنده KCEX فعال', 'connected');
      } else if (message.state === 'reconnecting') {
        setStatus('اتصال مجدد...', 'connecting');
      }
      return;
    }
  });
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'TVE_POPUP_CONTINUOUS') {
      continuousOpen = !!message.enabled;
      sendBridge('TVE_SET_CONTINUOUS', { enabled: continuousOpen });
      sendResponse({ ok: true });
      return false;
    }
    if (message?.type === 'TVE_POPUP_GET_STATE') {
      sendBridge('TVE_GET_STATE');
      sendResponse({ ok: true, symbol: currentTvSymbol, feedState: currentFeedState, feedStarted, bridgeReady });
      return false;
    }
    return false;
  });
  async function init() {
    try {
      const settings = await chrome.storage.local.get({ continuousOpen: true });
      continuousOpen = settings.continuousOpen !== false;
    } catch (_) {}
    buildToolbar();
    sendRuntime({ type: 'TVE_BOOTSTRAP' });
    sendBridge('TVE_DISCOVER');
    sendBridge('TVE_SET_CONTINUOUS', { enabled: continuousOpen });
    const observer = new MutationObserver(() => {
      if (!toolbar || !toolbar.isConnected) buildToolbar();
      else placeToolbar();
      const detected = detectSymbolFromPage();
      if (detected && currentTvSymbol && detected !== currentTvSymbol) {
        const wasFeedStarted = feedStarted;
        feedStarted = false;
        currentTvSymbol = detected;
        if (wasFeedStarted) sendRuntime({ type: 'TVE_STOP_FEED' });
        sendBridge('TVE_DISCOVER');
        setStatus('نماد تغییر کرد', 'ready');
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  window.addEventListener('pagehide', () => {
    try { chrome.runtime.sendMessage({ type: 'TVE_STOP_FEED' }); } catch (_) {}
  }, { once: true });
  init();
})();
