(() => {
  'use strict';
  const checkbox = document.getElementById('continuousOpen');
  const statusEl = document.getElementById('tabStatus');
  async function activeTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs && tabs[0] ? tabs[0] : null;
  }
  async function sendToActiveTab(message) {
    const tab = await activeTab();
    if (!tab || !Number.isInteger(tab.id) || !String(tab.url || '').startsWith('https://www.tradingview.com/')) {
      return { ok: false, reason: 'Open a TradingView chart tab first.' };
    }
    try { return { ok: true, response: await chrome.tabs.sendMessage(tab.id, message) }; }
    catch (_) { return { ok: false, reason: 'TradingView content script is not ready. Reload the chart tab.' }; }
  }
  async function init() {
    try {
      const saved = await chrome.storage.local.get({ continuousOpen: true });
      checkbox.checked = saved.continuousOpen !== false;
    } catch (_) { checkbox.checked = true; }
    const tab = await activeTab();
    if (!tab || !String(tab.url || '').startsWith('https://www.tradingview.com/')) {
      statusEl.textContent = 'Open a TradingView chart to use TV Enhancer.';
      return;
    }
    const result = await sendToActiveTab({ type: 'TVE_POPUP_GET_STATE' });
    if (!result.ok) { statusEl.textContent = result.reason; return; }
    const s = result.response || {};
    statusEl.textContent = (s.symbol || 'Chart detected') + ' · ' + (s.feedState || 'Ready');
  }
  checkbox.addEventListener('change', async () => {
    const enabled = checkbox.checked;
    try { await chrome.storage.local.set({ continuousOpen: enabled }); } catch (_) {}
    const result = await sendToActiveTab({ type: 'TVE_POPUP_CONTINUOUS', enabled });
    if (!result.ok) statusEl.textContent = result.reason;
  });
  init();
})();
