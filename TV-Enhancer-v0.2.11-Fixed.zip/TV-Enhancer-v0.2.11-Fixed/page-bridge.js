(() => {
  'use strict';
  if (window.__TV_ENHANCER_PAGE_BRIDGE_V0211__) return;
  Object.defineProperty(window, '__TV_ENHANCER_PAGE_BRIDGE_V0211__', {
    value: true,
    configurable: false,
    enumerable: false
  });
  const CHANNEL = 'TV_ENHANCER_BRIDGE_V0211';
  const MAX_TRADES = 50000;
  const MIN_BARS_TO_APPLY = 20;
  const MIN_REAL_BARS_TO_APPLY = 20;
  const KEEP_SECONDS = 24 * 60 * 60;

  const state = {
    symbol: null,
    kcexSymbol: null,
    intervalSeconds: 5,
    continuousOpen: true,
    trades: [],
    tradeKeys: new Set(),
    historyLoaded: false,
    feedState: 'idle',
    applied: false,
    appliedInterval: null,
    appliedResolution: null,
    mainChartMutated: false,
    chartLockedForReload: false,
    nativeMessagesBlocked: false,
    nativeMessageGuardInstalled: false,
    updateTimeScaleGuardInstalled: false,
    suppressedNativeMessages: 0,
    suppressedTimeScaleUpdates: 0,
    allowTimeScaleUpdate: false,
    applyPhase: 'idle',
    originalInterval: null,
    appliedSymbol: null,
    appliedSeries: null,
    appliedSource: null,
    appliedModel: null,
    lastAppliedTime: null,
    originalResolution: null,
    lastUpdateAt: 0,
    receivedTrades: 0,
    rejectedTrades: 0,
    duplicateTrades: 0,
    lastError: null,
    refreshQueued: false
  };

  function emit(type, detail = {}) {
    const plainDetail = safeSnapshot(detail, 0, new WeakSet());
    try {
      window.postMessage({ channel: CHANNEL, from: 'page', type, detail: plainDetail }, '*');
    } catch (error) {
      try {
        window.postMessage({
          channel: CHANNEL,
          from: 'page',
          type,
          detail: {
            serializationFallback: true,
            serializationError: String(error?.message || error),
            originalType: String(type)
          }
        }, '*');
      } catch (_) {}
    }
  }

  function own(obj, key) {
    if (!obj || (typeof obj !== 'object' && typeof obj !== 'function')) return undefined;
    let p = obj;
    let n = 0;
    while (p && n++ < 8) {
      try {
        const d = Object.getOwnPropertyDescriptor(p, key);
        if (d) return Object.prototype.hasOwnProperty.call(d, 'value') ? d.value : undefined;
        p = Object.getPrototypeOf(p);
      } catch (_) { return undefined; }
    }
    return undefined;
  }

  function safeSnapshot(value, depth = 0, seen = new WeakSet()) {
    if (value === null || value === undefined) return value ?? null;
    const type = typeof value;
    if (type === 'string' || type === 'number' || type === 'boolean') return value;
    if (type === 'bigint') return String(value);
    if (type === 'function') return '[Function]';
    if (type !== 'object') return String(value);
    if (depth >= 3) return '[Object]';
    if (seen.has(value)) return '[Circular]';
    seen.add(value);
    if (Array.isArray(value)) {
      return value.slice(0, 20).map(item => safeSnapshot(item, depth + 1, seen));
    }
    if (value instanceof Map) return { type: 'Map', size: value.size };
    if (value instanceof Set) return { type: 'Set', size: value.size };
    if (value instanceof Date) return Number.isFinite(value.getTime()) ? value.toISOString() : 'Invalid Date';
    const result = {};
    let keys = [];
    try { keys = Object.keys(value).slice(0, 30); } catch (_) { return '[Unreadable Object]'; }
    for (const key of keys) {
      try {
        const descriptor = Object.getOwnPropertyDescriptor(value, key);
        if (!descriptor || !Object.prototype.hasOwnProperty.call(descriptor, 'value')) continue;
        if (typeof descriptor.value === 'function') continue;
        result[key] = safeSnapshot(descriptor.value, depth + 1, seen);
      } catch (_) {}
    }
    return result;
  }

  function call(obj, name, args = []) {
    const fn = own(obj, name);
    if (typeof fn !== 'function') return { ok: false, reason: 'missing ' + name };
    try { return { ok: true, value: fn.apply(obj, args) }; }
    catch (error) { return { ok: false, reason: String(error?.message || error) }; }
  }

  function symbolToKcex(value) {
    if (typeof value !== 'string') return null;
    let s = value.trim().toUpperCase().replace(/^KCEX:/, '').replace(/\.P$/, '').replace(/\.PERP$/, '');
    s = s.replace(/[^A-Z0-9_]/g, '');
    if (s.includes('_')) return s;
    if (s.endsWith('USDT') && s.length > 4) return s.slice(0, -4) + '_USDT';
    return null;
  }

  function discoverChart() {
    const api = own(window, 'TradingViewApi');
    const collection = own(window, '_exposed_chartWidgetCollection');
    const activeWV = own(api, '_activeChartWidgetWV');
    const activeWidget = own(activeWV, '_value');
    const exposedWV = own(collection, '_activeChartWidgetModel');
    const exposedWidget = own(exposedWV, '_value');
    const widgets = [activeWidget, exposedWidget].filter(Boolean);
    const candidates = [];
    for (const widget of widgets) {
      const m1 = call(widget, 'model').value;
      const m2 = own(widget, 'm_model');
      if (m1) candidates.push(m1);
      if (m2) candidates.push(m2);
    }
    if (api) {
      const m = call(api, 'model').value;
      if (m) candidates.push(m);
    }
    let model = null;
    let series = null;
    for (const candidate of candidates) {
      const s = call(candidate, 'mainSeries').value;
      const ts = call(candidate, 'timeScale').value;
      if (s && ts) { model = candidate; series = s; break; }
    }
    if (!series) {
      for (const widget of widgets) {
        const m = own(widget, 'm_model') || call(widget, 'model').value;
        const s = call(m, 'mainSeries').value;
        if (m && s) { model = m; series = s; break; }
      }
    }
    if (!model || !series) return { ok: false, reason: 'TradingView main chart objects not found' };
    const source = own(series, '_seriesSource');
    const data = call(series, 'data').value;
    const bars = call(data, 'bars').value;
    const timeScale = call(model, 'timeScale').value;
    const gateway = own(source, '_gateway');
    const intervalObject = call(series, 'intervalObj').value;
    const symbolResult = call(series, 'symbol');
    const symbol = symbolResult.ok ? symbolResult.value : null;
    if (!source || !data || !bars || !timeScale) {
      return { ok: false, reason: 'Main series is missing data/source/timeScale objects' };
    }
    return {
      ok: true,
      api, collection, model, series, source, data, bars, timeScale, gateway, intervalObject,
      symbol: typeof symbol === 'string' ? symbol : String(symbol || '')
    };
  }

  function notifyContext() {
    const chart = discoverChart();
    if (!chart.ok) {
      emit('TVE_CONTEXT', { found: false, reason: chart.reason });
      return;
    }
    if (state.symbol && state.symbol !== chart.symbol) {
      state.trades = [];
      state.tradeKeys.clear();
      state.historyLoaded = false;
      state.receivedTrades = 0;
      state.rejectedTrades = 0;
      state.duplicateTrades = 0;
      if (state.mainChartMutated || state.chartLockedForReload) {
        state.applied = false;
        state.applyPhase = 'reload-required';
      } else {
        state.applied = false;
        state.appliedInterval = null;
        state.appliedSeries = null;
        state.appliedSource = null;
        state.appliedModel = null;
        state.lastAppliedTime = null;
      }
      state.feedState = 'idle';
    }
    state.symbol = chart.symbol;
    state.kcexSymbol = symbolToKcex(chart.symbol);
    emit('TVE_CONTEXT', {
      found: true,
      tvSymbol: chart.symbol,
      kcexSymbol: state.kcexSymbol,
      interval: call(chart.series, 'interval').value ?? null,
      sourceResolution: own(chart.source, '_resolution') ?? null,
      intervalObject: (() => {
        const x = call(chart.intervalObject, 'value');
        return x.ok ? safeSnapshot(x.value) : null;
      })(),
      barCount: (() => { const x = call(chart.bars, 'size'); return x.ok ? x.value : null; })(),
      reloadRequired: state.chartLockedForReload || state.mainChartMutated,
      applyPhase: state.applyPhase
    });
  }

  function normalizeTrade(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const price = Number(raw.price ?? raw.p);
    const volume = Number(raw.volume ?? raw.v);
    const timestamp = Number(raw.timestamp ?? raw.t);
    if (!Number.isFinite(price) || price <= 0 || !Number.isFinite(volume) || volume < 0 ||
        !Number.isFinite(timestamp) || timestamp < 100000000000) return null;
    return {
      price, volume, timestamp,
      tradeType: raw.tradeType ?? raw.T ?? null,
      orderType: raw.orderType ?? raw.O ?? null,
      makerFlag: raw.makerFlag ?? raw.M ?? null
    };
  }

  function addTrade(raw, origin) {
    const trade = normalizeTrade(raw);
    if (!trade) { state.rejectedTrades++; return false; }
    const key = [trade.timestamp, trade.price, trade.volume, trade.tradeType, trade.orderType, trade.makerFlag].join('|');
    if (state.tradeKeys.has(key)) { state.duplicateTrades++; return false; }
    state.tradeKeys.add(key);
    state.trades.push({ ...trade, origin, receiveTime: Date.now() });
    state.receivedTrades++;
    const cutoff = Date.now() - KEEP_SECONDS * 1000;
    if (state.trades.length > MAX_TRADES || (state.trades.length && state.trades[0].timestamp < cutoff)) {
      state.trades = state.trades.filter(t => t.timestamp >= cutoff).slice(-MAX_TRADES);
      state.tradeKeys = new Set(state.trades.map(t => [t.timestamp, t.price, t.volume, t.tradeType, t.orderType, t.makerFlag].join('|')));
    }
    if (state.applied) queueLiveRefresh();
    return true;
  }

  function addHistory(trades) {
    if (!Array.isArray(trades)) return;
    for (const trade of trades) addTrade(trade, 'history');
    state.historyLoaded = true;
    updateStats();
  }

  function buildCandles(seconds = state.intervalSeconds) {
    const stepMs = seconds * 1000;
    const grouped = new Map();
    const trades = state.trades.slice().sort((a, b) => a.timestamp - b.timestamp || a.receiveTime - b.receiveTime);
    for (const trade of trades) {
      const bucketMs = Math.floor(trade.timestamp / stepMs) * stepMs;
      let c = grouped.get(bucketMs);
      if (!c) {
        c = { timeMs: bucketMs, open: trade.price, high: trade.price, low: trade.price, close: trade.price, volume: 0, trades: 0, synthetic: false };
        grouped.set(bucketMs, c);
      }
      c.high = Math.max(c.high, trade.price);
      c.low = Math.min(c.low, trade.price);
      c.close = trade.price;
      c.volume += trade.volume;
      c.trades++;
    }
    const actual = Array.from(grouped.values()).sort((a, b) => a.timeMs - b.timeMs);
    if (!actual.length) return [];
    const currentBucket = Math.floor(Date.now() / stepMs) * stepMs;
    const firstBucket = Math.max(actual[0].timeMs, currentBucket - 3599 * stepMs);
    const actualByTime = grouped;
    const result = [];
    let previousClose = null;
    for (let t = firstBucket; t <= Math.max(currentBucket, actual[actual.length - 1].timeMs); t += stepMs) {
      const real = actualByTime.get(t);
      if (real) {
        result.push({ ...real });
        previousClose = real.close;
      } else if (state.continuousOpen && previousClose !== null) {
        result.push({
          timeMs: t,
          open: previousClose,
          high: previousClose,
          low: previousClose,
          close: previousClose,
          volume: 0,
          trades: 0,
          synthetic: true
        });
      }
    }
    return result.slice(-3600);
  }

  function getBarSummary(candles) {
    const realCount = candles.filter(c => !c.synthetic).length;
    const syntheticCount = candles.length - realCount;
    return {
      intervalSeconds: state.intervalSeconds,
      total: candles.length,
      real: realCount,
      synthetic: syntheticCount,
      first: candles[0] ? new Date(candles[0].timeMs).toISOString() : null,
      last: candles.length ? new Date(candles[candles.length - 1].timeMs).toISOString() : null,
      lastCandles: candles.slice(-5).map(c => ({
        time: new Date(c.timeMs).toISOString(),
        open: c.open, high: c.high, low: c.low, close: c.close,
        volume: c.volume, trades: c.trades, synthetic: c.synthetic
      }))
    };
  }

  function updateStats(extra = {}) {
    const candles = buildCandles();
    emit('TVE_BRIDGE_STATE', {
      feedState: state.feedState,
      intervalSeconds: state.intervalSeconds,
      symbol: state.symbol,
      kcexSymbol: state.kcexSymbol,
      tradeCount: state.trades.length,
      receivedTrades: state.receivedTrades,
      duplicateTrades: state.duplicateTrades,
      rejectedTrades: state.rejectedTrades,
      historyLoaded: state.historyLoaded,
      candles: getBarSummary(candles),
      applied: state.applied,
      appliedInterval: state.appliedInterval,
      appliedResolution: state.appliedResolution,
      mainChartMutated: state.mainChartMutated,
      chartLockedForReload: state.chartLockedForReload || state.mainChartMutated,
      reloadRequired: state.chartLockedForReload || state.mainChartMutated,
      nativeMessagesBlocked: state.nativeMessagesBlocked,
      suppressedNativeMessages: state.suppressedNativeMessages,
      suppressedTimeScaleUpdates: state.suppressedTimeScaleUpdates,
      applyPhase: state.applyPhase,
      lastError: state.lastError,
      ...extra
    });
  }

  function barRows(candles, startIndex = 0) {
    return candles.map((c, i) => ({
      index: startIndex + i,
      value: [
        Math.floor(c.timeMs / 1000),
        c.open,
        c.high,
        c.low,
        c.close,
        c.volume
      ]
    }));
  }

  function resolutionText(value) {
    if (typeof value === 'string') return value.trim().toUpperCase();
    if (typeof value === 'number' && Number.isFinite(value)) return String(value);
    if (value && typeof value === 'object') {
      const candidates = [
        own(value, 'resolution'),
        own(value, 'value'),
        own(value, '_value')
      ];
      for (const candidate of candidates) {
        if (typeof candidate === 'string' || typeof candidate === 'number') {
          return String(candidate).trim().toUpperCase();
        }
      }
    }
    return '';
  }

  function currentDataSources(chart) {
    const result = call(chart.model, 'dataSources');
    return Array.isArray(result.value) ? result.value : [];
  }

  function installNativeMessageGuard(chart) {
    const source = chart.source;
    const original = own(source, '_onMessageImpl');
    if (typeof original !== 'function') {
      throw new Error('SeriesSource._onMessageImpl در TradingView پیدا نشد.');
    }
    if (!Object.isExtensible(source)) {
      throw new Error('SeriesSource قابل توسعه نیست.');
    }
    if (state.nativeMessageGuardInstalled) {
      if (state.appliedSource === source) return;
      throw new Error('نیاز به Reload صفحه است.');
    }
    const guardedMethods = new Set([
      'symbol_resolved', 'symbol_error', 'series_timeframe', 'series_error',
      'series_loading', 'series_completed', 'data_update', 'clear_data', 'timescale_update'
    ]);
    const guarded = function (message) {
      if (state.nativeMessagesBlocked && message && guardedMethods.has(message.method)) {
        state.suppressedNativeMessages++;
        return undefined;
      }
      return original.apply(this, arguments);
    };
    Object.defineProperty(source, '_onMessageImpl', {
      configurable: true,
      enumerable: false,
      writable: true,
      value: guarded
    });
    state.nativeMessageGuardInstalled = true;

    // ROOT CAUSE FIX #1 (Fixes the 47 -> 81 TimeScale point jump on live updates in 006/007.txt):
    // TradingView's server WebSocket routes `timescale_update` and study updates directly to
    // ChartModel._updateTimeScale() or secondary data sources. When MainSeries is kept on 1m
    // (so its paneViews and client-side indicators continue rendering!), any stray 1m server
    // timescale_update appends 1-minute points onto our seconds TimeScale!
    // By gating ChartModel._updateTimeScale so ONLY our explicit `runTimeScaleUpdate` calls pass
    // while `nativeMessagesBlocked` is true, `timeScale.pointCount` stays 100% locked to `bars.count`.
    if (!state.updateTimeScaleGuardInstalled) {
      const model = chart.model;
      const origUpdateTS = own(model, '_updateTimeScale');
      if (typeof origUpdateTS === 'function' && Object.isExtensible(model)) {
        const guardedUpdateTS = function () {
          if (state.nativeMessagesBlocked && !state.allowTimeScaleUpdate) {
            state.suppressedTimeScaleUpdates++;
            return undefined;
          }
          return origUpdateTS.apply(this, arguments);
        };
        try {
          Object.defineProperty(model, '_updateTimeScale', {
            configurable: true,
            enumerable: false,
            writable: true,
            value: guardedUpdateTS
          });
          state.updateTimeScaleGuardInstalled = true;
        } catch (_) {}
      }
    }
  }

  function runTimeScaleUpdate(model, updateFn, payload) {
    state.allowTimeScaleUpdate = true;
    try {
      return updateFn.call(model, payload);
    } finally {
      state.allowTimeScaleUpdate = false;
    }
  }

  function getTickMarkTemplate(timeScale) {
    const tickStore = own(timeScale, '_tickMarks');
    const marksByWeight = own(tickStore, '_marksByWeight');
    let template = null;
    let fallbackWeight = 0;
    if (marksByWeight instanceof Map) {
      for (const [weight, list] of marksByWeight.entries()) {
        if (typeof weight === 'number' && Number.isFinite(weight)) fallbackWeight = weight;
        if (Array.isArray(list) && list.length) {
          template = list[0];
          if (Number.isFinite(own(template, 'weight'))) fallbackWeight = own(template, 'weight');
          break;
        }
      }
    }
    return {
      tickStore,
      template,
      weight: fallbackWeight,
      templateKeys: template ? Object.keys(template).slice(0, 20) : [],
      weightBuckets: marksByWeight instanceof Map ? Array.from(marksByWeight.keys()).slice(0, 20) : []
    };
  }

  function computeTickMarkWeight(seconds, fallbackWeight = 10) {
    // Gives TradingView's bottom time axis clean hierarchical weights for second/minute boundaries
    if (seconds % 86400 === 0) return 50;
    if (seconds % 3600 === 0) return 40;
    if (seconds % 60 === 0) return 30;
    if (seconds % 15 === 0) return 20;
    return fallbackWeight || 10;
  }

  function makeTimeMarks(candlesOrRows, startIndex, timeScale, cachedTemplateInfo = null) {
    const info = cachedTemplateInfo || getTickMarkTemplate(timeScale);
    const marks = [];
    for (let i = 0; i < candlesOrRows.length; i++) {
      const item = candlesOrRows[i];
      const seconds = item.value
        ? Number(item.value[0])
        : Math.floor(Number(item.timeMs) / 1000);
      if (!Number.isFinite(seconds)) continue;
      marks.push({
        index: startIndex + i,
        time: seconds,
        weight: computeTickMarkWeight(seconds, info.weight),
        originalTime: seconds
      });
    }
    return { marks, info };
  }

  function collectSourceQueues(chart) {
    const sources = new Set([chart.source]);
    for (const dataSource of currentDataSources(chart)) {
      const source = own(dataSource, '_seriesSource') || call(dataSource, 'seriesSource').value;
      if (source && typeof source === 'object') sources.add(source);
    }
    return Array.from(sources).map(source => ({
      source,
      promise: own(source, '_ongoingDataUpdate')
    })).filter(item => item.promise && typeof item.promise.then === 'function');
  }

  async function drainSourceQueues(chart, phase) {
    const queues = collectSourceQueues(chart);
    const settleAll = Promise.all(queues.map(async item => {
      try {
        await item.promise;
        return { ok: true };
      } catch (error) {
        return { ok: false, error: String(error?.message || error) };
      }
    }));
    let timeoutId = null;
    const timeout = new Promise((_, reject) => {
      timeoutId = setTimeout(() => reject(new Error('زمان انتظار برای صف‌های TradingView به پایان رسید.')), 7000);
    });
    let outcomes;
    try {
      outcomes = await Promise.race([settleAll, timeout]);
    } finally {
      if (timeoutId !== null) clearTimeout(timeoutId);
    }
    const failed = outcomes.find(outcome => !outcome.ok);
    if (failed) throw new Error('خطا در صف TradingView: ' + failed.error);
    await new Promise(resolve => setTimeout(resolve, 0));
    await new Promise(resolve => {
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => resolve());
      else setTimeout(resolve, 16);
    });
    await new Promise(resolve => setTimeout(resolve, 0));
    emit('TVE_APPLY_PHASE', {
      phase,
      drainedSourceQueues: queues.length,
      sourceQueueTypes: queues.map(item => own(item.source, 'constructor')?.name || 'SeriesSource'),
      barCountAfterDrain: call(call(chart.series, 'data').value, 'bars').value
        ? call(call(call(chart.series, 'data').value, 'bars').value, 'size').value
        : null
    });
  }

  function getTimeScalePointCount(timeScale) {
    const points = call(timeScale, 'points').value;
    const items = own(points, '_items');
    return Array.isArray(items) ? items.length : null;
  }

  function normalizeTimePointSeconds(value) {
    if (value instanceof Date) {
      const ms = value.getTime();
      return Number.isFinite(ms) ? Math.floor(ms / 1000) : null;
    }
    if (typeof value === 'number' && Number.isFinite(value)) {
      return Math.floor(Math.abs(value) >= 1e12 ? value / 1000 : value);
    }
    if (typeof value === 'string') {
      const text = value.trim();
      if (!text) return null;
      if (/^-?\d+(?:\.\d+)?$/.test(text)) {
        const numeric = Number(text);
        return Number.isFinite(numeric)
          ? Math.floor(Math.abs(numeric) >= 1e12 ? numeric / 1000 : numeric)
          : null;
      }
      const parsed = Date.parse(text);
      return Number.isFinite(parsed) ? Math.floor(parsed / 1000) : null;
    }
    return null;
  }

  function verifyAppliedChart(chart, expectedRows, targetResolution, expectedSeriesResolution) {
    const afterData = call(chart.series, 'data').value;
    const afterBars = call(afterData, 'bars').value;
    const items = own(afterBars, '_items');
    const countResult = call(afterBars, 'size');
    const lastIndexResult = call(afterBars, 'lastIndex');
    const firstIndexResult = call(afterBars, 'firstIndex');
    const lastRow = Array.isArray(items) && items.length ? items[items.length - 1] : null;
    const firstRow = Array.isArray(items) && items.length ? items[0] : null;
    const expectedFirstTime = expectedRows[0].value[0];
    const expectedLastTime = expectedRows[expectedRows.length - 1].value[0];
    const actualFirstTime = Number(firstRow?.value?.[0]);
    const actualLastTime = Number(lastRow?.value?.[0]);
    const allBarsMatch = Array.isArray(items) && items.length === expectedRows.length &&
      expectedRows.every((expected, i) => {
        const actual = items[i];
        if (!actual || Number(actual.index) !== expected.index || !Array.isArray(actual.value) || actual.value.length !== 6) return false;
        return expected.value.every((value, j) => {
          const actualValue = Number(actual.value[j]);
          if (!Number.isFinite(actualValue)) return false;
          if (j === 0) return actualValue === value;
          const tolerance = Math.max(1e-12, Math.abs(value) * 1e-10);
          return Math.abs(actualValue - value) <= tolerance;
        });
      });
    const actualSeriesResolution = resolutionText(call(chart.series, 'interval').value);
    const actualSourceResolution = resolutionText(own(chart.source, '_resolution'));
    const scaleFirst = call(chart.timeScale, 'indexToTimePoint', [0]);
    const scaleLast = call(chart.timeScale, 'indexToTimePoint', [expectedRows.length - 1]);
    const indexRange = call(call(chart.timeScale, 'points').value, 'range');
    const rangeValue = indexRange.ok ? call(indexRange.value, 'value').value : null;
    const tickLast = call(own(chart.timeScale, '_tickMarks'), 'indexToTime', [expectedRows.length - 1]);
    const tickLastSeconds = tickLast.ok ? normalizeTimePointSeconds(tickLast.value) : null;
    const tickLastDisplay = tickLast.ok
      ? (tickLast.value instanceof Date
          ? (Number.isFinite(tickLast.value.getTime()) ? tickLast.value.toISOString() : 'Invalid Date')
          : safeSnapshot(tickLast.value))
      : null;
    const timeScalePointCount = getTimeScalePointCount(chart.timeScale);
    const result = {
      barCount: countResult.value,
      firstIndex: firstIndexResult.value,
      lastIndex: lastIndexResult.value,
      firstBarTime: actualFirstTime,
      lastBarTime: actualLastTime,
      allBarsMatch,
      seriesResolution: actualSeriesResolution,
      expectedSeriesResolution,
      sourceResolution: actualSourceResolution,
      timeScaleFirstPoint: scaleFirst.ok ? scaleFirst.value : null,
      timeScaleLastPoint: scaleLast.ok ? scaleLast.value : null,
      timeScaleRange: rangeValue ? safeSnapshot(rangeValue) : null,
      timeScalePointCount,
      tickMarkLastTime: tickLastDisplay,
      tickMarkLastTimeType: tickLast.ok
        ? (tickLast.value instanceof Date ? 'Date' : typeof tickLast.value)
        : null,
      tickMarkLastTimeSeconds: tickLastSeconds,
      tickMarkMatchesExpected: tickLastSeconds === expectedLastTime
    };
    const ok =
      countResult.ok &&
      countResult.value === expectedRows.length &&
      allBarsMatch &&
      firstIndexResult.value === 0 &&
      lastIndexResult.value === expectedRows.length - 1 &&
      actualFirstTime === expectedFirstTime &&
      actualLastTime === expectedLastTime &&
      actualSeriesResolution === expectedSeriesResolution &&
      actualSourceResolution === targetResolution &&
      scaleFirst.ok && scaleFirst.value === expectedFirstTime &&
      scaleLast.ok && scaleLast.value === expectedLastTime &&
      rangeValue && own(rangeValue, 'firstIndex') === 0 &&
      own(rangeValue, 'lastIndex') === expectedRows.length - 1 &&
      timeScalePointCount === expectedRows.length &&
      tickLast.ok && tickLastSeconds === expectedLastTime;
    return { ok, result };
  }

  function readRangeEdge(range, edge) {
    if (!range) return null;
    const direct = own(range, edge);
    if (Number.isFinite(direct)) return direct;
    const method = edge === 'left' ? 'left' : edge === 'right' ? 'right' : edge;
    const result = call(range, method);
    return result.ok && Number.isFinite(result.value) ? result.value : null;
  }

  function getViewportSnapshot(chart) {
    const ts = chart.timeScale;
    const logical = call(ts, 'logicalRange');
    const visible = call(ts, 'visibleBarsStrictRange');
    return {
      baseIndex: call(ts, 'baseIndex').value ?? null,
      rightOffset: call(ts, 'rightOffset').value ?? own(ts, '_rightOffset') ?? null,
      barSpacing: call(ts, 'barSpacing').value ?? own(ts, '_barSpacing') ?? null,
      width: call(ts, 'width').value ?? own(ts, '_width') ?? null,
      logicalRange: logical.ok && logical.value ? {
        left: readRangeEdge(logical.value, '_left') ?? readRangeEdge(logical.value, 'left'),
        right: readRangeEdge(logical.value, '_right') ?? readRangeEdge(logical.value, 'right')
      } : null,
      visibleBars: visible.ok && visible.value ? {
        firstBar: call(visible.value, 'firstBar').value ?? own(visible.value, '_firstBar') ?? null,
        lastBar: call(visible.value, 'lastBar').value ?? own(visible.value, '_lastBar') ?? null
      } : null
    };
  }

  function getVisibleBarPriceBounds(chart) {
    const visible = call(chart.timeScale, 'visibleBarsStrictRange').value;
    const first = visible
      ? (call(visible, 'firstBar').value ?? own(visible, '_firstBar'))
      : null;
    const last = visible
      ? (call(visible, 'lastBar').value ?? own(visible, '_lastBar'))
      : null;
    const items = own(chart.bars, '_items');
    if (!Array.isArray(items) || !Number.isFinite(first) || !Number.isFinite(last)) {
      return { ok: false, reason: 'Visible bar range or BarStore rows unavailable', firstBar: first ?? null, lastBar: last ?? null };
    }
    let low = Infinity;
    let high = -Infinity;
    let count = 0;
    for (const row of items) {
      const index = Number(row?.index);
      const value = row?.value;
      if (index < first || index > last || !Array.isArray(value) || value.length < 5) continue;
      const barLow = Number(value[3]);
      const barHigh = Number(value[2]);
      if (!Number.isFinite(barLow) || !Number.isFinite(barHigh)) continue;
      low = Math.min(low, barLow);
      high = Math.max(high, barHigh);
      count++;
    }
    if (!count || !Number.isFinite(low) || !Number.isFinite(high)) {
      return { ok: false, reason: 'No valid OHLC bars in current visible range', firstBar: first, lastBar: last, count };
    }
    return { ok: true, firstBar: first, lastBar: last, low, high, count };
  }

  function getPriceRangeSnapshot(priceScale) {
    const result = call(priceScale, 'priceRange');
    if (!result.ok || !result.value) return { ok: false, reason: result.reason || 'PriceScale.priceRange returned null' };
    const range = result.value;
    const min = call(range, 'minValue').value ?? own(range, '_minValue') ?? null;
    const max = call(range, 'maxValue').value ?? own(range, '_maxValue') ?? null;
    const minOk = min !== null && min !== undefined && Number.isFinite(Number(min));
    const maxOk = max !== null && max !== undefined && Number.isFinite(Number(max));
    return {
      ok: minOk && maxOk,
      min: minOk ? Number(min) : null,
      max: maxOk ? Number(max) : null,
      type: range?.constructor?.name || 'PriceRange'
    };
  }

  function priceRangeCoversVisibleBars(chart) {
    const priceScale = call(chart.series, 'priceScale').value;
    if (!priceScale) return { ok: false, reason: 'Main series PriceScale unavailable' };
    const bounds = getVisibleBarPriceBounds(chart);
    const range = getPriceRangeSnapshot(priceScale);
    if (!bounds.ok || !range.ok) return { ok: false, bounds, range, reason: bounds.reason || range.reason };
    const isLog = !!call(priceScale, 'isLog').value;
    const tolerance = Math.max(1e-12, Math.max(Math.abs(bounds.low), Math.abs(bounds.high)) * 1e-9);
    const covers = isLog || (range.min <= bounds.low + tolerance && range.max >= bounds.high - tolerance);
    return {
      ok: covers,
      isLog,
      autoScale: call(priceScale, 'isAutoScale').value ?? null,
      lockScale: call(priceScale, 'isLockScale').value ?? null,
      priceRangeReady: call(chart.series, 'priceRangeReady').value ?? own(chart.series, '_priceRangeReady') ?? null,
      bounds,
      range,
      coversVisibleBars: covers
    };
  }

  async function refreshVisiblePriceScale(chart, enableAutoScaleForInteraction = false) {
    const priceScale = call(chart.series, 'priceScale').value;
    const visible = call(chart.timeScale, 'visibleBarsStrictRange').value;
    const logical = call(chart.timeScale, 'logicalRange').value;
    if (!priceScale || !visible || !logical) {
      throw new Error('PriceScale در دسترس نیست.');
    }
    const before = priceRangeCoversVisibleBars(chart);
    const readyBefore = call(chart.series, 'priceRangeReady').value ?? own(chart.series, '_priceRangeReady') ?? null;
    let readinessRestored = false;
    let autoScaleEnabledForInteraction = false;
    const setModeAtStart = own(priceScale, 'setMode');
    if (enableAutoScaleForInteraction && typeof setModeAtStart === 'function' && call(priceScale, 'isLockScale').value !== true) {
      const modeResult = call(priceScale, 'setMode', [{ autoScale: true }]);
      autoScaleEnabledForInteraction = modeResult.ok;
    }
    if (readyBefore === false) {
      const enableReady = own(chart.series, '_enablePriceRangeReady');
      if (typeof enableReady === 'function') {
        enableReady.call(chart.series);
        readinessRestored = true;
      }
    }
    const recalcOnce = own(priceScale, 'recalculatePriceRangeOnce');
    if (typeof recalcOnce === 'function') recalcOnce.call(priceScale);
    const invalidateRange = own(priceScale, 'recalculatePriceRange');
    if (typeof invalidateRange !== 'function') {
      throw new Error('PriceScale.recalculatePriceRange در TradingView پیدا نشد.');
    }
    invalidateRange.call(priceScale, visible, logical);
    const firstCalculation = call(priceScale, 'priceRange');
    const fullUpdate = own(chart.model, 'fullUpdate');
    if (typeof fullUpdate === 'function') fullUpdate.call(chart.model);
    await new Promise(resolve => {
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => requestAnimationFrame(resolve));
      else setTimeout(resolve, 40);
    });
    const after = priceRangeCoversVisibleBars(chart);
    let autoscaleFallback = false;
    if (!after.ok) {
      const setMode = own(priceScale, 'setMode');
      if (typeof setMode === 'function') {
        setMode.call(priceScale, { autoScale: true });
        autoscaleFallback = true;
        if (typeof recalcOnce === 'function') recalcOnce.call(priceScale);
        invalidateRange.call(priceScale, visible, logical);
        call(priceScale, 'priceRange');
        if (typeof fullUpdate === 'function') fullUpdate.call(chart.model);
        await new Promise(resolve => {
          if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => requestAnimationFrame(resolve));
          else setTimeout(resolve, 40);
        });
      }
    }
    const final = priceRangeCoversVisibleBars(chart);
    const result = {
      before,
      readyBefore,
      readyAfter: call(chart.series, 'priceRangeReady').value ?? own(chart.series, '_priceRangeReady') ?? null,
      readinessRestored,
      autoScaleEnabledForInteraction,
      firstCalculationOk: firstCalculation.ok,
      autoscaleFallback,
      after: final,
      invalidatedForRange: safeSnapshot(own(priceScale, '_invalidatedForRange'))
    };
    if (!final.ok) {
      throw new Error('خطا در تنظیم PriceScale: ' + JSON.stringify(result));
    }
    return result;
  }

  async function revealLatestBars(chart, lastIndex) {
    const before = getViewportSnapshot(chart);
    const setter = own(chart.timeScale, 'setRightOffset');
    if (typeof setter !== 'function') {
      throw new Error('TimeScale.setRightOffset در TradingView پیدا نشد.');
    }
    setter.call(chart.timeScale, Math.min(5, Math.max(0, lastIndex)));
    const lightUpdate = own(chart.model, 'lightUpdate');
    if (typeof lightUpdate === 'function') lightUpdate.call(chart.model);
    await new Promise(resolve => {
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => resolve());
      else setTimeout(resolve, 16);
    });
    const after = getViewportSnapshot(chart);
    const logical = after.logicalRange;
    const visibleContainsLatest = !!logical &&
      Number.isFinite(logical.left) && Number.isFinite(logical.right) &&
      logical.left <= lastIndex && logical.right >= lastIndex;
    return { before, after, visibleContainsLatest, targetRightOffset: Math.min(5, Math.max(0, lastIndex)) };
  }

  async function applyInitialToMainChart() {
    if (state.mainChartMutated || state.chartLockedForReload) {
      throw new Error('نیاز به Reload صفحه است.');
    }
    const chart = discoverChart();
    if (!chart.ok) throw new Error(chart.reason);
    const expected = state.kcexSymbol;
    const actual = symbolToKcex(chart.symbol);
    if (!expected || !actual || expected !== actual) {
      throw new Error('نماد چارت با KCEX همخوانی ندارد: ' + chart.symbol + ' / انتظار: ' + (expected || '--'));
    }
    const candles = buildCandles();
    const realCount = candles.filter(c => !c.synthetic).length;
    if (candles.length < MIN_BARS_TO_APPLY || realCount < MIN_REAL_BARS_TO_APPLY) {
      throw new Error(
        'حداقل ' + MIN_REAL_BARS_TO_APPLY +
        ' کندل واقعی لازم است (فعلی: ' + realCount + ' واقعی از ' +
        candles.length + ' کل)'
      );
    }
    const status = own(chart.source, '_status');
    if (status !== 3) throw new Error('وضعیت SeriesSource آماده نیست: ' + status);
    const updateTimeScale = own(chart.model, '_updateTimeScale');
    const acceptUnpacked = own(chart.source, '_onDataUnpacked');
    const enqueueUpdate = own(chart.source, '_enqueueUpdate');
    const messageHandler = own(chart.source, '_onMessageImpl');
    if (typeof updateTimeScale !== 'function' || typeof acceptUnpacked !== 'function' ||
        typeof enqueueUpdate !== 'function' || typeof messageHandler !== 'function') {
      throw new Error('توابع داخلی API در TradingView یافت نشدند.');
    }
    if (!Object.isExtensible(chart.source)) {
      throw new Error('SeriesSource قابل تغییر نیست.');
    }

    const targetResolution = String(state.intervalSeconds) + 'S';
    const originalResolution = own(chart.source, '_resolution');
    const originalSeriesInterval = call(chart.series, 'interval').value;
    const originalSeriesResolution = resolutionText(originalSeriesInterval);
    const rows = barRows(candles, 0);
    const timeValues = candles.map(c => Math.floor(c.timeMs / 1000));

    for (let i = 0; i < rows.length; i++) {
      const v = rows[i].value;
      if (v.length !== 6 || !v.every(Number.isFinite) || v[0] <= 0 ||
          v[1] <= 0 || v[2] < Math.max(v[1], v[4]) ||
          v[3] > Math.min(v[1], v[4]) || v[5] < 0) {
        throw new Error('کندل نامعتبر در ردیف ' + (i + 1));
      }
      if (i > 0) {
        if (!(timeValues[i] > timeValues[i - 1])) {
          throw new Error('ترتیب زمانی کندل‌ها صعودی نیست.');
        }
        if (state.continuousOpen && timeValues[i] - timeValues[i - 1] !== state.intervalSeconds) {
          throw new Error('فاصله زمانی Continuous Open رعایت نشده است.');
        }
      }
    }

    // ROOT CAUSE FIX #2 & #3:
    // 1) Capture TickMark template BEFORE touching MainSeries or clearing TimeScale!
    //    (In v0.2.10, MainSeries.setInterval wiped _marksByWeight, leaving template: null).
    // 2) Keep MainSeries on its active resolution (1m) so TradingView NEVER enters the
    //    `series_loading` state and NEVER destroys client-side studies or candle paneViews
    //    (fixing the blank chart in v0.2.10 / 008.txt), while passing full `marks` with
    //    `clearTickMarks: true` AND locking `_updateTimeScale` (fixing the axis jump in v0.2.9 / 007.txt).
    const cachedTickTemplate = getTickMarkTemplate(chart.timeScale);
    const tickData = makeTimeMarks(candles, 0, chart.timeScale, cachedTickTemplate);
    if (!tickData.marks.length || tickData.marks.length !== rows.length) {
      throw new Error('ساختار TickMark برای TimeScale ساخته نشد.');
    }

    const last = timeValues[timeValues.length - 1];
    const payload = {
      index: 0,
      zoffset: 0,
      values: timeValues,
      indexDiffs: [],
      baseIndex: rows.length - 1,
      marks: tickData.marks,
      clearFlag: true,
      clearTickMarks: true
    };

    installNativeMessageGuard(chart);
    state.mainChartMutated = true;
    state.chartLockedForReload = true;
    state.applyPhase = 'mutating';
    state.nativeMessagesBlocked = true;
    state.originalResolution = originalResolution;
    state.originalInterval = originalSeriesInterval;
    state.appliedResolution = targetResolution;
    state.appliedSymbol = chart.symbol;
    state.appliedSeries = chart.series;
    state.appliedSource = chart.source;
    state.appliedModel = chart.model;
    updateStats();

    chart.source._resolution = targetResolution;
    const sourceResolutionAfter = resolutionText(own(chart.source, '_resolution'));
    const seriesResolutionAfter = resolutionText(call(chart.series, 'interval').value);
    if (sourceResolutionAfter !== targetResolution || seriesResolutionAfter !== originalSeriesResolution) {
      throw new Error(
        'عدم تطابق رزولوشن: MainSeries=' + (seriesResolutionAfter || '--') +
        ' / SeriesSource=' + (sourceResolutionAfter || '--')
      );
    }

    const hybridMode = {
      mainSeriesIntervalPreserved: true,
      originalMainSeriesInterval: originalSeriesResolution,
      currentMainSeriesInterval: seriesResolutionAfter,
      originalSourceResolution: resolutionText(originalResolution),
      currentSourceResolution: sourceResolutionAfter,
      tickMarksRebuilt: true,
      timeScaleGuardActive: state.updateTimeScaleGuardInstalled
    };

    emit('TVE_APPLY_PHASE', {
      phase: 'hybrid-source-resolution-ready',
      targetResolution,
      hybridMode,
      barCountBeforeReset: call(chart.bars, 'size').value,
      timeScalePointCountBeforeReset: getTimeScalePointCount(chart.timeScale)
    });

    runTimeScaleUpdate(chart.model, updateTimeScale, payload);

    emit('TVE_APPLY_PHASE', {
      phase: 'timescale-reset-requested',
      expectedBars: rows.length,
      expectedFirstTime: timeValues[0],
      expectedLastTime: last,
      timeScalePointCount: getTimeScalePointCount(chart.timeScale)
    });

    await drainSourceQueues(chart, 'clear-queues-drained');

    const clearedChart = discoverChart();
    if (!clearedChart.ok || clearedChart.series !== chart.series || clearedChart.source !== chart.source) {
      throw new Error('مرجع MainSeries/SeriesSource تغییر کرده است.');
    }
    const clearedBarCount = call(clearedChart.bars, 'size').value;
    if (clearedBarCount !== 0) {
      throw new Error('پاکسازی BarStore کامل نشد: ' + clearedBarCount + ' کندل باقی مانده.');
    }
    const clearedPointCount = getTimeScalePointCount(clearedChart.timeScale);
    if (clearedPointCount !== rows.length) {
      throw new Error('تعداد نقاط TimeScale تطابق ندارد: ' + clearedPointCount + ' / ' + rows.length);
    }

    emit('TVE_APPLY_PHASE', {
      phase: 'old-bars-cleared',
      clearedBarCount,
      timeScalePointCount: clearedPointCount,
      expectedBars: rows.length
    });

    await enqueueUpdate.call(chart.source, () => {
      acceptUnpacked.call(chart.source, rows, rows[rows.length - 1], null);
    });

    await drainSourceQueues(chart, 'data-update-queues-drained');

    const finalChart = discoverChart();
    if (!finalChart.ok || finalChart.series !== chart.series || finalChart.source !== chart.source) {
      throw new Error('مرجع MainSeries/SeriesSource پس از تزریق تغییر کرد.');
    }

    const verification = verifyAppliedChart(finalChart, rows, targetResolution, originalSeriesResolution);
    emit('TVE_APPLY_PHASE', {
      phase: 'verification-complete',
      success: !!verification?.ok,
      verification: verification?.result || null
    });

    if (!verification || !verification.ok) {
      throw new Error(
        'تایید ساختار MainSeries/TimeScale ناموفق بود: ' +
        JSON.stringify(verification?.result || {})
      );
    }

    const viewport = await revealLatestBars(finalChart, rows.length - 1);
    if (!viewport.visibleContainsLatest) {
      throw new Error('نمایش آخرین کندل‌ها در TimeScale ناموفق بود: ' + JSON.stringify(viewport));
    }

    const priceScaleRefresh = await refreshVisiblePriceScale(finalChart, true);
    const finalFullUpdate = call(finalChart.model, 'fullUpdate');
    await new Promise(resolve => {
      if (typeof requestAnimationFrame === 'function') requestAnimationFrame(() => requestAnimationFrame(resolve));
      else setTimeout(resolve, 40);
    });

    state.applied = true;
    state.applyPhase = 'applied';
    state.appliedInterval = state.intervalSeconds;
    state.lastAppliedTime = last;
    state.lastUpdateAt = Date.now();

    emit('TVE_APPLY_RESULT', {
      success: true,
      applyAlgorithm: 'hybrid-source-resolution -> guarded-timescale-with-tickmarks -> drain-all-clear-queues -> native-unpacked-insert -> verify -> reveal-viewport -> recalculate-visible-price-scale -> fullUpdate',
      resolutionMode: 'hybrid-series-preserved-with-tickmarks-and-timescale-guard',
      mainSeriesIntervalPreserved: true,
      reloadRequired: true,
      chartLockedForReload: true,
      nativeMessagesBlocked: true,
      suppressedNativeMessages: state.suppressedNativeMessages,
      suppressedTimeScaleUpdates: state.suppressedTimeScaleUpdates,
      symbol: chart.symbol,
      interval: state.intervalSeconds + 's',
      seriesInterval: verification.result.seriesResolution,
      sourceResolution: verification.result.sourceResolution,
      submittedBars: rows.length,
      barStoreCount: verification.result.barCount,
      firstTime: timeValues[0],
      lastTime: last,
      firstBarTime: verification.result.firstBarTime,
      lastBarTime: verification.result.lastBarTime,
      timeScaleFirstPoint: verification.result.timeScaleFirstPoint,
      timeScaleLastPoint: verification.result.timeScaleLastPoint,
      tickMarkLastTime: verification.result.tickMarkLastTime,
      originalResolution,
      originalSeriesInterval,
      hybridMode,
      tickMarkTemplate: tickData.info,
      verification: verification.result,
      viewport,
      priceScaleRefresh,
      nativeFullUpdate: { ok: finalFullUpdate.ok, reason: finalFullUpdate.reason || null }
    });

    updateStats({
      applySuccess: true,
      actualResolution: verification.result.seriesResolution,
      barStoreCount: verification.result.barCount,
      lastIndex: rows.length - 1,
      viewport,
      priceScaleRefresh
    });
    return true;
  }

  function refreshAppliedChart() {
    if (!state.applied || state.refreshQueued) return;
    state.refreshQueued = true;
    setTimeout(async () => {
      state.refreshQueued = false;
      try {
        const chart = discoverChart();
        if (!chart.ok || chart.series !== state.appliedSeries || chart.source !== state.appliedSource) {
          state.applied = false;
          state.chartLockedForReload = true;
          state.applyPhase = 'reload-required';
          state.lastError = 'چارت تغییر کرده است؛ نیاز به Reload صفحه.';
          emit('TVE_APPLY_ERROR', { message: state.lastError, reloadRequired: true });
          updateStats();
          return;
        }
        const currentSeriesResolution = resolutionText(call(chart.series, 'interval').value);
        const currentSourceResolution = resolutionText(own(chart.source, '_resolution'));
        if (currentSeriesResolution !== resolutionText(state.originalInterval) ||
            currentSourceResolution !== state.appliedResolution) {
          state.applied = false;
          state.chartLockedForReload = true;
          state.applyPhase = 'reload-required';
          state.lastError = 'رزولوشن چارت تغییر کرده است؛ نیاز به Reload صفحه.';
          emit('TVE_APPLY_ERROR', { message: state.lastError, reloadRequired: true });
          updateStats();
          return;
        }
        const candles = buildCandles(state.appliedInterval);
        if (!candles.length) return;
        const data = call(chart.series, 'data').value;
        const store = call(data, 'bars').value;
        const currentLastIndex = call(store, 'lastIndex').value;
        const existing = own(store, '_items');
        if (!Array.isArray(existing) || !existing.length || !Number.isFinite(currentLastIndex)) return;
        const lastStoredRow = existing[existing.length - 1];
        const lastStoredTime = Number(lastStoredRow?.value?.[0]);
        if (!Number.isFinite(lastStoredTime)) return;
        const candidates = candles.filter(c => Math.floor(c.timeMs / 1000) >= lastStoredTime);
        if (!candidates.length) return;
        const rows = [];
        let nextIndex = currentLastIndex;
        for (const candle of candidates) {
          const time = Math.floor(candle.timeMs / 1000);
          if (time < lastStoredTime) continue;
          let index;
          if (time === lastStoredTime) {
            index = currentLastIndex;
          } else {
            index = ++nextIndex;
          }
          rows.push({
            index,
            value: [time, candle.open, candle.high, candle.low, candle.close, candle.volume]
          });
        }
        if (!rows.length) return;
        const newRows = rows.filter(row => row.index > currentLastIndex);
        const enqueue = own(chart.source, '_enqueueUpdate');
        if (typeof enqueue !== 'function') throw new Error('SeriesSource update queue unavailable');
        const update = own(chart.model, '_updateTimeScale');
        const accept = own(chart.source, '_onDataUnpacked');
        if (typeof accept !== 'function' || typeof update !== 'function') throw new Error('Series data update unavailable');

        await enqueue.call(chart.source, () => {
          if (newRows.length) {
            const firstNewIndex = newRows[0].index;
            const tickData = makeTimeMarks(newRows, firstNewIndex, chart.timeScale);
            runTimeScaleUpdate(chart.model, update, {
              index: firstNewIndex,
              zoffset: 0,
              values: newRows.map(row => row.value[0]),
              indexDiffs: [],
              baseIndex: newRows[newRows.length - 1].index,
              marks: tickData.marks,
              clearFlag: false,
              clearTickMarks: false
            });
          }
          accept.call(chart.source, rows, rows[rows.length - 1], null);
        });

        const lightUpdate = own(chart.model, 'lightUpdate');
        if (typeof lightUpdate === 'function') lightUpdate.call(chart.model);

        const priceStatus = priceRangeCoversVisibleBars(chart);
        const priceScale = call(chart.series, 'priceScale').value;
        const autoScaleStillEnabled = priceScale && call(priceScale, 'isAutoScale').value === true;
        if (!priceStatus.ok && autoScaleStillEnabled) await refreshVisiblePriceScale(chart, false);

        state.lastAppliedTime = rows[rows.length - 1].value[0];
        state.lastUpdateAt = Date.now();
        emit('TVE_LIVE_UPDATE', {
          rows: rows.length,
          newBars: newRows.length,
          lastTime: state.lastAppliedTime,
          lastIndex: rows[rows.length - 1].index
        });
      } catch (error) {
        state.lastError = String(error?.stack || error);
        emit('TVE_APPLY_ERROR', { message: state.lastError, reloadRequired: true });
      }
    }, 120);
  }

  function queueLiveRefresh() {
    refreshAppliedChart();
  }

  function selectInterval(seconds) {
    if (![1, 5, 10, 15, 20, 30, 45].includes(seconds)) return;
    if (state.mainChartMutated || state.chartLockedForReload) {
      emit('TVE_APPLY_ERROR', {
        message: 'نیاز به Reload صفحه است.',
        reloadRequired: true
      });
      return;
    }
    state.intervalSeconds = seconds;
    state.applied = false;
    state.appliedSeries = null;
    state.appliedSource = null;
    state.appliedModel = null;
    state.appliedInterval = null;
    state.appliedResolution = null;
    updateStats();
  }

  window.addEventListener('message', event => {
    if (event.source !== window || !event.data || event.data.channel !== CHANNEL || event.data.from !== 'content') return;
    const { type, detail = {} } = event.data;
    try {
      switch (type) {
        case 'TVE_DISCOVER': notifyContext(); break;
        case 'TVE_SELECT_INTERVAL': selectInterval(Number(detail.seconds)); break;
        case 'TVE_HISTORY': addHistory(detail.trades); break;
        case 'TVE_TRADE': addTrade(detail.trade, 'live'); updateStats(); break;
        case 'TVE_FEED_STATE': state.feedState = detail.state || state.feedState; updateStats({ feedDetail: detail }); break;
        case 'TVE_SET_CONTINUOUS':
          if (state.mainChartMutated || state.chartLockedForReload) {
            emit('TVE_RELOAD_REQUIRED', { reason: 'تغییر Continuous Open نیاز به Reload دارد.', reloadRequired: true });
          } else {
            state.continuousOpen = !!detail.enabled;
            updateStats();
          }
          break;
        case 'TVE_APPLY':
          applyInitialToMainChart().catch(error => {
            state.lastError = String(error?.stack || error);
            if (state.mainChartMutated) state.applyPhase = 'reload-required';
            emit('TVE_APPLY_RESULT', {
              success: false,
              message: state.lastError,
              reloadRequired: state.mainChartMutated || state.chartLockedForReload,
              chartLockedForReload: state.mainChartMutated || state.chartLockedForReload,
              applyPhase: state.applyPhase
            });
            updateStats();
          });
          break;
        case 'TVE_GET_STATE': notifyContext(); updateStats(); break;
        case 'TVE_STOP': state.applied = false; break;
      }
    } catch (error) {
      state.lastError = String(error?.stack || error);
      emit('TVE_BRIDGE_ERROR', { message: state.lastError, reloadRequired: state.mainChartMutated || state.chartLockedForReload });
    }
  });

  let attempts = 0;
  const discoveryTimer = setInterval(() => {
    attempts++;
    const chart = discoverChart();
    if (chart.ok || attempts >= 20) {
      clearInterval(discoveryTimer);
      notifyContext();
      updateStats();
    }
  }, 500);
})();
