(function () {
  try {
    const inject = () => {
      if (document.getElementById('kcex-sec-main-script-v7')) return;
      const script = document.createElement('script');
      script.id = 'kcex-sec-main-script-v7';
      script.src = chrome.runtime.getURL('injected.js');
      script.async = false;
      (document.head || document.documentElement).appendChild(script);
    };
    if (document.documentElement) inject();
    else window.addEventListener('DOMContentLoaded', inject, { once: true });
  } catch (_) {}
})();
