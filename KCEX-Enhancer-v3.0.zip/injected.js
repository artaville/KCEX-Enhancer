(function () {
  if (window.__KCEX_SECONDS_ENGINE_V7__) return;
  window.__KCEX_SECONDS_ENGINE_V7__ = true;

  // Real-trade second engine: all timeframes are aggregated from actual trade messages.
  const SECOND_INTERVALS = [
    { label: '1s', res: '1S', seconds: 1, defaultFav: true },
    { label: '5s', res: '5S', seconds: 5, defaultFav: true },
    { label: '10s', res: '10S', seconds: 10, defaultFav: true },
    { label: '15s', res: '15S', seconds: 15, defaultFav: true },
    { label: '20s', res: '20S', seconds: 20, defaultFav: true },
    { label: '30s', res: '30S', seconds: 30, defaultFav: true },
    { label: '45s', res: '45S', seconds: 45, defaultFav: true }
  ];

  const DB_NAME = 'kcex_seconds_real_history_v7';
  const DB_VERSION = 1;
  const RETENTION_MS = 24 * 60 * 60 * 1000;
  const RETENTION_SEC = RETENTION_MS / 1000;
  // Keep all 24h locally; cap the initial chart payload to avoid freezing the chart on 1s.
  const MAX_CHART_BARS = 20000;
  const DB_FLUSH_MS = 300;
  const WS_URL = 'wss://www.kcex.com/fapi/edge';
  const FAV_STORAGE_KEY = 'kcex_custom_sec_favs_v7';
  const ACTIVE_STORAGE_KEY = 'kcex_active_sec_resolution_v7';

  const origFetch = window.fetch.bind(window);
  const OrigXHR = window.XMLHttpRequest;
  const NativeWebSocket = window.WebSocket;
  const symbolStores = new Map();
  const chartWebSockets = new Set();
  const wsTemplatesBySymbol = new Map();
  const pendingDbWrites = new Map();
  let dbPromise = null;
  let dbFlushTimer = null;
  let currentActiveResolution = readActiveResolution();
  // Visual state is shared with the independent TradingView module; it does not activate the Original engine.
  let displayedSecondResolution = currentActiveResolution;
  let nativeToolbarLabelState = null;
  let favResolutions = getFavResolutions();
  let cachedKlineChartInstance = null;
  let webpackHooked = false;
  let lastUrlSymbol = getCurrentUrlSymbol();
  let symbolTransitionLockUntil = 0;
  let activeDealSocket = null;
  let activeDealSocketSymbol = null;
  let dealSocketReconnectTimer = null;
  let dealSocketPingTimer = null;
  let dealSocketGeneration = 0;
  let isTogglingReactInterval = false;
  let lastCleanupMs = 0;

  function readActiveResolution() {
    try {
      const saved = localStorage.getItem(ACTIVE_STORAGE_KEY);
      return SECOND_INTERVALS.some(x => x.res === saved) ? saved : null;
    } catch (_) { return null; }
  }

  function saveActiveResolution(res) {
    try {
      if (res) localStorage.setItem(ACTIVE_STORAGE_KEY, res);
      else localStorage.removeItem(ACTIVE_STORAGE_KEY);
    } catch (_) {}
  }

  function getFavResolutions() {
    const defaults = SECOND_INTERVALS.filter(x => x.defaultFav).map(x => x.res);
    try {
      const saved = JSON.parse(localStorage.getItem(FAV_STORAGE_KEY) || 'null');
      if (Array.isArray(saved)) {
        // Make the two newly-added resolutions visible on the toolbar after upgrading.
        return [...new Set([...saved.filter(x => SECOND_INTERVALS.some(y => y.res === x)), '20S', '45S'])];
      }
    } catch (_) {}
    return defaults;
  }

  function saveFavResolutions(list) {
    try { localStorage.setItem(FAV_STORAGE_KEY, JSON.stringify(list)); } catch (_) {}
  }

  function getActiveSecStep() {
    if (!currentActiveResolution) return null;
    const match = String(currentActiveResolution).match(/^(\d+)S$/i);
    return match ? Number(match[1]) : null;
  }

  function getCurrentUrlSymbol() {
    const match = location.pathname.match(/\/exchange\/([A-Z0-9_]+)/i);
    return match ? match[1].toUpperCase() : null;
  }

  function countDecimalsOfNumber(value) {
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return 2;
    const s = n.toFixed(12).replace(/0+$/, '');
    const dot = s.indexOf('.');
    return dot < 0 || dot === s.length - 1 ? 0 : s.length - dot - 1;
  }

  function updatePrecision(store, prices) {
    let decimals = store.decimals || 0;
    for (const value of prices) {
      const p = Number(value);
      if (!Number.isFinite(p) || p <= 0) continue;
      decimals = Math.max(decimals, countDecimalsOfNumber(p));
      if (p < 0.01) decimals = Math.max(decimals, Math.min(12, Math.max(6, Math.ceil(-Math.log10(p)) + 4)));
      else if (p < 1) decimals = Math.max(decimals, 4);
      else decimals = Math.max(decimals, 2);
    }
    store.decimals = Math.min(12, Math.max(2, decimals));
    store.tickSize = Math.pow(10, -store.decimals);
  }

  function roundPrice(value, store) {
    const n = Number(value);
    if (!Number.isFinite(n)) return 0;
    return Number(n.toFixed(store.decimals || Math.max(2, countDecimalsOfNumber(n))));
  }

  function isPriceValidForStore(store, price) {
    const p = Number(price);
    if (!Number.isFinite(p) || p <= 0) return false;
    if (!store.refPrice) return true;
    const ratio = p / store.refPrice;
    return ratio > 0.35 && ratio < 2.85;
  }

  function getStore(symbol) {
    const sym = String(symbol || getCurrentUrlSymbol() || 'BTC_USDT').toUpperCase();
    if (!symbolStores.has(sym)) {
      symbolStores.set(sym, {
        symbol: sym,
        liveSecMap: new Map(),
        sortedSecs: [],
        refPrice: null,
        lastPrice: null,
        decimals: null,
        tickSize: null,
        lastIngestedDealTs: 0,
        socketCutoverTs: 0,
        lastPublishedBarSignature: null,
        lastPublishedChart: null,
        historyLoaded: false,
        dbLoaded: false,
        initPromise: null,
        backfillPromise: null,
        lastBackfillMs: 0,
        backfillGapSuspected: false,
        lastError: null
      });
    }
    return symbolStores.get(sym);
  }

  // ---------- IndexedDB: 24h retention, one-second real-trade buckets only ----------
  function getDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB is unavailable in this browser context.'));
        return;
      }
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('seconds')) {
          const seconds = db.createObjectStore('seconds', { keyPath: ['symbol', 'sec'] });
          seconds.createIndex('bySymbol', 'symbol', { unique: false });
          seconds.createIndex('bySec', 'sec', { unique: false });
        }
        if (!db.objectStoreNames.contains('meta')) {
          db.createObjectStore('meta', { keyPath: 'symbol' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB open failed.'));
      request.onblocked = () => reject(new Error('IndexedDB upgrade is blocked by another KCEX tab.'));
    });
    return dbPromise;
  }

  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB request failed.'));
    });
  }

  function transactionDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed.'));
      tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted.'));
    });
  }

  async function loadPersistedHistory(symbol) {
    const store = getStore(symbol);
    if (store.dbLoaded) return;
    try {
      const db = await getDb();
      const tx = db.transaction(['seconds', 'meta'], 'readonly');
      const rowsPromise = requestResult(tx.objectStore('seconds').index('bySymbol').getAll(IDBKeyRange.only(store.symbol)));
      const metaPromise = requestResult(tx.objectStore('meta').get(store.symbol));
      const [rows, meta] = await Promise.all([rowsPromise, metaPromise]);
      const cutoff = Math.floor((Date.now() - RETENTION_MS) / 1000);
      let maxTradeTs = Number(meta?.lastTradeTs) || 0;
      for (const row of rows || []) {
        if (!row || !Number.isFinite(Number(row.sec)) || Number(row.sec) < cutoff) continue;
        store.liveSecMap.set(Number(row.sec), {
          open: Number(row.open), high: Number(row.high), low: Number(row.low), close: Number(row.close),
          volume: Number(row.volume) || 0, turnover: Number(row.turnover) || 0,
          firstTs: Number(row.firstTs) || Number(row.sec) * 1000,
          lastTs: Number(row.lastTs) || Number(row.sec) * 1000,
          ticks: Number(row.ticks) || 1
        });
        addSortedSec(store, Number(row.sec));
        maxTradeTs = Math.max(maxTradeTs, Number(row.lastTs) || 0);
      }
      store.lastIngestedDealTs = maxTradeTs;
      store.sortedSecs.sort((a, b) => a - b);
      const latestSec = store.sortedSecs[store.sortedSecs.length - 1];
      const latest = latestSec === undefined ? null : [latestSec, store.liveSecMap.get(latestSec)];
      if (latest) {
        store.lastPrice = latest[1].close;
        store.refPrice = latest[1].close;
        updatePrecision(store, [latest[1].open, latest[1].high, latest[1].low, latest[1].close]);
      }
      store.dbLoaded = true;
      store.historyLoaded = true;
      if (store.liveSecMap.size) updateStatusBadge(store);
    } catch (error) {
      store.lastError = 'Storage load: ' + String(error);
      store.dbLoaded = true;
    }
  }

  function queuePersistBucket(store, sec, bucket) {
    const row = {
      symbol: store.symbol,
      sec,
      open: bucket.open,
      high: bucket.high,
      low: bucket.low,
      close: bucket.close,
      volume: bucket.volume,
      turnover: bucket.turnover,
      firstTs: bucket.firstTs,
      lastTs: bucket.lastTs,
      ticks: bucket.ticks
    };
    pendingDbWrites.set(store.symbol + '|' + sec, row);
    if (!dbFlushTimer) dbFlushTimer = setTimeout(flushPendingDbWrites, DB_FLUSH_MS);
  }

  async function flushPendingDbWrites() {
    dbFlushTimer = null;
    if (!pendingDbWrites.size) return;
    const rows = [...pendingDbWrites.values()];
    pendingDbWrites.clear();
    try {
      const db = await getDb();
      const tx = db.transaction(['seconds', 'meta'], 'readwrite');
      const seconds = tx.objectStore('seconds');
      const metaStore = tx.objectStore('meta');
      const metaBySymbol = new Map();
      for (const row of rows) {
        seconds.put(row);
        metaBySymbol.set(row.symbol, Math.max(metaBySymbol.get(row.symbol) || 0, row.lastTs || 0));
      }
      for (const [symbol, lastTradeTs] of metaBySymbol) {
        const store = getStore(symbol);
        metaStore.put({ symbol, lastTradeTs: Math.max(store.lastIngestedDealTs || 0, lastTradeTs) });
      }
      await transactionDone(tx);
    } catch (error) {
      // Keep the newest row per bucket queued so a temporary quota/transaction issue can retry.
      for (const row of rows) pendingDbWrites.set(row.symbol + '|' + row.sec, row);
      for (const store of symbolStores.values()) store.lastError = 'Storage write: ' + String(error);
    }
    if (pendingDbWrites.size && !dbFlushTimer) dbFlushTimer = setTimeout(flushPendingDbWrites, 1500);
  }

  async function cleanupOldHistory() {
    const now = Date.now();
    if (now - lastCleanupMs < 60 * 60 * 1000) return;
    lastCleanupMs = now;
    const cutoff = Math.floor((now - RETENTION_MS) / 1000);
    try {
      const db = await getDb();
      const tx = db.transaction(['seconds'], 'readwrite');
      const store = tx.objectStore('seconds');
      const cursorRequest = store.openCursor();
      cursorRequest.onsuccess = () => {
        const cursor = cursorRequest.result;
        if (!cursor) return;
        if (Number(cursor.value.sec) < cutoff) cursor.delete();
        cursor.continue();
      };
      await transactionDone(tx);
      for (const cached of symbolStores.values()) {
        for (const sec of cached.liveSecMap.keys()) {
          if (sec < cutoff) cached.liveSecMap.delete(sec);
        }
        cached.sortedSecs = cached.sortedSecs.filter(sec => sec >= cutoff);
      }
    } catch (_) {}
  }

  try {
    if (navigator.storage?.persist) navigator.storage.persist().catch(() => {});
  } catch (_) {}

  // ---------- Real trade ingestion ----------
  function normalizeTradeTime(value) {
    let t = Number(value);
    if (!Number.isFinite(t) || t <= 0) return 0;
    if (t < 1e12) t *= 1000;
    return t;
  }

  function recordLiveTrade(symbol, trade, source) {
    if (!symbol || !trade) return false;
    const store = getStore(symbol);
    const t = normalizeTradeTime(trade.t);
    const p = Number(trade.p);
    const v = Number(trade.v) || 0;
    if (!t || !Number.isFinite(p) || p <= 0 || !Number.isFinite(v) || v < 0) return false;
    if (source === 'ws' && store.socketCutoverTs && t <= store.socketCutoverTs) return false;

    // The payload already identifies the symbol; do not discard legitimate fast market moves
    // merely because they are far from the last locally cached price.
    updatePrecision(store, [p]);
    const sec = Math.floor(t / 1000);
    let bucket = store.liveSecMap.get(sec);

    if (!bucket) {
      bucket = {
        open: p, high: p, low: p, close: p,
        volume: v, turnover: p * v,
        firstTs: t, lastTs: t, ticks: 1
      };
    } else {
      if (t < bucket.firstTs) {
        bucket.firstTs = t;
        bucket.open = p;
      }
      if (t >= bucket.lastTs) {
        bucket.lastTs = t;
        bucket.close = p;
      }
      bucket.high = Math.max(bucket.high, p);
      bucket.low = Math.min(bucket.low, p);
      bucket.volume += v;
      bucket.turnover += p * v;
      bucket.ticks += 1;
    }

    if (!store.liveSecMap.has(sec)) addSortedSec(store, sec);
    store.liveSecMap.set(sec, bucket);
    store.lastIngestedDealTs = Math.max(store.lastIngestedDealTs || 0, t);
    if (!store.lastPrice || t >= (store.lastPriceTs || 0)) {
      store.lastPrice = p;
      store.lastPriceTs = t;
    }
    store.refPrice = store.lastPrice || p;
    queuePersistBucket(store, sec, bucket);

    const cutoff = Math.floor((Date.now() - RETENTION_MS) / 1000);
    for (const oldSec of store.liveSecMap.keys()) {
      if (oldSec < cutoff) store.liveSecMap.delete(oldSec);
    }
    store.sortedSecs = store.sortedSecs.filter(oldSec => oldSec >= cutoff);
    return true;
  }

  function parseDealList(data) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.deals)) return data.deals;
    if (data && typeof data === 'object' && data.p !== undefined) return [data];
    return [];
  }

  async function backfillRecentDeals(symbol, cutoverTs) {
    const store = getStore(symbol);
    if (store.backfillPromise) return store.backfillPromise;
    store.backfillPromise = (async () => {
      try {
        const res = await origFetch(`/fapi/v1/contract/deals/${encodeURIComponent(store.symbol)}?__kcex_internal=1`, {
          credentials: 'same-origin', cache: 'no-store'
        });
        const json = await res.json();
        const rows = parseDealList(json?.data);
        if (!json?.success || !rows.length) return;

        const before = store.lastIngestedDealTs || 0;
        const normalized = rows.map(d => ({ d, t: normalizeTradeTime(d?.t) }))
          .filter(x => x.t > before && x.t <= cutoverTs)
          .sort((a, b) => a.t - b.t);

        // The endpoint has been observed returning at most 100 latest trades.
        // If all 100 are newer than our saved checkpoint, older missing trades may exist.
        const validRows = rows.map(d => ({ d, t: normalizeTradeTime(d?.t) }))
          .filter(x => x.t > 0).sort((a, b) => a.t - b.t);
        if (validRows.length >= 100 && (!before || validRows[0].t > before + 1500)) {
          store.backfillGapSuspected = true;
        }

        for (const item of normalized) recordLiveTrade(store.symbol, item.d, 'rest');
        store.lastBackfillMs = Date.now();
        updateStatusBadge(store);
        // The chart may have requested history before the REST snapshot completed.
        if (currentActiveResolution && getCurrentUrlSymbol() === store.symbol) {
          setTimeout(() => {
            if (currentActiveResolution && getCurrentUrlSymbol() === store.symbol) applySecondBarsToOriginalChart();
          }, 80);
        }
      } catch (error) {
        store.lastError = 'REST recovery: ' + String(error);
      } finally {
        store.backfillPromise = null;
      }
    })();
    return store.backfillPromise;
  }

  // ---------- Dedicated KCEX futures deals WebSocket ----------
  function stopDealsSocket() {
    dealSocketGeneration++;
    if (dealSocketReconnectTimer) clearTimeout(dealSocketReconnectTimer);
    if (dealSocketPingTimer) clearInterval(dealSocketPingTimer);
    dealSocketReconnectTimer = null;
    dealSocketPingTimer = null;
    if (activeDealSocket) {
      try { activeDealSocket.close(1000, 'KCEX seconds engine stopped'); } catch (_) {}
    }
    activeDealSocket = null;
    activeDealSocketSymbol = null;
  }

  function scheduleDealsReconnect(symbol, generation) {
    if (generation !== dealSocketGeneration) return;
    if (!currentActiveResolution || getCurrentUrlSymbol() !== symbol) return;
    if (dealSocketReconnectTimer) clearTimeout(dealSocketReconnectTimer);
    dealSocketReconnectTimer = setTimeout(() => connectDealsSocket(symbol), 1800);
  }

  function connectDealsSocket(symbol) {
    const sym = String(symbol || '').toUpperCase();
    if (!sym || !currentActiveResolution) return;
    if (activeDealSocket && activeDealSocketSymbol === sym &&
        (activeDealSocket.readyState === WebSocket.OPEN || activeDealSocket.readyState === WebSocket.CONNECTING)) return;

    stopDealsSocket();
    const generation = dealSocketGeneration;
    activeDealSocketSymbol = sym;
    let ws;
    try {
      ws = new NativeWebSocket(WS_URL);
      activeDealSocket = ws;
    } catch (error) {
      const store = getStore(sym);
      store.lastError = 'WebSocket create: ' + String(error);
      scheduleDealsReconnect(sym, generation);
      return;
    }

    ws.addEventListener('open', () => {
      if (generation !== dealSocketGeneration) return;
      // Define the cutover immediately before subscribing: REST covers trades at/before it,
      // the live socket covers trades after it. This avoids replaying pre-ack WS messages twice.
      const store = getStore(sym);
      store.socketCutoverTs = Date.now();
      try {
        ws.send(JSON.stringify({ method: 'sub.deal', param: { symbol: sym, compress: false } }));
      } catch (_) {}
      if (dealSocketPingTimer) clearInterval(dealSocketPingTimer);
      dealSocketPingTimer = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          try { ws.send(JSON.stringify({ method: 'ping' })); } catch (_) {}
        }
      }, 10000);
    });

    ws.addEventListener('message', event => {
      if (generation !== dealSocketGeneration) return;
      let msg;
      try {
        if (typeof event.data !== 'string') return;
        msg = JSON.parse(event.data);
      } catch (_) { return; }

      if (msg?.channel === 'rs.sub.deal' && msg.data === 'success') {
        const store = getStore(sym);
        // A cutover separates REST recovery (<= cutover) from live WS events (> cutover).
        const cutover = store.socketCutoverTs || Date.now();
        backfillRecentDeals(sym, cutover);
      } else if (msg?.channel === 'push.deal') {
        const messageSymbol = String(msg.symbol || msg.data?.symbol || sym).toUpperCase();
        if (messageSymbol !== sym) return;
        for (const deal of parseDealList(msg.data)) recordLiveTrade(sym, deal, 'ws');
      } else if (msg?.channel === 'rs.error') {
        getStore(sym).lastError = 'WebSocket subscription error: ' + String(msg.data || 'unknown');
      }
    });

    ws.addEventListener('error', () => {
      getStore(sym).lastError = 'WebSocket connection error';
    });

    ws.addEventListener('close', () => {
      if (dealSocketPingTimer) clearInterval(dealSocketPingTimer);
      dealSocketPingTimer = null;
      if (activeDealSocket === ws) activeDealSocket = null;
      scheduleDealsReconnect(sym, generation);
    });
  }

  async function ensureSymbolEngine(symbol) {
    const store = getStore(symbol);
    if (store.initPromise) return store.initPromise;
    store.initPromise = (async () => {
      await loadPersistedHistory(store.symbol);
      await cleanupOldHistory();
      if (currentActiveResolution && getCurrentUrlSymbol() === store.symbol) connectDealsSocket(store.symbol);
      return store;
    })();
    try { return await store.initPromise; }
    finally { store.initPromise = null; }
  }

  function addSortedSec(store, sec) {
    const keys = store.sortedSecs || (store.sortedSecs = []);
    const last = keys.length - 1;
    if (last < 0 || sec > keys[last]) {
      keys.push(sec);
      return;
    }
    let low = 0;
    let high = keys.length;
    while (low < high) {
      const mid = (low + high) >>> 1;
      if (keys[mid] < sec) low = mid + 1;
      else high = mid;
    }
    if (keys[low] !== sec) keys.splice(low, 0, sec);
  }

  function getPreviousCloseBeforeBucket(store, bucketSec) {
    const keys = store.sortedSecs || [];
    let low = 0;
    let high = keys.length;
    // Find the first second >= bucketSec; its predecessor is the last prior trade-second.
    while (low < high) {
      const mid = (low + high) >>> 1;
      if (keys[mid] < bucketSec) low = mid + 1;
      else high = mid;
    }
    for (let i = low - 1; i >= 0; i--) {
      const one = store.liveSecMap.get(keys[i]);
      const close = Number(one?.close);
      if (Number.isFinite(close) && close > 0) return close;
    }
    return null;
  }

  function getPreviousCloseForAdjacentBucket(store, bucketSec, secStep) {
    const keys = store.sortedSecs || [];
    let low = 0;
    let high = keys.length;
    // Find the last real-trade second strictly before this interval.
    while (low < high) {
      const mid = (low + high) >>> 1;
      if (keys[mid] < bucketSec) low = mid + 1;
      else high = mid;
    }
    const previousSec = keys[low - 1];
    if (!Number.isFinite(previousSec)) return null;
    const previousBucket = Math.floor(previousSec / secStep) * secStep;
    // A previous close may be used as the display Open only when the immediately
    // preceding interval actually has data. Never bridge an unknown time gap.
    if (previousBucket !== bucketSec - secStep) return null;
    const close = Number(store.liveSecMap.get(previousSec)?.close);
    return Number.isFinite(close) && close > 0 ? close : null;
  }

  // ---------- Aggregate 1-second real bars into any requested second interval ----------
  function aggregateSecondBuckets(symbol, secStep, startSec, endSec) {
    const store = getStore(symbol);
    const groups = new Map();
    const sorted = [...store.liveSecMap.entries()].sort((a, b) => a[0] - b[0]);

    for (const [sec, one] of sorted) {
      if (startSec !== undefined && sec < startSec) continue;
      if (endSec !== undefined && sec > endSec) continue;
      const bucketSec = Math.floor(sec / secStep) * secStep;
      let bar = groups.get(bucketSec);
      if (!bar) {
        bar = {
          symbol: store.symbol,
          bucketSec,
          time: bucketSec * 1000,
          timestamp: bucketSec * 1000,
          open: one.open,
          high: one.high,
          low: one.low,
          close: one.close,
          volume: one.volume,
          turnover: one.turnover || 0,
          firstTs: one.firstTs,
          lastTs: one.lastTs,
          ticks: one.ticks || 1
        };
        groups.set(bucketSec, bar);
      } else {
        if (one.firstTs < bar.firstTs) {
          bar.firstTs = one.firstTs;
          bar.open = one.open;
        }
        if (one.lastTs >= bar.lastTs) {
          bar.lastTs = one.lastTs;
          bar.close = one.close;
        }
        bar.high = Math.max(bar.high, one.high);
        bar.low = Math.min(bar.low, one.low);
        bar.volume += one.volume;
        bar.turnover += one.turnover || 0;
        bar.ticks += one.ticks || 1;
      }
    }

    const observed = [...groups.values()].sort((a, b) => a.time - b.time);
    if (!observed.length) return [];

    // Do not manufacture bars in intervals for which no trades were captured.
    // A missing bucket is a real visual gap, not a flat candle and not a reason
    // to connect the next observed candle to an old close with a giant wick/body.
    let hadGap = false;
    const result = observed.map((bar, index) => {
      if (index > 0 && bar.bucketSec - observed[index - 1].bucketSec > secStep) hadGap = true;

      const realOpen = roundPrice(bar.open, store);
      const realHigh = roundPrice(bar.high, store);
      const realLow = roundPrice(bar.low, store);
      const realClose = roundPrice(bar.close, store);
      const adjacentPreviousClose = getPreviousCloseForAdjacentBucket(store, bar.bucketSec, secStep);
      const displayOpen = adjacentPreviousClose === null
        ? realOpen
        : roundPrice(adjacentPreviousClose, store);
      const displayHigh = roundPrice(Math.max(realHigh, displayOpen, realClose), store);
      const displayLow = roundPrice(Math.min(realLow, displayOpen, realClose), store);

      return {
        symbol: bar.symbol,
        bucketSec: bar.bucketSec,
        time: bar.time,
        timestamp: bar.timestamp,
        open: displayOpen,
        high: displayHigh,
        low: displayLow,
        close: realClose,
        volume: bar.volume,
        turnover: bar.turnover,
        realOpen,
        realHigh,
        realLow,
        realClose,
        rawOpen: realOpen,
        rawHigh: realHigh,
        rawLow: realLow,
        rawClose: realClose
      };
    });

    if (hadGap && !store.backfillGapSuspected) {
      store.backfillGapSuspected = true;
      updateStatusBadge(store);
    }
    return result;
  }

  function getOrBuildBucketBar(symbol, secStep, bucketSec) {
    const store = getStore(symbol);
    let firstTs = Infinity;
    let lastTs = -Infinity;
    let open = null;
    let close = null;
    let high = -Infinity;
    let low = Infinity;
    let volume = 0;
    let turnover = 0;
    let ticks = 0;

    // At most 45 one-second buckets are inspected for any supported interval.
    for (let sec = bucketSec; sec < bucketSec + secStep; sec++) {
      const one = store.liveSecMap.get(sec);
      if (!one) continue;
      if (one.firstTs < firstTs) {
        firstTs = one.firstTs;
        open = one.open;
      }
      if (one.lastTs >= lastTs) {
        lastTs = one.lastTs;
        close = one.close;
      }
      high = Math.max(high, one.high);
      low = Math.min(low, one.low);
      volume += one.volume;
      turnover += one.turnover || 0;
      ticks += one.ticks || 1;
    }

    if (open === null || close === null) {
      // Keep a short, immediately-adjacent no-trade interval visually flat, but
      // never draw a placeholder across a period with missing market data.
      const previousClose = getPreviousCloseForAdjacentBucket(store, bucketSec, secStep);
      if (previousClose === null || !Number.isFinite(Number(previousClose)) || Number(previousClose) <= 0) return null;
      const flatPrice = roundPrice(previousClose, store);
      return {
        symbol: store.symbol,
        bucketSec,
        time: bucketSec * 1000,
        timestamp: bucketSec * 1000,
        open: flatPrice,
        high: flatPrice,
        low: flatPrice,
        close: flatPrice,
        volume: 0,
        turnover: 0,
        ticks: 0,
        realOpen: null,
        realHigh: null,
        realLow: null,
        realClose: null,
        rawOpen: null,
        rawHigh: null,
        rawLow: null,
        rawClose: null,
        isProvisional: true
      };
    }
    const realOpen = roundPrice(open, store);
    const realHigh = roundPrice(high, store);
    const realLow = roundPrice(low, store);
    const realClose = roundPrice(close, store);
    const previousClose = getPreviousCloseForAdjacentBucket(store, bucketSec, secStep);
    if (previousClose === null && getPreviousCloseBeforeBucket(store, bucketSec) !== null && !store.backfillGapSuspected) {
      store.backfillGapSuspected = true;
      updateStatusBadge(store);
    }
    const displayOpen = previousClose === null ? realOpen : roundPrice(previousClose, store);
    return {
      symbol: store.symbol,
      bucketSec,
      time: bucketSec * 1000,
      timestamp: bucketSec * 1000,
      // The chart receives a continuous Open; Close remains the last real trade.
      // High/Low include the display Open so the candle remains valid/renderable.
      open: displayOpen,
      high: roundPrice(Math.max(realHigh, displayOpen, realClose), store),
      low: roundPrice(Math.min(realLow, displayOpen, realClose), store),
      close: realClose,
      volume,
      turnover,
      ticks,
      realOpen,
      realHigh,
      realLow,
      realClose,
      rawOpen: realOpen,
      rawHigh: realHigh,
      rawLow: realLow,
      rawClose: realClose,
      isProvisional: false
    };
  }

  function buildKlinePayload(symbol, secStep, requestUrl) {
    const nowSec = Math.floor(Date.now() / 1000);
    const cutoff = nowSec - RETENTION_SEC;
    let startSec = cutoff;
    let endSec = nowSec;
    let limit = MAX_CHART_BARS;
    try {
      const url = new URL(requestUrl, location.origin);
      if (url.searchParams.has('start')) startSec = Math.max(cutoff, Number(url.searchParams.get('start')) || cutoff);
      if (url.searchParams.has('end')) endSec = Math.min(nowSec + 2, Number(url.searchParams.get('end')) || nowSec);
      if (url.searchParams.has('limit')) limit = Math.min(MAX_CHART_BARS, Math.max(1, Number(url.searchParams.get('limit')) || MAX_CHART_BARS));
    } catch (_) {}

    const bars = aggregateSecondBuckets(symbol, secStep, startSec, endSec).slice(-limit);
    const time = [], open = [], high = [], low = [], close = [], vol = [], amount = [];
    const realOpen = [], realHigh = [], realLow = [], realClose = [];
    for (const bar of bars) {
      time.push(Math.floor(bar.time / 1000));
      open.push(bar.open); high.push(bar.high); low.push(bar.low); close.push(bar.close);
      realOpen.push(bar.realOpen); realHigh.push(bar.realHigh);
      realLow.push(bar.realLow); realClose.push(bar.realClose);
      vol.push(bar.volume); amount.push(bar.turnover);
    }
    return {
      success: true,
      code: 0,
      data: {
        time, open, close, high, low, vol, amount,
        // Original trade-derived OHLC, separate from the continuous display candles.
        realOpen, realClose, realHigh, realLow
      }
    };
  }

  function isKlineHistoryUrl(rawUrl) {
    if (!rawUrl || typeof rawUrl !== 'string' || rawUrl.includes('__kcex_internal=1')) return false;
    try {
      const url = new URL(rawUrl, location.origin);
      return /\/fapi\/v1\/contract\/kline\/[A-Z0-9_]+$/i.test(url.pathname) &&
        !url.pathname.includes('/extreme_price/') && !url.pathname.includes('/first_windows/');
    } catch (_) { return false; }
  }

  function getSymbolFromKlineUrl(rawUrl) {
    try {
      const url = new URL(rawUrl, location.origin);
      const match = url.pathname.match(/\/contract\/kline\/([A-Z0-9_]+)$/i);
      return match ? match[1].toUpperCase() : getCurrentUrlSymbol();
    } catch (_) { return getCurrentUrlSymbol(); }
  }

  // ---------- Intercept the page's chart history requests only while seconds are selected ----------
  window.fetch = async function (input, init) {
    const requestUrl = typeof input === 'string' ? input : (input && input.url ? input.url : '');
    const secStep = getActiveSecStep();
    if (secStep && isKlineHistoryUrl(requestUrl)) {
      const symbol = getSymbolFromKlineUrl(requestUrl);
      if (symbol) {
        await ensureSymbolEngine(symbol);
        const payload = buildKlinePayload(symbol, secStep, requestUrl);
        return new Response(JSON.stringify(payload), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    }
    return origFetch(input, init);
  };

  window.XMLHttpRequest = function () {
    const xhr = new OrigXHR();
    let requestUrl = '';
    const originalOpen = xhr.open;
    const originalSend = xhr.send;

    xhr.open = function (method, url, ...rest) {
      requestUrl = String(url || '');
      return originalOpen.call(this, method, url, ...rest);
    };

    xhr.send = function (body) {
      const secStep = getActiveSecStep();
      if (secStep && isKlineHistoryUrl(requestUrl)) {
        const symbol = getSymbolFromKlineUrl(requestUrl);
        ensureSymbolEngine(symbol).then(() => {
          const payload = buildKlinePayload(symbol, secStep, requestUrl);
          const jsonText = JSON.stringify(payload);
          try {
            Object.defineProperty(xhr, 'readyState', { configurable: true, get: () => 4 });
            Object.defineProperty(xhr, 'status', { configurable: true, get: () => 200 });
            Object.defineProperty(xhr, 'statusText', { configurable: true, get: () => 'OK' });
            Object.defineProperty(xhr, 'responseURL', { configurable: true, get: () => requestUrl });
            Object.defineProperty(xhr, 'responseText', { configurable: true, get: () => jsonText });
            Object.defineProperty(xhr, 'response', { configurable: true, get: () => xhr.responseType === 'json' ? payload : jsonText });
          } catch (_) {}
          if (typeof xhr.onreadystatechange === 'function') {
            try { xhr.onreadystatechange(new Event('readystatechange')); } catch (_) {}
          }
          xhr.dispatchEvent(new Event('readystatechange'));
          if (typeof xhr.onload === 'function') {
            try { xhr.onload(new ProgressEvent('load')); } catch (_) {}
          }
          xhr.dispatchEvent(new ProgressEvent('load'));
          xhr.dispatchEvent(new ProgressEvent('loadend'));
        }).catch(() => originalSend.call(xhr, body));
        return;
      }
      return originalSend.call(this, body);
    };

    return xhr;
  };
  window.XMLHttpRequest.prototype = OrigXHR.prototype;
  Object.assign(window.XMLHttpRequest, OrigXHR);

  // ---------- Original chart discovery and formatting ----------
  function isKlineChartObject(obj) {
    return !!obj && typeof obj === 'object' &&
      typeof obj.updateData === 'function' &&
      typeof obj.applyNewData === 'function' &&
      typeof obj.getDataList === 'function';
  }

  function configureOriginalChartFormatter(chart) {
    if (!chart || chart.__kcexSecondsFormatterV7__) return;
    chart.__kcexSecondsFormatterV7__ = true;
    try {
      if (typeof chart.setCustomApi === 'function') {
        chart.setCustomApi({
          formatDate: (_formatObject, timestamp, format, type) => {
            const d = new Date(timestamp);
            const pad = n => String(n).padStart(2, '0');
            const date = `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())}`;
            const time = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
            if (type === 0 || (format && String(format).includes('YYYY'))) return `${date} ${time}`;
            return time;
          }
        });
      }
    } catch (_) {}

    try {
      const tsStore = chart._chartStore && (chart._chartStore._timeScaleStore ||
        (typeof chart._chartStore.timeScaleStore === 'function' && chart._chartStore.timeScaleStore()));
      if (tsStore && typeof tsStore.formatDate === 'function' && !tsStore.__kcexSecondsFormatterV7__) {
        tsStore.__kcexSecondsFormatterV7__ = true;
        const original = tsStore.formatDate.bind(tsStore);
        tsStore.formatDate = function (timestamp, format, type) {
          if (!currentActiveResolution) return original(timestamp, format, type);
          const d = new Date(timestamp);
          const pad = n => String(n).padStart(2, '0');
          const date = `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())}`;
          const time = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
          return type === 0 || (format && String(format).includes('YYYY')) ? `${date} ${time}` : time;
        };
      }
    } catch (_) {}

    try {
      if (!chart.__kcexSecondsUpdateWrappedV7__) {
        chart.__kcexSecondsUpdateWrappedV7__ = true;
        const originalUpdate = chart.updateData.bind(chart);
        chart.__kcexOriginalUpdateV7__ = originalUpdate;
        chart.updateData = function (data) {
          if (getActiveSecStep() && data && !data.__kcexDirectV7__) return;
          return originalUpdate(data);
        };
      }
    } catch (_) {}
  }

  // Version 2.2: continuous-open display candles; close and volume stay trade-derived.
  function configureSecondCandleStyles(chart) {
    if (!chart || chart.__kcexSecondCandleStylesV22__) return;
    if (typeof chart.setStyles !== 'function') return;
    try {
      chart.setStyles({
        candle: {
          bar: {
            // Continuous Open now matches the previous Close; keep strong close-to-close colors.
            compareRule: 'previous_close',
            upColor: '#20B889',
            downColor: '#ED586E',
            noChangeColor: '#8195A0',
            upBorderColor: '#20B889',
            downBorderColor: '#ED586E',
            noChangeBorderColor: '#8195A0',
            upWickColor: '#20B889',
            downWickColor: '#ED586E',
            noChangeWickColor: '#8195A0'
          }
        }
      });
      chart.__kcexSecondCandleStylesV22__ = true;
    } catch (_) {}
  }

  // Wrap KCEX chart sockets so their kline updates can be replaced with our real-trade buckets.
  // The dedicated deals socket uses NativeWebSocket directly and bypasses this chart-only wrapper.
  function transformIncomingChartWsData(raw) {
    if (typeof raw !== 'string' || !raw.startsWith('{')) return raw;
    try {
      const msg = JSON.parse(raw);
      if (msg.__kcexSyntheticV7) return raw;
      const channel = String(msg.channel || '');
      const symbol = String(msg.symbol || msg.data?.symbol || '').toUpperCase();
      if (!symbol || !channel.toLowerCase().includes('kline') || msg.data?.t === undefined) return raw;
      wsTemplatesBySymbol.set(symbol, JSON.parse(raw));
      const step = getActiveSecStep();
      if (!step || symbol !== getCurrentUrlSymbol()) return raw;
      const nowSec = Math.floor(Date.now() / 1000);
      const bucketSec = Math.floor(nowSec / step) * step;
      const bar = getOrBuildBucketBar(symbol, step, bucketSec);
      if (!bar) return raw;
      msg.__kcexSyntheticV7 = true;
      msg.symbol = symbol;
      msg.ts = Date.now();
      msg.data.symbol = symbol;
      msg.data.interval = 'Min1';
      msg.data.t = bar.bucketSec;
      msg.data.o = bar.open;
      msg.data.h = bar.high;
      msg.data.l = bar.low;
      msg.data.c = bar.close;
      msg.data.ro = bar.open;
      msg.data.rh = bar.high;
      msg.data.rl = bar.low;
      msg.data.rc = bar.close;
      msg.data.realOpen = bar.realOpen;
      msg.data.realHigh = bar.realHigh;
      msg.data.realLow = bar.realLow;
      msg.data.realClose = bar.realClose;
      msg.data.isProvisional = Boolean(bar.isProvisional);
      msg.data.q = bar.volume;
      msg.data.a = bar.turnover;
      return JSON.stringify(msg);
    } catch (_) { return raw; }
  }

  try {
    window.WebSocket = function (url, protocols) {
      const ws = protocols !== undefined ? new NativeWebSocket(url, protocols) : new NativeWebSocket(url);
      chartWebSockets.add(ws);
      const listeners = [];
      let onMessage = null;
      const originalAdd = ws.addEventListener.bind(ws);
      const originalRemove = ws.removeEventListener.bind(ws);

      originalAdd('message', rawEvent => {
        const transformed = transformIncomingChartWsData(rawEvent.data);
        const event = transformed === rawEvent.data ? rawEvent : new MessageEvent('message', {
          data: transformed,
          origin: rawEvent.origin,
          lastEventId: rawEvent.lastEventId,
          source: rawEvent.source,
          ports: rawEvent.ports
        });
        if (typeof onMessage === 'function') {
          try { onMessage.call(ws, event); } catch (_) {}
        }
        for (const listener of listeners.slice()) {
          try {
            if (typeof listener === 'function') listener.call(ws, event);
            else if (listener && typeof listener.handleEvent === 'function') listener.handleEvent(event);
          } catch (_) {}
        }
      });

      ws.addEventListener = function (type, listener, options) {
        if (type === 'message' && listener) {
          if (!listeners.includes(listener)) listeners.push(listener);
          return;
        }
        return originalAdd(type, listener, options);
      };
      ws.removeEventListener = function (type, listener, options) {
        if (type === 'message' && listener) {
          const index = listeners.indexOf(listener);
          if (index >= 0) listeners.splice(index, 1);
          return;
        }
        return originalRemove(type, listener, options);
      };
      Object.defineProperty(ws, 'onmessage', {
        configurable: true,
        enumerable: true,
        get: () => onMessage,
        set: fn => { onMessage = fn; }
      });
      ws.__kcexDispatchSyntheticV7 = function (payload) {
        if (ws.readyState !== NativeWebSocket.OPEN) return;
        const event = new MessageEvent('message', { data: payload });
        if (typeof onMessage === 'function') {
          try { onMessage.call(ws, event); } catch (_) {}
        }
        for (const listener of listeners.slice()) {
          try {
            if (typeof listener === 'function') listener.call(ws, event);
            else if (listener && typeof listener.handleEvent === 'function') listener.handleEvent(event);
          } catch (_) {}
        }
      };
      originalAdd('close', () => chartWebSockets.delete(ws));
      return ws;
    };
    window.WebSocket.prototype = NativeWebSocket.prototype;
    Object.assign(window.WebSocket, NativeWebSocket);
  } catch (_) {}

  function dispatchSyntheticKlineToChart(symbol, bar) {
    const template = wsTemplatesBySymbol.get(symbol);
    const payload = template ? JSON.parse(JSON.stringify(template)) : {
      channel: 'push.kline',
      symbol,
      ts: Date.now(),
      data: { symbol, interval: 'Min1' }
    };
    payload.__kcexSyntheticV7 = true;
    payload.symbol = symbol;
    payload.ts = Date.now();
    payload.data = payload.data || {};
    payload.data.symbol = symbol;
    payload.data.interval = 'Min1';
    payload.data.t = bar.bucketSec;
    payload.data.o = bar.open;
    payload.data.h = bar.high;
    payload.data.l = bar.low;
    payload.data.c = bar.close;
    payload.data.ro = bar.open;
    payload.data.rh = bar.high;
    payload.data.rl = bar.low;
    payload.data.rc = bar.close;
    payload.data.realOpen = bar.realOpen;
    payload.data.realHigh = bar.realHigh;
    payload.data.realLow = bar.realLow;
    payload.data.realClose = bar.realClose;
    payload.data.isProvisional = Boolean(bar.isProvisional);
    payload.data.q = bar.volume;
    payload.data.a = bar.turnover;
    const serialized = JSON.stringify(payload);
    for (const socket of chartWebSockets) {
      if (socket && socket.readyState === NativeWebSocket.OPEN && typeof socket.__kcexDispatchSyntheticV7 === 'function') {
        socket.__kcexDispatchSyntheticV7(serialized);
      }
    }
  }

  // Preserve the original right-axis second countdown display.
  function getFormattedSecondCountdown() {
    const secStep = getActiveSecStep();
    if (!secStep) return null;
    const nowSec = Math.floor(Date.now() / 1000);
    const remaining = (secStep - (nowSec % secStep)) % secStep;
    const display = secStep === 1 ? 1 : remaining;
    return '00:' + String(display).padStart(2, '0');
  }

  try {
    const canvasProto = CanvasRenderingContext2D.prototype;
    const originalFillText = canvasProto.fillText;
    const originalStrokeText = canvasProto.strokeText;

    function isRightAxisCountdown(ctx, text) {
      if (!currentActiveResolution || typeof text !== 'string') return false;
      if (!/^(00:)?00:[0-5]\d$/.test(text.trim())) return false;
      const canvas = ctx && ctx.canvas;
      if (!canvas) return false;
      const width = canvas.clientWidth || canvas.width;
      const height = canvas.clientHeight || canvas.height;
      return width <= 180 && height >= 100;
    }

    canvasProto.fillText = function (text, x, y, maxWidth) {
      if (isRightAxisCountdown(this, text)) text = getFormattedSecondCountdown() || text;
      return maxWidth === undefined
        ? originalFillText.call(this, text, x, y)
        : originalFillText.call(this, text, x, y, maxWidth);
    };

    canvasProto.strokeText = function (text, x, y, maxWidth) {
      if (isRightAxisCountdown(this, text)) text = getFormattedSecondCountdown() || text;
      return maxWidth === undefined
        ? originalStrokeText.call(this, text, x, y)
        : originalStrokeText.call(this, text, x, y, maxWidth);
    };
  } catch (_) {}

  function tryHookWebpackKlineCharts() {
    if (webpackHooked && cachedKlineChartInstance) return;
    const chunkKey = Object.keys(window).find(k => k.startsWith('webpackChunk') && !k.includes('tradingview'));
    const chunkArray = chunkKey ? window[chunkKey] : null;
    if (!Array.isArray(chunkArray)) return;
    webpackHooked = true;
    try {
      chunkArray.push([
        ['__kcex_seconds_v7_' + Date.now()], {}, function (webpackRequire) {
          try {
            const cache = webpackRequire && webpackRequire.c;
            if (!cache) return;
            for (const id of Object.keys(cache)) {
              const exp = cache[id] && cache[id].exports;
              if (!exp || typeof exp !== 'object') continue;
              for (const candidate of [exp, exp.default].filter(Boolean)) {
                if (typeof candidate.init !== 'function' || typeof candidate.dispose !== 'function' || candidate.__kcexSecondsInitWrappedV7__) continue;
                candidate.__kcexSecondsInitWrappedV7__ = true;
                const originalInit = candidate.init.bind(candidate);
                candidate.init = function (dom, styles) {
                  const instance = originalInit(dom, styles);
                  if (isKlineChartObject(instance)) {
                    cachedKlineChartInstance = instance;
                    configureOriginalChartFormatter(instance);
                  }
                  return instance;
                };
                try {
                  const dummy = document.createElement('div');
                  dummy.style.cssText = 'width:100px;height:100px;position:fixed;left:-9999px;top:-9999px;visibility:hidden;';
                  document.documentElement.appendChild(dummy);
                  const dummyChart = originalInit(dummy);
                  if (dummyChart) {
                    const proto = Object.getPrototypeOf(dummyChart);
                    if (proto && !proto.__kcexSecondsProtoHookedV7__) {
                      proto.__kcexSecondsProtoHookedV7__ = true;
                      ['updateData', 'applyNewData', 'getDataList', 'resize'].forEach(name => {
                        if (typeof proto[name] !== 'function') return;
                        const original = proto[name];
                        proto[name] = function (...args) {
                          if (this !== dummyChart && isKlineChartObject(this)) {
                            cachedKlineChartInstance = this;
                            configureOriginalChartFormatter(this);
                          }
                          return original.apply(this, args);
                        };
                      });
                    }
                  }
                  candidate.dispose(dummy);
                  dummy.remove();
                } catch (_) {}
              }
            }
          } catch (_) {}
        }
      ]);
    } catch (_) {}
  }

  function findOriginalKlineChartInstance() {
    if (cachedKlineChartInstance && isKlineChartObject(cachedKlineChartInstance)) {
      configureOriginalChartFormatter(cachedKlineChartInstance);
      return cachedKlineChartInstance;
    }
    tryHookWebpackKlineCharts();
    if (cachedKlineChartInstance && isKlineChartObject(cachedKlineChartInstance)) return cachedKlineChartInstance;

    const visitedFibers = new WeakSet();
    const visitedObjects = new WeakSet();
    function searchObject(obj, depth = 0) {
      if (!obj || typeof obj !== 'object' || depth > 4 || visitedObjects.has(obj)) return null;
      if (obj instanceof Node || obj instanceof Window) return null;
      visitedObjects.add(obj);
      if (isKlineChartObject(obj)) return obj;
      for (const key of Object.keys(obj).slice(0, 25)) {
        try {
          const value = obj[key];
          if (value && typeof value === 'object') {
            const found = searchObject(value, depth + 1);
            if (found) return found;
          }
        } catch (_) {}
      }
      return null;
    }

    for (const canvas of document.querySelectorAll('canvas')) {
      if (canvas.clientWidth < 200 || canvas.clientHeight < 100) continue;
      let el = canvas;
      while (el && el !== document.body) {
        const reactKey = Object.keys(el).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
        if (reactKey) {
          let fiber = el[reactKey];
          let steps = 0;
          while (fiber && steps++ < 30) {
            if (!visitedFibers.has(fiber)) {
              visitedFibers.add(fiber);
              const foundState = searchObject(fiber.stateNode);
              if (foundState) {
                cachedKlineChartInstance = foundState;
                configureOriginalChartFormatter(foundState);
                return foundState;
              }
              let hook = fiber.memoizedState;
              let hookSteps = 0;
              while (hook && hookSteps++ < 30) {
                const foundHook = searchObject(hook.memoizedState);
                if (foundHook) {
                  cachedKlineChartInstance = foundHook;
                  configureOriginalChartFormatter(foundHook);
                  return foundHook;
                }
                hook = hook.next;
              }
            }
            fiber = fiber.return;
          }
        }
        el = el.parentElement;
      }
    }
    return null;
  }

  function applySecondBarsToOriginalChart() {
    const secStep = getActiveSecStep();
    const symbol = getCurrentUrlSymbol();
    if (!secStep || !symbol) return false;
    const store = getStore(symbol);
    const startSec = Math.floor((Date.now() - RETENTION_MS) / 1000);
    const bars = aggregateSecondBuckets(symbol, secStep, startSec, Math.floor(Date.now() / 1000)).slice(-MAX_CHART_BARS);
    const chart = findOriginalKlineChartInstance();
    if (!chart || !bars.length) return false;
    configureOriginalChartFormatter(chart);
    configureSecondCandleStyles(chart);
    try {
      if (store.decimals && typeof chart.setPriceVolumePrecision === 'function') chart.setPriceVolumePrecision(store.decimals, 2);
      chart.applyNewData(bars.map(b => ({ ...b, __kcexDirectV7__: true })), false);
      return true;
    } catch (_) { return false; }
  }


  async function activateSecondResolution(res) {
    currentActiveResolution = res;
    saveActiveResolution(res);
    setDisplayedSecondResolution(res);
    const symbol = getCurrentUrlSymbol();
    if (!symbol) return;
    await ensureSymbolEngine(symbol);
    const applied = applySecondBarsToOriginalChart();
    if (!applied) {
      // Do not toggle KCEX's React interval to 1m/5m as a reload trick: that
      // leaves the native 1m selection highlighted. The normal 50ms chart
      // publisher retries when the real chart instance becomes available.
      let attempts = 0;
      const retryApply = () => {
        if (currentActiveResolution !== res || attempts++ >= 35) return;
        if (!applySecondBarsToOriginalChart()) setTimeout(retryApply, 100);
      };
      setTimeout(retryApply, 80);
    }
    connectDealsSocket(symbol);
  }

  function pushRealtimeBarToOriginalChart(symbol) {
    if (!getActiveSecStep() || Date.now() < symbolTransitionLockUntil) return;
    const secStep = getActiveSecStep();
    const store = getStore(symbol);
    if (!store.dbLoaded) return;
    const nowSec = Math.floor(Date.now() / 1000);
    const bucketSec = Math.floor(nowSec / secStep) * secStep;
    const liveBar = getOrBuildBucketBar(symbol, secStep, bucketSec);
    if (!liveBar) return;
    const chart = findOriginalKlineChartInstance();
    const signature = [
      liveBar.bucketSec, liveBar.open, liveBar.high, liveBar.low, liveBar.close,
      liveBar.volume, liveBar.turnover, liveBar.ticks, liveBar.isProvisional ? 1 : 0
    ].join('|');
    // Re-publish only when the bar changes or the underlying chart instance is recreated.
    // The 50ms scheduler detects boundaries quickly without forcing 20 identical chart redraws/sec.
    if (store.lastPublishedBarSignature === signature && store.lastPublishedChart === chart) return;
    dispatchSyntheticKlineToChart(symbol, liveBar);

    if (!chart) return;
    configureOriginalChartFormatter(chart);
    try {
      const data = chart.getDataList();
      const rawUpdate = chart.__kcexOriginalUpdateV7__ || chart.updateData.bind(chart);
      if (!Array.isArray(data) || !data.length) {
        applySecondBarsToOriginalChart();
        return;
      }
      const last = data[data.length - 1];
      if (!isPriceValidForStore(store, last.close)) {
        applySecondBarsToOriginalChart();
        return;
      }
      // updateData replaces the current candle when timestamps match, otherwise appends the new interval.
      rawUpdate({ ...liveBar, __kcexDirectV7__: true });
      store.lastPublishedBarSignature = signature;
      store.lastPublishedChart = chart;
    } catch (_) {}
  }

  // ---------- Toolbar and dropdown UI ----------
  function injectStyles() {
    if (document.getElementById('kcex-sec-style-v7')) return;
    const style = document.createElement('style');
    style.id = 'kcex-sec-style-v7';
    style.textContent = `
      #kcex-sec-toolbar-group-v7{display:inline-flex;align-items:center;gap:6px;margin-right:6px;flex-shrink:0}
      .kcex-sec-btn-v7{display:inline-flex;align-items:center;justify-content:center;cursor:pointer;user-select:none;position:relative;font-size:12px;padding:2px 5px;border-radius:4px;color:#848e9c;transition:color .15s ease,background .15s ease}
      .kcex-sec-btn-v7:hover{color:#eaecef}
      .kcex-sec-btn-v7.kcex-sec-active-v7{color:#0ecb81!important;background:rgba(14,203,129,.12);font-weight:600!important}
      .kcex-sec-badge-v7{display:inline-flex;align-items:center;gap:4px;font-size:10px;color:#0ecb81;background:rgba(14,203,129,.1);border:1px solid rgba(14,203,129,.25);border-radius:4px;padding:1px 5px;cursor:help;user-select:none}
      .kcex-sec-dot-v7{width:5px;height:5px;border-radius:50%;background:#0ecb81;box-shadow:0 0 6px #0ecb81}
      .kcex-sec-dropdown-row-v7{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:6px 0 8px;margin-bottom:6px;border-bottom:1px solid rgba(255,255,255,.08)}
      .kcex-sec-dropdown-item-v7{display:flex;align-items:center;gap:4px;padding:4px 8px;border-radius:4px;cursor:pointer;font-size:12px;color:#848e9c;background:rgba(255,255,255,.03);transition:all .15s ease}
      .kcex-sec-dropdown-item-v7:hover{color:#eaecef;background:rgba(255,255,255,.08)}
      .kcex-sec-dropdown-item-v7.active{color:#0ecb81;background:rgba(14,203,129,.12)}
      .kcex-sec-star-v7{font-size:12px;color:#5e6673;cursor:pointer}.kcex-sec-star-v7.fav{color:#f0b90b}
      .kcex-native-interval-muted-v8{background:transparent!important;box-shadow:none!important;outline:none!important;border-color:transparent!important;color:#848e9c!important;font-weight:400!important}
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function updateStatusBadge(store) {
    const badge = document.getElementById('kcex-sec-live-badge-v7');
    if (!badge || !store) return;
    const storage = store.dbLoaded ? 'IndexedDB ready' : 'Loading history';
    const gap = store.backfillGapSuspected ? ' | Historical trade gap detected; long flat placeholders are suppressed' : '';
    const err = store.lastError ? ' | ' + store.lastError : '';
    const label = badge.querySelector('.kcex-sec-badge-label-v7');
    if (label) label.textContent = store.backfillGapSuspected ? 'REAL SEC · GAP' : 'REAL SEC';
    badge.title = `Real-trade seconds | ${store.symbol} | ${storage} | 24h local retention${gap}${err}`;
  }

  function getToolbarContainer() {
    return document.querySelector('[class*="klineInterval_klineActions"]') ||
      document.querySelector('[class*="klineInterval_wrapper"]') ||
      document.querySelector('.guide-klineInterval');
  }

  function normalizeNativeIntervalLabel(value) {
    const text = String(value || '')
      .replace(/[★☆⭐✩✪\u2605\u2606]/g, '')
      .replace(/\s+/g, '')
      .trim();
    const match = text.match(/^(\d+)(m|min|h|d|w|M)$/i);
    if (!match) return null;
    // Keep uppercase M distinct from lowercase m (months vs minutes).
    const unit = match[2] === 'M' ? 'M' : match[2].toLowerCase();
    return `${match[1]}${unit}`;
  }

  function findNativeIntervalMenuGrid() {
    const spans = Array.from(document.querySelectorAll('div,span'));
    const timeItem = spans.find(el => el.textContent.trim() === 'Time' && el.children.length === 0);
    if (!timeItem) return null;
    let grid = timeItem.parentElement;
    let depth = 0;
    while (grid && depth++ < 6) {
      const text = grid.textContent || '';
      if (text.includes('1m') && text.includes('2m') && text.includes('5m') && text.includes('15m')) return grid;
      grid = grid.parentElement;
    }
    return null;
  }

  function readNativeKlineIntervalLabel() {
    const container = getToolbarContainer();
    if (!container) return null;
    const reactKey = Object.keys(container).find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
    if (!reactKey) return null;
    let fiber = container[reactKey];
    let depth = 0;
    while (fiber && depth++ < 24) {
      const props = fiber.memoizedProps;
      if (props && typeof props === 'object' && props.klineInterval !== undefined && props.klineInterval !== null) {
        const raw = String(props.klineInterval).trim();
        if (/^\d+$/.test(raw)) return `${raw}m`;
        return normalizeNativeIntervalLabel(raw) || null;
      }
      fiber = fiber.return;
    }
    return null;
  }

  function getNativeIntervalElements() {
    const roots = [getToolbarContainer(), findNativeIntervalMenuGrid()].filter(Boolean);
    const found = new Set();
    for (const root of roots) {
      const elements = [root, ...root.querySelectorAll('*')];
      for (const el of elements) {
        if (!(el instanceof Element)) continue;
        if (el.closest('#kcex-sec-dropdown-section-v7, [data-kcex-sec-v7]')) continue;
        const label = normalizeNativeIntervalLabel(el.textContent);
        if (!label) continue;
        let current = el;
        for (let depth = 0; current && current !== root.parentElement && depth < 5; depth++, current = current.parentElement) {
          if (current.closest('#kcex-sec-dropdown-section-v7, [data-kcex-sec-v7]')) break;
          if (normalizeNativeIntervalLabel(current.textContent) !== label) break;
          const cls = typeof current.className === 'string' ? current.className : '';
          if (current.hasAttribute('data-interval') || current.tagName === 'BUTTON' || /interval|timeframe|resolution|fav|item|option/i.test(cls)) {
            found.add(current);
          }
        }
      }
    }
    return [...found];
  }

  function findNativeToolbarIntervalTextNode() {
    const container = getToolbarContainer();
    if (!container) return null;

    // The native favorite intervals are also rendered inside the toolbar.
    // Searching the whole toolbar for the first text matching "1m" can pick
    // a favorite cell instead of the actual interval dropdown trigger. Once
    // seconds mode is enabled, that would overwrite a favorite label (and a
    // repeated sync could overwrite several favorites in succession).
    // Restrict the display-label update to KCEX's own "more"/interval trigger.
    const trigger = container.querySelector(
      '[class*="klineInterval_more"], .guide-more'
    );
    if (!trigger || trigger.closest('#kcex-sec-toolbar-group-v7, #kcex-sec-dropdown-section-v7')) return null;

    const walker = document.createTreeWalker(trigger, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement?.closest('#kcex-sec-toolbar-group-v7, #kcex-sec-dropdown-section-v7')) continue;
      if (normalizeNativeIntervalLabel(node.nodeValue)) return node;
    }
    return null;
  }

  function syncNativeIntervalPresentation(activeResolution) {
    const active = /^\d+S$/i.test(String(activeResolution || '')) ? String(activeResolution).toUpperCase() : null;
    const nativeLabel = readNativeKlineIntervalLabel();
    const nativeCells = new Set(getNativeIntervalElements());
    const toolbar = getToolbarContainer();
    if (toolbar) {
      // KCEX changes the wrapper that carries activeInterval across builds.
      // Include every native active wrapper directly, even when its label is nested.
      toolbar.querySelectorAll('[class*="activeInterval"]').forEach(el => {
        if (!el.closest('#kcex-sec-toolbar-group-v7, #kcex-sec-dropdown-section-v7')) nativeCells.add(el);
      });
    }

    nativeCells.forEach(el => {
      const cls = typeof el.className === 'string' ? el.className : '';
      const markedActive = /active|selected|current/i.test(cls) || el.getAttribute('aria-selected') === 'true';
      const matchesReactSelection = !!nativeLabel && normalizeNativeIntervalLabel(el.textContent) === nativeLabel;
      const savedActiveClass = el.dataset.kcexSavedActiveClassV9;
      if (active && (markedActive || matchesReactSelection)) {
        // The original activeInterval class can draw a visible border even
        // after the background/outline are neutralized. Remove that class
        // only for the native selection while seconds are displayed.
        const activeClass = Array.from(el.classList).find(name => name.includes('activeInterval'));
        if (activeClass && !savedActiveClass) {
          el.dataset.kcexSavedActiveClassV9 = activeClass;
          el.classList.remove(activeClass);
        }
        el.classList.add('kcex-native-interval-muted-v8');
      } else {
        el.classList.remove('kcex-native-interval-muted-v8');
        if (!active && savedActiveClass) {
          // Restore exactly the class we removed before seconds mode. React will
          // immediately reconcile it if a different native interval was selected.
          el.classList.add(savedActiveClass);
          delete el.dataset.kcexSavedActiveClassV9;
        }
      }
    });

    const textNode = findNativeToolbarIntervalTextNode();
    if (active && textNode) {
      if (!nativeToolbarLabelState || nativeToolbarLabelState.node !== textNode) {
        nativeToolbarLabelState = { node: textNode, original: textNode.nodeValue, applied: null };
      }
      const secondLabel = active.toLowerCase();
      const current = textNode.nodeValue || '';
      const leading = current.match(/^\s*/)?.[0] || '';
      const trailing = current.match(/\s*$/)?.[0] || '';
      textNode.nodeValue = `${leading}${secondLabel}${trailing}`;
      nativeToolbarLabelState.applied = textNode.nodeValue;
    } else if (!active && nativeToolbarLabelState) {
      const state = nativeToolbarLabelState;
      if (state.node?.isConnected && state.applied !== null && state.node.nodeValue === state.applied) {
        state.node.nodeValue = state.original;
      }
      nativeToolbarLabelState = null;
    }
  }

  function setDisplayedSecondResolution(resolution) {
    displayedSecondResolution = /^\d+S$/i.test(String(resolution || '')) ? String(resolution).toUpperCase() : null;
    syncToolbarHighlight();
  }

  function findNativeIntervalCellFromTarget(target) {
    if (!(target instanceof Element)) return null;
    if (target.closest('#kcex-sec-dropdown-section-v7, [data-kcex-sec-v7]')) return null;
    // Opening the native interval dropdown is not itself a timeframe change.
    if (target.closest('[class*="klineInterval_more"], .guide-more')) return null;
    const dataItem = target.closest('[data-interval]:not([data-kcex-sec-v7])');
    if (dataItem && !dataItem.closest('[class*="klineInterval_more"], .guide-more') && normalizeNativeIntervalLabel(dataItem.textContent)) return dataItem;
    const grid = findNativeIntervalMenuGrid();
    let current = target;
    for (let depth = 0; current && current !== document.body && depth < 9; depth++, current = current.parentElement) {
      if (current.closest('#kcex-sec-dropdown-section-v7, [data-kcex-sec-v7]')) return null;
      if (current.closest('[class*="klineInterval_more"], .guide-more')) return null;
      if (normalizeNativeIntervalLabel(current.textContent)) {
        const cls = typeof current.className === 'string' ? current.className : '';
        if (current.tagName === 'BUTTON' || /interval|timeframe|resolution|fav|item|option/i.test(cls) || (grid && grid.contains(current))) {
          return current;
        }
      }
      if (grid && current === grid) break;
    }
    return null;
  }

  function isNativeFavoriteToggleClick(event, cell) {
    const path = typeof event.composedPath === 'function' ? event.composedPath() : [event.target];
    const x = Number(event.clientX);
    const y = Number(event.clientY);
    for (const node of path) {
      if (!(node instanceof Element)) continue;
      const cls = typeof node.className === 'string' ? node.className : '';
      const labels = [node.getAttribute('aria-label'), node.getAttribute('title'), node.getAttribute('data-testid')]
        .filter(Boolean).join(' ');
      if (/(?:favorite|favourite|fav(?:orite)?[-_ ]?(?:icon|star)|star[-_ ]?icon|bookmark|collect)/i.test(`${cls} ${labels}`)) return true;
      const text = (node.textContent || '').trim();
      if (/^[★☆⭐✩✪]$/.test(text)) return true;
      // SVG icons are treated as star toggles only when the pointer was actually
      // inside the icon bounds. Do not swallow clicks on the interval label beside it.
      const svg = node.tagName === 'SVG' ? node : node.closest('svg');
      if (svg) {
        const rect = svg.getBoundingClientRect();
        if (x >= rect.left - 2 && x <= rect.right + 2 && y >= rect.top - 2 && y <= rect.bottom + 2) return true;
      }
    }
    // Some native builds render the star as a font glyph without a dedicated class.
    // Restrict this fallback to the narrow leading icon slot, not a broad fraction
    // of the favorite button that could overlap the timeframe text.
    if (cell && /favInterval|favorite/i.test(String(cell.className || ''))) {
      const rect = cell.getBoundingClientRect();
      const iconSlot = Math.min(18, rect.width * 0.22);
      const dx = x - rect.left;
      if (dx >= 0 && dx <= iconSlot && y >= rect.top && y <= rect.bottom) return true;
    }
    return false;
  }

  function handleNativeIntervalClick(event) {
    if (isTogglingReactInterval) return;
    const cell = findNativeIntervalCellFromTarget(event.target);
    if (!cell || isNativeFavoriteToggleClick(event, cell)) return;

    // Let KCEX's own React handler process the interval click. We only leave
    // seconds mode here; favorite-star clicks are deliberately not intercepted.
    if (currentActiveResolution) {
      currentActiveResolution = null;
      saveActiveResolution(null);
      stopDealsSocket();
    }
    setDisplayedSecondResolution(null);
    syncToolbarHighlight();
  }

  function syncToolbarHighlight() {
    const container = getToolbarContainer();
    const secondItems = Array.from(document.querySelectorAll('[data-kcex-sec-v7]'));
    const activeResolution = displayedSecondResolution;

    if (container) {
      syncNativeIntervalPresentation(activeResolution);
    }

    secondItems.forEach(el => {
      const active = String(el.getAttribute('data-kcex-sec-v7') || '').toUpperCase() === activeResolution;
      el.classList.toggle('kcex-sec-active-v7', !!active);
    });
  }

  // Small UI bridge used by the independent TradingView module. It only changes
  // the interval label/highlight; it never starts or stops either chart engine.
  window.__KCEX_ENHANCER_INTERVAL_UI_V1__ = {
    setActive: setDisplayedSecondResolution,
    clear: () => setDisplayedSecondResolution(null),
    getActive: () => displayedSecondResolution || currentActiveResolution || null
  };

  function injectTopToolbarButtons() {
    injectStyles();
    const container = getToolbarContainer();
    if (!container) return;
    const native = container.querySelector('[data-interval]:not([data-kcex-sec-v7])');
    const baseClass = native ? (Array.from(native.classList).find(c => c.includes('favInterval')) || '') : '';
    let group = document.getElementById('kcex-sec-toolbar-group-v7');
    if (!group || group.parentElement !== container) {
      if (group) group.remove();
      group = document.createElement('div');
      group.id = 'kcex-sec-toolbar-group-v7';
      container.insertBefore(group, container.firstChild);
    }

    const renderSign = favResolutions.join(',') + '|' + (currentActiveResolution || '') + '|' + (getCurrentUrlSymbol() || '');
    if (group.dataset.renderSign === renderSign) { syncToolbarHighlight(); return; }
    group.dataset.renderSign = renderSign;
    group.innerHTML = '';

    const badge = document.createElement('div');
    badge.id = 'kcex-sec-live-badge-v7';
    badge.className = 'kcex-sec-badge-v7';
    badge.innerHTML = '<span class="kcex-sec-dot-v7"></span><span class="kcex-sec-badge-label-v7">REAL SEC</span>';
    const symbol = getCurrentUrlSymbol();
    if (symbol) updateStatusBadge(getStore(symbol));
    group.appendChild(badge);

    SECOND_INTERVALS.forEach(item => {
      if (!favResolutions.includes(item.res) && currentActiveResolution !== item.res) return;
      const button = document.createElement('div');
      button.className = `${baseClass} kcex-sec-btn-v7`.trim();
      button.setAttribute('data-kcex-sec-v7', item.res);
      button.textContent = item.label;
      button.addEventListener('click', event => {
        event.stopPropagation();
        activateSecondResolution(item.res);
      });
      group.appendChild(button);
    });
    syncToolbarHighlight();
  }

  function injectDropdownPopup() {
    const spans = Array.from(document.querySelectorAll('div,span'));
    const timeItem = spans.find(el => el.textContent.trim() === 'Time' && el.children.length === 0);
    if (!timeItem) return;
    let grid = timeItem.parentElement;
    let depth = 0;
    while (grid && depth++ < 5) {
      const text = grid.textContent || '';
      if (text.includes('1m') && text.includes('2m') && text.includes('5m') && text.includes('15m')) break;
      grid = grid.parentElement;
    }
    if (!grid || grid.querySelector('#kcex-sec-dropdown-section-v7')) return;

    const row = document.createElement('div');
    row.id = 'kcex-sec-dropdown-section-v7';
    row.className = 'kcex-sec-dropdown-row-v7';
    row.style.gridColumn = '1 / -1';

    SECOND_INTERVALS.forEach(item => {
      const cell = document.createElement('div');
      cell.className = `kcex-sec-dropdown-item-v7 ${currentActiveResolution === item.res ? 'active' : ''}`;
      cell.innerHTML = `<span class="kcex-sec-star-v7 ${favResolutions.includes(item.res) ? 'fav' : ''}" title="Add/remove from toolbar">★</span><span style="flex:1">${item.label}</span>`;
      const star = cell.querySelector('.kcex-sec-star-v7');
      star.addEventListener('click', event => {
        event.stopPropagation();
        if (favResolutions.includes(item.res)) {
          if (favResolutions.length > 1) favResolutions = favResolutions.filter(x => x !== item.res);
        } else favResolutions.push(item.res);
        saveFavResolutions(favResolutions);
        star.classList.toggle('fav', favResolutions.includes(item.res));
        injectTopToolbarButtons();
      });
      cell.addEventListener('click', event => {
        event.stopPropagation();
        activateSecondResolution(item.res);
        row.querySelectorAll('.kcex-sec-dropdown-item-v7').forEach(el => el.classList.remove('active'));
        cell.classList.add('active');
      });
      row.appendChild(cell);
    });
    grid.insertBefore(row, grid.firstChild);

  }

  // Native minute/hour interval clicks leave seconds mode, but favorite-star clicks
  // are excluded so the site's original Favorites control remains fully interactive.
  document.addEventListener('click', handleNativeIntervalClick, true);

  // ---------- Symbol changes, initial restore, and realtime chart updates ----------
  function checkSymbolTransition() {
    const symbol = getCurrentUrlSymbol();
    if (!symbol || symbol === lastUrlSymbol) return;
    lastUrlSymbol = symbol;
    symbolTransitionLockUntil = Date.now() + 400;
    stopDealsSocket();
    if (currentActiveResolution) {
      setTimeout(async () => {
        if (getCurrentUrlSymbol() !== symbol || !currentActiveResolution) return;
        await ensureSymbolEngine(symbol);
        applySecondBarsToOriginalChart();
        connectDealsSocket(symbol);
        injectTopToolbarButtons();
      }, 350);
    }
  }

  // Publish the active candle at 20 Hz. This lets a zero-volume placeholder
  // appear at the interval boundary, before the first trade of that interval.
  setInterval(() => {
    const symbol = getCurrentUrlSymbol();
    if (symbol && currentActiveResolution) pushRealtimeBarToOriginalChart(symbol);
  }, 50);

  setInterval(() => {
    checkSymbolTransition();
    const symbol = getCurrentUrlSymbol();
    if (symbol && currentActiveResolution) {
      const store = getStore(symbol);
      if (!store.dbLoaded && !store.initPromise) ensureSymbolEngine(symbol);
      updateStatusBadge(store);
      cleanupOldHistory();
    }
  }, 150);

  setInterval(() => {
    tryHookWebpackKlineCharts();
    injectTopToolbarButtons();
    injectDropdownPopup();
  }, 350);

  // Restore the last selected second timeframe after refresh.
  if (currentActiveResolution) {
    setDisplayedSecondResolution(currentActiveResolution);
    setTimeout(async () => {
      const symbol = getCurrentUrlSymbol();
      if (!symbol || !currentActiveResolution) return;
      await ensureSymbolEngine(symbol);
      applySecondBarsToOriginalChart();
      connectDealsSocket(symbol);
      injectTopToolbarButtons();
    }, 900);
  }

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flushPendingDbWrites();
  });

  window.addEventListener('pagehide', () => {
    try { if (dbFlushTimer) clearTimeout(dbFlushTimer); } catch (_) {}
    flushPendingDbWrites();
    stopDealsSocket();
  });
})();
