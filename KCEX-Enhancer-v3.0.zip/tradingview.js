(function () {
  'use strict';

  // KCEX Enhancer - independent TradingView seconds engine + candle countdown (v2.9).
  // This module intentionally does not share state, storage, or chart APIs with injected.js.
  if (window.__KCEX_TV_SECONDS_ENGINE_V5__) return;
  window.__KCEX_TV_SECONDS_ENGINE_V4__ = true;

  const MODULE_ID = 'kcex-tv-seconds-engine-v5';
  const BADGE_ID = 'kcex-tv-countdown-badge-v5';
  const WS_URL = 'wss://www.kcex.com/fapi/edge';
  const DB_NAME = 'kcex_tv_seconds_real_history_v1';
  const DB_VERSION = 1;
  const RETENTION_MS = 24 * 60 * 60 * 1000;
  const RETENTION_SEC = RETENTION_MS / 1000;
  const MAX_HISTORY_BARS = 20000;
  const DB_FLUSH_MS = 300;
  const DATA_POLL_MS = 50;
  const UI_POLL_MS = 150;
  const TIMER_TICK_MS = 100;
  const SERVER_SYNC_MS = 15000;
  const CHART_API_CACHE_MS = 350;
  const ALLOWED_STEPS = [1, 5, 10, 15, 20, 30, 45];
  const SECOND_RESOLUTIONS = ALLOWED_STEPS.map(x => `${x}S`);
  const RESOLUTION_SET = new Set(SECOND_RESOLUTIONS);

  let dbPromise = null;
  let dbFlushTimer = null;
  let dataPollTimer = null;
  let uiPollTimer = null;
  let timerTickTimer = null;
  let clockOffsetMs = 0;
  let lastServerSyncAt = 0;
  let activeResolution = null;
  let resolutionSource = 'waiting';
  let currentHost = null;
  let currentBadge = null;
  let lastBadgeText = '';
  let lastCleanupAt = 0;
  const stores = new Map();
  const pendingDbWrites = new Map();
  const patchedDatafeeds = new WeakSet();
  const subscriptions = new Map();
  let lastSetResolutionResult = null;
  let lastSetResolutionError = null;
  let widgetOptionsPatched = false;
  let patchedDatafeedCount = 0;
  let chartApiCache = null;
  let chartApiCacheAt = 0;
  const datafeedSourcesSeen = new Set();
  let lastResolveSymbolRequest = null;
  let lastResolvedMarketSymbol = null;
  let lastGetBarsSymbol = null;
  let lastSubscribeSymbol = null;

  function nowMs() {
    return Date.now() + clockOffsetMs;
  }

  function normalizeResolution(value) {
    if (value === null || value === undefined) return null;
    const s = String(value).trim().toUpperCase();
    if (/^\d+S$/.test(s) || /^\d+$/.test(s) || /^\d+[DWM]$/.test(s)) return s;
    return null;
  }

  function secondsFromResolution(value) {
    const r = normalizeResolution(value);
    const match = r && r.match(/^(\d+)S$/);
    const step = match ? Number(match[1]) : 0;
    return ALLOWED_STEPS.includes(step) ? step : null;
  }

  function resolutionToMs(value) {
    const r = normalizeResolution(value);
    if (!r) return null;
    let m;
    if ((m = r.match(/^(\d+)S$/))) return Number(m[1]) * 1000;
    if ((m = r.match(/^(\d+)$/))) return Number(m[1]) * 60 * 1000;
    if ((m = r.match(/^(\d+)D$/))) return Number(m[1]) * 86400000;
    if ((m = r.match(/^(\d+)W$/))) return Number(m[1]) * 604800000;
    if ((m = r.match(/^(\d+)M$/))) return Number(m[1]) * 2592000000;
    return null;
  }

  function setResolution(value, source) {
    const r = normalizeResolution(value);
    if (!r) return;
    activeResolution = r;
    resolutionSource = source || 'datafeed';
    try {
      const ui = window.__KCEX_ENHANCER_INTERVAL_UI_V1__;
      if (ui && typeof ui.setActive === 'function') {
        ui.setActive(secondsFromResolution(r) ? r : null);
      }
    } catch (_) {}
  }

  function resolutionFromUrl() {
    try {
      const params = new URL(location.href).searchParams;
      return normalizeResolution(params.get('i') || params.get('resolution') || params.get('interval'));
    } catch (_) { return null; }
  }

  function supportedResolutions(list) {
    const existing = Array.isArray(list) ? list.map(String) : [];
    return [...new Set([...SECOND_RESOLUTIONS, ...existing])];
  }

  function withSecondsFeature(options) {
    if (!options || typeof options !== 'object') return options;
    const next = { ...options };
    const enabled = Array.isArray(next.enabled_features) ? next.enabled_features.map(String) : [];
    const disabled = Array.isArray(next.disabled_features) ? next.disabled_features.map(String) : [];
    next.enabled_features = [...new Set([...enabled.filter(x => x !== 'seconds_resolution'), 'seconds_resolution'])];
    next.disabled_features = disabled.filter(x => x !== 'seconds_resolution');
    return next;
  }

  function getTradingViewFrame() {
    const frames = [...document.querySelectorAll('iframe[id^="tradingview_"], iframe[title="Financial Chart"]')];
    return frames.find(frame => {
      try {
        const r = frame.getBoundingClientRect();
        if (r.width <= 150 || r.height <= 100) return false;
        let node = frame;
        while (node && node !== document.documentElement) {
          const css = getComputedStyle(node);
          if (css.display === 'none' || css.visibility === 'hidden' || Number(css.opacity || 1) === 0) return false;
          node = node.parentElement;
        }
        return true;
      } catch (_) { return false; }
    }) || null;
  }

  function isTradingViewActive() {
    return !!getTradingViewFrame();
  }

  function getResolutionFromElement(target) {
    if (!(target instanceof Element)) return null;
    const toolbarButton = target.closest('[data-kcex-sec-v7]');
    if (toolbarButton) {
      const value = String(toolbarButton.getAttribute('data-kcex-sec-v7') || '').toUpperCase();
      return RESOLUTION_SET.has(value) ? value : null;
    }
    const dropdownItem = target.closest('.kcex-sec-dropdown-item-v7');
    if (dropdownItem) {
      if (target.closest('.kcex-sec-star-v7')) return null;
      const match = String(dropdownItem.textContent || '').match(/(1|5|10|15|20|30|45)\s*s\b/i);
      return match ? `${match[1]}S` : null;
    }
    return null;
  }

  function markSecondResolutionSelected(resolution) {
    document.querySelectorAll('[data-kcex-sec-v7]').forEach(el => {
      const active = String(el.getAttribute('data-kcex-sec-v7') || '').toUpperCase() === resolution;
      el.classList.toggle('kcex-tv-sec-active-v5', active);
      if (active) {
        el.style.background = 'rgba(14,203,129,.14)';
        el.style.color = '#0ecb81';
      } else {
        el.style.removeProperty('background');
        el.style.removeProperty('color');
      }
    });
    document.querySelectorAll('.kcex-sec-dropdown-item-v7').forEach(el => {
      const match = String(el.textContent || '').match(/(1|5|10|15|20|30|45)\s*s\b/i);
      const active = !!match && `${match[1]}S` === resolution;
      el.classList.toggle('active', active);
    });
  }

  function pageContractSymbol() {
    try {
      const match = location.pathname.match(/\/exchange\/([A-Z0-9_]+)/i);
      if (match && match[1]) return normalizeSymbol(match[1]);
      const querySymbol = new URL(location.href).searchParams.get('s');
      return querySymbol ? normalizeSymbol(querySymbol) : null;
    } catch (_) { return null; }
  }

  function isPlaceholderChartSymbol(value) {
    const token = String(value || '').trim().toUpperCase();
    return !token || /^(?:TV_CHART_CONTAINER|TV_CHART|CHART_CONTAINER|CHART|CONTAINER|TRADINGVIEW_[A-Z0-9]+)$/.test(token);
  }

  function cleanSymbolCandidate(value) {
    const raw = String(value || '').trim();
    if (!raw) return null;
    // KCEX price-type symbols may be formatted as SYMBOL:LAST_PRICE.
    // The contract itself is the first segment; discard the price-type suffix.
    let candidate = raw.split(':')[0].trim().replace(/\.P$/i, '');
    if (!/^[A-Z0-9_]+$/i.test(candidate) || isPlaceholderChartSymbol(candidate)) return null;
    return normalizeSymbol(candidate);
  }

  function symbolFromInfo(info, requestedSymbol) {
    const candidates = [
      info?.ticker,
      requestedSymbol,
      info?.name,
      info?.full_name,
      info?.description
    ];
    for (const candidate of candidates) {
      const cleaned = cleanSymbolCandidate(candidate);
      if (cleaned) {
        lastResolvedMarketSymbol = {
          selected: cleaned,
          source: candidate === info?.ticker ? 'ticker' :
            candidate === requestedSymbol ? 'requestedSymbol' :
            candidate === info?.name ? 'name' :
            candidate === info?.full_name ? 'full_name' : 'description',
          pageSymbol: pageContractSymbol()
        };
        return cleaned;
      }
    }
    const pageSymbol = pageContractSymbol();
    lastResolvedMarketSymbol = {
      selected: pageSymbol,
      source: pageSymbol ? 'page-url-fallback' : 'unresolved',
      rawTicker: info?.ticker ?? null,
      rawName: info?.name ?? null,
      requestedSymbol: requestedSymbol ?? null,
      pageSymbol
    };
    return pageSymbol;
  }

  function normalizeResolveSymbolRequest(symbolName) {
    const raw = String(symbolName || '').trim();
    if (!raw) return raw;
    const parts = raw.split(':');
    if (!isPlaceholderChartSymbol(parts[0])) return raw;
    const pageSymbol = pageContractSymbol();
    if (!pageSymbol) return raw;
    parts[0] = pageSymbol;
    return parts.join(':');
  }

  function normalizeTradeTime(value) {
    let t = Number(value);
    if (!Number.isFinite(t) || t <= 0) return 0;
    if (t < 1e12) t *= 1000;
    return t;
  }

  function normalizeSymbol(value) {
    return String(value || '').trim().toUpperCase().replace(/\.P$/, '');
  }

  function getStore(symbol) {
    const sym = normalizeSymbol(symbol);
    if (!sym) return null;
    if (!stores.has(sym)) {
      stores.set(sym, {
        symbol: sym,
        liveSecMap: new Map(),
        sortedSecs: [],
        lastTradeTs: 0,
        lastPrice: null,
        decimals: 2,
        dbLoaded: false,
        initPromise: null,
        socket: null,
        socketReadyPromise: null,
        socketReadyResolve: null,
        socketCutoverTs: 0,
        socketReconnectTimer: null,
        socketPingTimer: null,
        socketGeneration: 0,
        backfillPromise: null,
        backfillGapSuspected: false,
        lastError: null,
        historyTailByStep: new Map(),
        lastCleanupAt: 0,
        acceptedTrades: 0,
        restAcceptedTrades: 0,
        wsAcceptedTrades: 0,
        rejectedCutoverTrades: 0,
        lastWsMessageAt: 0,
        lastWsChannel: null,
        lastRestBackfillAt: 0,
        lastGetBarsAt: 0,
        lastGetBarsResolution: null,
        lastGetBarsCount: null,
        lastSubscribeAt: 0
      });
    }
    return stores.get(sym);
  }

  function updatePrecision(store, values) {
    let decimals = store.decimals || 0;
    for (const value of values) {
      const p = Number(value);
      if (!Number.isFinite(p) || p <= 0) continue;
      const s = p.toFixed(12).replace(/0+$/, '');
      const dot = s.indexOf('.');
      const count = dot < 0 || dot === s.length - 1 ? 0 : s.length - dot - 1;
      decimals = Math.max(decimals, count);
      if (p < 0.01) decimals = Math.max(decimals, Math.min(12, Math.max(6, Math.ceil(-Math.log10(p)) + 4)));
      else if (p < 1) decimals = Math.max(decimals, 4);
      else decimals = Math.max(decimals, 2);
    }
    store.decimals = Math.min(12, Math.max(2, decimals));
  }

  function roundPrice(value, store) {
    const n = Number(value);
    if (!Number.isFinite(n)) return 0;
    return Number(n.toFixed(store.decimals || 8));
  }

  function addSortedSec(store, sec) {
    const keys = store.sortedSecs;
    const last = keys.length - 1;
    if (last < 0 || sec > keys[last]) {
      keys.push(sec);
      return;
    }
    let low = 0;
    let high = keys.length;
    while (low < high) {
      const mid = (low + high) >>> 1;
      if (keys[mid] < sec) low = mid + 1;
      else high = mid;
    }
    if (keys[low] !== sec) keys.splice(low, 0, sec);
  }

  // ---------- Independent IndexedDB: real one-second trade buckets, 24h retention ----------
  function getDb() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB is unavailable'));
        return;
      }
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('seconds')) {
          const seconds = db.createObjectStore('seconds', { keyPath: ['symbol', 'sec'] });
          seconds.createIndex('bySymbol', 'symbol', { unique: false });
        }
        if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'symbol' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB open failed'));
      request.onblocked = () => reject(new Error('IndexedDB upgrade blocked'));
    });
    return dbPromise;
  }

  function requestResult(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('IndexedDB request failed'));
    });
  }

  function transactionDone(tx) {
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed'));
      tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
    });
  }

  async function loadPersistedHistory(store) {
    if (store.dbLoaded) return;
    try {
      const db = await getDb();
      const tx = db.transaction(['seconds', 'meta'], 'readonly');
      const rowsPromise = requestResult(
        tx.objectStore('seconds').index('bySymbol').getAll(IDBKeyRange.only(store.symbol))
      );
      const metaPromise = requestResult(tx.objectStore('meta').get(store.symbol));
      const [rows, meta] = await Promise.all([rowsPromise, metaPromise]);
      const cutoff = Math.floor((Date.now() - RETENTION_MS) / 1000);
      let latestTs = 0;
      for (const row of rows || []) {
        const sec = Number(row?.sec);
        if (!Number.isFinite(sec) || sec < cutoff) continue;
        const bucket = {
          open: Number(row.open),
          high: Number(row.high),
          low: Number(row.low),
          close: Number(row.close),
          volume: Number(row.volume) || 0,
          turnover: Number(row.turnover) || 0,
          firstTs: Number(row.firstTs) || sec * 1000,
          lastTs: Number(row.lastTs) || sec * 1000,
          ticks: Number(row.ticks) || 1
        };
        store.liveSecMap.set(sec, bucket);
        addSortedSec(store, sec);
        latestTs = Math.max(latestTs, bucket.lastTs);
      }
      store.sortedSecs.sort((a, b) => a - b);
      store.lastTradeTs = latestTs;
      const lastSec = store.sortedSecs[store.sortedSecs.length - 1];
      if (lastSec !== undefined) store.lastPrice = store.liveSecMap.get(lastSec)?.close ?? null;
      if (store.lastPrice) updatePrecision(store, [store.lastPrice]);
    } catch (error) {
      store.lastError = 'Storage load: ' + String(error);
    } finally {
      store.dbLoaded = true;
    }
  }

  function queuePersistBucket(store, sec, bucket) {
    const row = {
      symbol: store.symbol,
      sec,
      open: bucket.open,
      high: bucket.high,
      low: bucket.low,
      close: bucket.close,
      volume: bucket.volume,
      turnover: bucket.turnover,
      firstTs: bucket.firstTs,
      lastTs: bucket.lastTs,
      ticks: bucket.ticks
    };
    pendingDbWrites.set(store.symbol + '|' + sec, row);
    if (!dbFlushTimer) dbFlushTimer = setTimeout(flushPendingDbWrites, DB_FLUSH_MS);
  }

  async function flushPendingDbWrites() {
    dbFlushTimer = null;
    if (!pendingDbWrites.size) return;
    const rows = [...pendingDbWrites.values()];
    pendingDbWrites.clear();
    try {
      const db = await getDb();
      const tx = db.transaction(['seconds', 'meta'], 'readwrite');
      const seconds = tx.objectStore('seconds');
      const meta = tx.objectStore('meta');
      const latestBySymbol = new Map();
      for (const row of rows) {
        seconds.put(row);
        latestBySymbol.set(row.symbol, Math.max(latestBySymbol.get(row.symbol) || 0, row.lastTs || 0));
      }
      for (const [symbol, ts] of latestBySymbol) {
        const store = stores.get(symbol);
        meta.put({ symbol, lastTradeTs: Math.max(store?.lastTradeTs || 0, ts) });
      }
      await transactionDone(tx);
    } catch (error) {
      for (const row of rows) pendingDbWrites.set(row.symbol + '|' + row.sec, row);
      for (const store of stores.values()) store.lastError = 'Storage write: ' + String(error);
      if (!dbFlushTimer) dbFlushTimer = setTimeout(flushPendingDbWrites, 1500);
    }
  }

  async function cleanupOldHistory(store) {
    const now = Date.now();
    if (now - store.lastCleanupAt < 60 * 60 * 1000) return;
    store.lastCleanupAt = now;
    const cutoff = Math.floor((now - RETENTION_MS) / 1000);
    try {
      const db = await getDb();
      const tx = db.transaction(['seconds'], 'readwrite');
      const index = tx.objectStore('seconds').index('bySymbol');
      const request = index.openCursor(IDBKeyRange.only(store.symbol));
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) return;
        if (Number(cursor.value.sec) < cutoff) cursor.delete();
        cursor.continue();
      };
      await transactionDone(tx);
    } catch (_) {}
    for (const sec of store.liveSecMap.keys()) {
      if (sec < cutoff) store.liveSecMap.delete(sec);
    }
    store.sortedSecs = store.sortedSecs.filter(sec => sec >= cutoff);
  }

  // ---------- Actual trade ingestion and OHLC aggregation (same model as Original) ----------
  function recordLiveTrade(symbol, trade, source) {
    const store = getStore(symbol);
    if (!store || !trade) return false;
    const t = normalizeTradeTime(trade.t);
    const p = Number(trade.p);
    const v = Number(trade.v) || 0;
    if (!t || !Number.isFinite(p) || p <= 0 || !Number.isFinite(v) || v < 0) return false;
    if (source === 'ws' && store.socketCutoverTs && t <= store.socketCutoverTs) {
      store.rejectedCutoverTrades = (store.rejectedCutoverTrades || 0) + 1;
      return false;
    }

    updatePrecision(store, [p]);
    const sec = Math.floor(t / 1000);
    let bucket = store.liveSecMap.get(sec);
    if (!bucket) {
      bucket = {
        open: p, high: p, low: p, close: p,
        volume: v, turnover: p * v,
        firstTs: t, lastTs: t, ticks: 1
      };
      addSortedSec(store, sec);
    } else {
      if (t < bucket.firstTs) {
        bucket.firstTs = t;
        bucket.open = p;
      }
      if (t >= bucket.lastTs) {
        bucket.lastTs = t;
        bucket.close = p;
      }
      bucket.high = Math.max(bucket.high, p);
      bucket.low = Math.min(bucket.low, p);
      bucket.volume += v;
      bucket.turnover += p * v;
      bucket.ticks += 1;
    }
    store.liveSecMap.set(sec, bucket);
    store.lastTradeTs = Math.max(store.lastTradeTs || 0, t);
    if (!store.lastPrice || t >= (store.lastPriceTs || 0)) {
      store.lastPrice = p;
      store.lastPriceTs = t;
    }
    queuePersistBucket(store, sec, bucket);
    store.acceptedTrades = (store.acceptedTrades || 0) + 1;
    if (source === 'ws') store.wsAcceptedTrades = (store.wsAcceptedTrades || 0) + 1;
    if (source === 'rest') store.restAcceptedTrades = (store.restAcceptedTrades || 0) + 1;

    const cutoff = Math.floor((Date.now() - RETENTION_MS) / 1000);
    if (sec >= cutoff) {
      // Prune the in-memory map occasionally rather than on every tick.
      if (store.sortedSecs.length && store.sortedSecs[0] < cutoff) {
        while (store.sortedSecs.length && store.sortedSecs[0] < cutoff) {
          const old = store.sortedSecs.shift();
          store.liveSecMap.delete(old);
        }
      }
    }
    return true;
  }

  function parseDealList(data) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.deals)) return data.deals;
    if (data && typeof data === 'object' && data.p !== undefined) return [data];
    return [];
  }

  async function performBackfill(store, cutoverTs, lowerBoundTs) {
    try {
      const url = `/fapi/v1/contract/deals/${encodeURIComponent(store.symbol)}`;
      const response = await fetch(url, {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { Accept: 'application/json' }
      });
      if (!response.ok) throw new Error(`REST HTTP ${response.status}`);
      const json = await response.json();
      const rows = parseDealList(json?.data);
      if (!json?.success || !rows.length) return 0;

      const normalized = rows
        .map(deal => ({ deal, ts: normalizeTradeTime(deal?.t) }))
        .filter(x => x.ts > 0 && x.ts <= cutoverTs && x.ts > (lowerBoundTs || 0))
        .sort((a, b) => a.ts - b.ts);

      const validAll = rows
        .map(deal => ({ deal, ts: normalizeTradeTime(deal?.t) }))
        .filter(x => x.ts > 0)
        .sort((a, b) => a.ts - b.ts);
      if (validAll.length >= 100 && lowerBoundTs > 0 && validAll[0].ts > lowerBoundTs + 1500) {
        store.backfillGapSuspected = true;
      }

      let accepted = 0;
      for (const item of normalized) {
        if (recordLiveTrade(store.symbol, item.deal, 'rest')) accepted++;
      }
      store.lastBackfillAt = Date.now();
      store.lastRestBackfillAt = store.lastBackfillAt;
      store.lastRestBackfillCount = accepted;
      return accepted;
    } catch (error) {
      store.lastError = 'REST recovery: ' + String(error);
      return 0;
    }
  }

  function scheduleBackfill(store, cutoverTs, lowerBoundTs) {
    const previous = store.backfillPromise;
    const run = (previous ? previous.catch(() => 0) : Promise.resolve(0))
      .then(() => performBackfill(store, cutoverTs, lowerBoundTs));
    let tracked;
    tracked = run.finally(() => {
      if (store.backfillPromise === tracked) store.backfillPromise = null;
    });
    store.backfillPromise = tracked;
    return tracked;
  }

  function getWebSocketConstructor() {
    // Prefer the native constructor in the same-origin TradingView iframe so
    // the Original chart's WebSocket wrapper does not see this independent socket.
    try {
      const frame = document.querySelector('iframe[id^="tradingview_"], iframe[title="Financial Chart"]');
      const Ctor = frame?.contentWindow?.WebSocket;
      if (typeof Ctor === 'function') return Ctor;
    } catch (_) {}
    return window.WebSocket;
  }

  function scheduleReconnect(store, generation) {
    if (generation !== store.socketGeneration) return;
    if (store.socketReconnectTimer) clearTimeout(store.socketReconnectTimer);
    store.socketReconnectTimer = setTimeout(() => connectDealsSocket(store), 1800);
  }

  function connectDealsSocket(store) {
    if (!store || store.socket) {
      if (store?.socket && (store.socket.readyState === 0 || store.socket.readyState === 1)) return;
    }
    store.socketGeneration++;
    const generation = store.socketGeneration;
    if (store.socketReconnectTimer) clearTimeout(store.socketReconnectTimer);
    store.socketReconnectTimer = null;
    if (store.socketPingTimer) clearInterval(store.socketPingTimer);
    store.socketPingTimer = null;

    let ws;
    try {
      const WebSocketCtor = getWebSocketConstructor();
      ws = new WebSocketCtor(WS_URL);
      store.socket = ws;
      store.socketReadyPromise = new Promise(resolve => { store.socketReadyResolve = resolve; });
    } catch (error) {
      store.lastError = 'WebSocket create: ' + String(error);
      if (store.socketReadyResolve) store.socketReadyResolve(false);
      scheduleReconnect(store, generation);
      return;
    }

    ws.addEventListener('open', () => {
      if (generation !== store.socketGeneration) return;
      const checkpoint = store.lastTradeTs || 0;
      store.socketCutoverTs = Date.now();
      try {
        ws.send(JSON.stringify({ method: 'sub.deal', param: { symbol: store.symbol, compress: false } }));
      } catch (error) {
        store.lastError = 'WebSocket subscribe: ' + String(error);
      }
      if (store.socketPingTimer) clearInterval(store.socketPingTimer);
      store.socketPingTimer = setInterval(() => {
        try { if (ws.readyState === 1) ws.send(JSON.stringify({ method: 'ping' })); } catch (_) {}
      }, 10000);
      if (store.socketReadyResolve) store.socketReadyResolve(true);
      scheduleBackfill(store, store.socketCutoverTs, checkpoint);
    });

    ws.addEventListener('message', event => {
      if (generation !== store.socketGeneration || typeof event.data !== 'string') return;
      let message;
      try { message = JSON.parse(event.data); } catch (_) { return; }
      store.lastWsMessageAt = Date.now();
      store.lastWsChannel = message?.channel || message?.method || 'unknown';
      if (message?.channel === 'push.deal') {
        const messageSymbol = normalizeSymbol(message.symbol || message.data?.symbol || store.symbol);
        if (messageSymbol !== store.symbol) return;
        for (const deal of parseDealList(message.data)) recordLiveTrade(store.symbol, deal, 'ws');
      } else if (message?.channel === 'rs.error') {
        store.lastError = 'WebSocket subscription error: ' + String(message.data || 'unknown');
      }
    });

    ws.addEventListener('error', () => {
      store.lastError = 'WebSocket connection error';
      if (store.socketReadyResolve) store.socketReadyResolve(false);
    });

    ws.addEventListener('close', () => {
      if (generation !== store.socketGeneration) return;
      if (store.socketPingTimer) clearInterval(store.socketPingTimer);
      store.socketPingTimer = null;
      if (store.socket === ws) store.socket = null;
      if (store.socketReadyResolve) store.socketReadyResolve(false);
      scheduleReconnect(store, generation);
    });
  }

  async function ensureSymbolEngine(symbol) {
    const store = getStore(symbol);
    if (!store) throw new Error('Invalid symbol');
    if (store.initPromise) return store.initPromise;
    store.initPromise = (async () => {
      await loadPersistedHistory(store);
      await cleanupOldHistory(store);

      // Open the live stream independently from the history bootstrap.
      if (!store.socket || store.socket.readyState > 1) connectDealsSocket(store);
      const ready = store.socketReadyPromise;
      const connected = ready
        ? await Promise.race([ready, new Promise(resolve => setTimeout(() => resolve(false), 1800))])
        : false;

      if (connected && store.backfillPromise) {
        await store.backfillPromise;
      } else if (!connected) {
        // REST bootstrap must not depend on WebSocket availability.
        const cutoff = Date.now();
        await scheduleBackfill(store, cutoff, store.lastTradeTs || 0);
      }

      // A stale IndexedDB meta timestamp or an early socket race must never
      // leave TradingView with an empty history response when REST has trades.
      if (!store.sortedSecs.length) {
        await scheduleBackfill(store, Date.now(), 0);
      }

      return store;
    })();
    try { return await store.initPromise; }
    finally { store.initPromise = null; }
  }

  function previousCloseBeforeBucket(store, bucketSec) {
    const keys = store.sortedSecs;
    let low = 0;
    let high = keys.length;
    while (low < high) {
      const mid = (low + high) >>> 1;
      if (keys[mid] < bucketSec) low = mid + 1;
      else high = mid;
    }
    for (let i = low - 1; i >= 0; i--) {
      const one = store.liveSecMap.get(keys[i]);
      const close = Number(one?.close);
      if (Number.isFinite(close) && close > 0) return close;
    }
    return null;
  }

  function buildBarForBucket(store, step, bucketSec) {
    let firstTs = Infinity;
    let lastTs = -Infinity;
    let realOpen = null;
    let realClose = null;
    let realHigh = -Infinity;
    let realLow = Infinity;
    let volume = 0;
    let turnover = 0;
    let ticks = 0;

    for (let sec = bucketSec; sec < bucketSec + step; sec++) {
      const one = store.liveSecMap.get(sec);
      if (!one) continue;
      if (one.firstTs < firstTs) {
        firstTs = one.firstTs;
        realOpen = one.open;
      }
      if (one.lastTs >= lastTs) {
        lastTs = one.lastTs;
        realClose = one.close;
      }
      realHigh = Math.max(realHigh, one.high);
      realLow = Math.min(realLow, one.low);
      volume += one.volume;
      turnover += one.turnover || 0;
      ticks += one.ticks || 1;
    }

    const previousClose = previousCloseBeforeBucket(store, bucketSec);
    if (realOpen === null || realClose === null) {
      const price = previousClose;
      if (!Number.isFinite(Number(price)) || Number(price) <= 0) return null;
      const flat = roundPrice(price, store);
      return {
        time: bucketSec * 1000,
        open: flat, high: flat, low: flat, close: flat,
        volume: 0,
        __kcexRaw: null,
        __kcexProvisional: true
      };
    }

    const rawOpen = roundPrice(realOpen, store);
    const rawHigh = roundPrice(realHigh, store);
    const rawLow = roundPrice(realLow, store);
    const rawClose = roundPrice(realClose, store);
    const displayOpen = previousClose === null ? rawOpen : roundPrice(previousClose, store);

    return {
      time: bucketSec * 1000,
      open: displayOpen,
      high: roundPrice(Math.max(rawHigh, displayOpen, rawClose), store),
      low: roundPrice(Math.min(rawLow, displayOpen, rawClose), store),
      close: rawClose,
      volume,
      // Diagnostic-only raw values; TradingView consumes the standard OHLCV fields above.
      __kcexRaw: { open: rawOpen, high: rawHigh, low: rawLow, close: rawClose, turnover, ticks },
      __kcexProvisional: false
    };
  }

  function buildHistoryBars(store, step, period) {
    const nowSec = Math.floor(Date.now() / 1000);
    const cutoff = nowSec - RETENTION_SEC;
    const toSec = Number.isFinite(Number(period?.to)) ? Math.min(nowSec + step, Number(period.to)) : nowSec + step;
    let fromSec = Number.isFinite(Number(period?.from)) ? Number(period.from) : nowSec - 900;
    const countBack = Math.max(0, Math.min(MAX_HISTORY_BARS, Number(period?.countBack) || 0));
    if (countBack) fromSec = Math.min(fromSec, toSec - countBack * step);
    fromSec = Math.max(cutoff, fromSec);

    const firstAvailable = store.sortedSecs[0];
    const lastAvailable = store.sortedSecs[store.sortedSecs.length - 1];
    if (firstAvailable === undefined || lastAvailable === undefined) return [];

    const startBucket = Math.max(
      Math.floor(fromSec / step) * step,
      Math.floor(firstAvailable / step) * step
    );
    const nowBucket = Math.floor(nowSec / step) * step;
    const endBucket = Math.min(
      Math.floor(Math.max(0, toSec - 0.001) / step) * step,
      nowBucket
    );
    if (endBucket < startBucket) return [];

    const rawLastBucket = Math.floor(lastAvailable / step) * step;
    // Do not manufacture an unlimited future/idle tail in historical requests.
    const finalBucket = Math.min(endBucket, Math.max(rawLastBucket, nowBucket));
    const maxStart = Math.max(startBucket, finalBucket - (MAX_HISTORY_BARS - 1) * step);
    const bars = [];
    for (let bucket = maxStart; bucket <= finalBucket; bucket += step) {
      const bar = buildBarForBucket(store, step, bucket);
      if (bar) bars.push(bar);
    }
    return bars;
  }

  function standardBar(bar) {
    return {
      time: bar.time,
      open: bar.open,
      high: bar.high,
      low: bar.low,
      close: bar.close,
      volume: bar.volume
    };
  }

  function signatureForBar(bar) {
    return [bar.time, bar.open, bar.high, bar.low, bar.close, bar.volume].join('|');
  }

  function subscriptionKey(symbol, step) {
    return `${symbol}|${step}`;
  }

  function publishRealtime() {
    const nowSec = Math.floor(Date.now() / 1000);
    for (const sub of subscriptions.values()) {
      const store = getStore(sub.symbol);
      if (!store) continue;
      const currentBucket = Math.floor(nowSec / sub.step) * sub.step;

      if (sub.lastSentBucket === null || sub.lastSentBucket === undefined) {
        const tail = store.historyTailByStep.get(sub.step);
        if (Number.isFinite(tail)) sub.lastSentBucket = tail;
        else sub.lastSentBucket = currentBucket - sub.step;
      }

      let nextBucket = sub.lastSentBucket + sub.step;
      let emitted = 0;
      while (nextBucket <= currentBucket && emitted < 500) {
        const bar = buildBarForBucket(store, sub.step, nextBucket);
        if (bar) {
          const standard = standardBar(bar);
          try { sub.callback(standard); } catch (_) {}
          sub.lastSentBucket = nextBucket;
          sub.lastSignature = signatureForBar(standard);
          emitted++;
        } else {
          // No prior real trade is available to price a zero-volume placeholder.
          sub.lastSentBucket = nextBucket;
          emitted++;
        }
        nextBucket += sub.step;
      }

      if (sub.lastSentBucket === currentBucket) {
        const bar = buildBarForBucket(store, sub.step, currentBucket);
        if (bar) {
          const standard = standardBar(bar);
          const signature = signatureForBar(standard);
          if (signature !== sub.lastSignature) {
            try { sub.callback(standard); } catch (_) {}
            sub.lastSignature = signature;
          }
        }
      }
    }
  }

  function startDataPoll() {
    if (dataPollTimer) return;
    dataPollTimer = setInterval(publishRealtime, DATA_POLL_MS);
  }

  function stopDataPollIfIdle() {
    if (subscriptions.size) return;
    if (dataPollTimer) clearInterval(dataPollTimer);
    dataPollTimer = null;
  }

  function isSecondResolution(resolution) {
    return RESOLUTION_SET.has(String(resolution || '').toUpperCase());
  }

  function patchDatafeed(datafeed, source) {
    if (!datafeed || patchedDatafeeds.has(datafeed)) return;
    patchedDatafeeds.add(datafeed);
    patchedDatafeedCount++;
    datafeedSourcesSeen.add(source);
    datafeed.__kcexTvEngineSourceV5__ = source;
    try { datafeed.__kcexTvEnginePatchedAtV5__ = Date.now(); } catch (_) {}

    const original = {
      onReady: datafeed.onReady,
      resolveSymbol: datafeed.resolveSymbol,
      getBars: datafeed.getBars,
      subscribeBars: datafeed.subscribeBars,
      unsubscribeBars: datafeed.unsubscribeBars,
      getServerTime: datafeed.getServerTime
    };

    if (typeof original.onReady === 'function') {
      datafeed.onReady = function (callback) {
        return Reflect.apply(original.onReady, this, [config => {
          const next = { ...(config || {}) };
          next.supported_resolutions = supportedResolutions(next.supported_resolutions);
          callback(next);
        }]);
      };
    }

    if (typeof original.resolveSymbol === 'function') {
      datafeed.resolveSymbol = function (symbolName, onResolve, onError, extension) {
        const effectiveSymbolName = normalizeResolveSymbolRequest(symbolName);
        lastResolveSymbolRequest = {
          requested: String(symbolName || ''),
          effective: effectiveSymbolName,
          pageSymbol: pageContractSymbol()
        };
        const wrappedResolve = info => {
          if (!info || typeof info !== 'object') {
            onResolve(info);
            return;
          }
          const next = { ...info };
          const resolvedSymbol = symbolFromInfo(next, effectiveSymbolName);
          const requestedBase = cleanSymbolCandidate(effectiveSymbolName);
          // If KCEX/TradingView supplies its container id as the ticker,
          // replace that identifier with the actual contract before the Charting
          // Library stores SymbolInfo or calls getBars/subscribeBars.
          if (resolvedSymbol && (!cleanSymbolCandidate(next.ticker) ||
              isPlaceholderChartSymbol(String(next.ticker || '').split(':')[0]))) {
            const suffix = String(effectiveSymbolName || '').includes(':')
              ? ':' + String(effectiveSymbolName).split(':').slice(1).join(':')
              : '';
            next.ticker = resolvedSymbol + suffix;
          } else if (requestedBase && !cleanSymbolCandidate(next.ticker)) {
            next.ticker = effectiveSymbolName;
          }
          if (resolvedSymbol && isPlaceholderChartSymbol(next.name)) next.name = resolvedSymbol;
          if (resolvedSymbol && isPlaceholderChartSymbol(next.description)) next.description = resolvedSymbol;
          next.has_seconds = true;
          next.seconds_multipliers = [...ALLOWED_STEPS].map(String);
          next.supported_resolutions = supportedResolutions(next.supported_resolutions);
          if (Array.isArray(next.supported_resolution)) {
            next.supported_resolution = supportedResolutions(next.supported_resolution);
          }
          onResolve(next);
        };
        return Reflect.apply(original.resolveSymbol, this, [effectiveSymbolName, wrappedResolve, onError, extension]);
      };
    }

    if (typeof original.getBars === 'function') {
      datafeed.getBars = function (symbolInfo, resolution, periodParams, onHistory, onError) {
        setResolution(resolution, 'getBars');
        const step = secondsFromResolution(resolution);
        if (!step) return Reflect.apply(original.getBars, this, arguments);
        const symbol = symbolFromInfo(symbolInfo, symbolInfo?.ticker);
        lastGetBarsSymbol = { resolved: symbol, ticker: symbolInfo?.ticker ?? null, name: symbolInfo?.name ?? null, resolution: String(resolution) };
        if (!symbol) {
          if (typeof onError === 'function') onError('KCEX Enhancer: unable to resolve contract symbol for seconds history');
          return;
        }
        const store = getStore(symbol);
        if (store) {
          store.lastGetBarsAt = Date.now();
          store.lastGetBarsResolution = String(resolution);
        }
        ensureSymbolEngine(symbol).then(async readyStore => {
          let bars = buildHistoryBars(readyStore, step, periodParams || {});
          if (!bars.length && !readyStore.sortedSecs.length) {
            await scheduleBackfill(readyStore, Date.now(), 0);
            bars = buildHistoryBars(readyStore, step, periodParams || {});
          }
          const standard = bars.map(standardBar);
          readyStore.lastGetBarsCount = standard.length;
          if (standard.length) {
            const tail = standard[standard.length - 1].time / 1000;
            const prev = store.historyTailByStep.get(step);
            store.historyTailByStep.set(step, Number.isFinite(prev) ? Math.max(prev, tail) : tail);
          }
          if (typeof onHistory === 'function') {
            onHistory(standard, { noData: standard.length === 0 });
          }
        }).catch(error => {
          if (typeof onError === 'function') onError(String(error));
        });
      };
    }

    if (typeof original.subscribeBars === 'function') {
      datafeed.subscribeBars = function (symbolInfo, resolution, onRealtime, subscriberUID, onResetCacheNeeded) {
        setResolution(resolution, 'subscribeBars');
        const step = secondsFromResolution(resolution);
        if (!step) return Reflect.apply(original.subscribeBars, this, arguments);
        const symbol = symbolFromInfo(symbolInfo, symbolInfo?.ticker);
        lastSubscribeSymbol = { resolved: symbol, ticker: symbolInfo?.ticker ?? null, name: symbolInfo?.name ?? null, resolution: String(resolution) };
        if (!symbol || typeof onRealtime !== 'function') return;

        const uid = String(subscriberUID || `kcex-tv-${symbol}-${step}-${Date.now()}`);
        const store = getStore(symbol);
        if (store) store.lastSubscribeAt = Date.now();
        const tail = store?.historyTailByStep.get(step);
        subscriptions.set(uid, {
          uid,
          symbol,
          step,
          callback: onRealtime,
          reset: onResetCacheNeeded,
          lastSentBucket: Number.isFinite(tail) ? tail : null,
          lastSignature: null
        });
        startDataPoll();
        ensureSymbolEngine(symbol).then(() => publishRealtime()).catch(error => {
          const s = getStore(symbol);
          if (s) s.lastError = 'Subscription startup: ' + String(error);
        });
      };
    }

    if (typeof original.unsubscribeBars === 'function') {
      datafeed.unsubscribeBars = function (subscriberUID) {
        const uid = String(subscriberUID || '');
        if (subscriptions.has(uid)) {
          subscriptions.delete(uid);
          stopDataPollIfIdle();
          return;
        }
        return Reflect.apply(original.unsubscribeBars, this, arguments);
      };
    }

    // getServerTime remains untouched; the countdown module reads it below.
  }

  // Patch the Datafeed at TradingView.widget construction time when possible.
  // This is earlier than discovering window.tradingview_<id> after the widget is created,
  // so the added seconds resolutions are present before the first onReady callback.
  function wrapWidgetConstructor(original) {
    if (typeof original !== 'function' || original.__kcexTvWidgetFactoryV5__) return original;

    function prepareArgs(args) {
      const nextArgs = args.slice();
      for (let i = 0; i < nextArgs.length; i++) {
        let arg = nextArgs[i];
        if (!arg || typeof arg !== 'object') continue;
        const df = arg.datafeed || arg.dataFeed || arg._datafeed;
        const looksLikeWidgetOptions = !!df ||
          Array.isArray(arg.enabled_features) ||
          (typeof arg.symbol === 'string' && ('interval' in arg || 'container' in arg || 'container_id' in arg));
        if (!looksLikeWidgetOptions) continue;
        if (df && typeof df === 'object') patchDatafeed(df, 'TradingView.widget(options)');
        const normalizedWidgetSymbol = normalizeResolveSymbolRequest(arg.symbol);
        if (normalizedWidgetSymbol && normalizedWidgetSymbol !== arg.symbol) {
          arg = { ...arg, symbol: normalizedWidgetSymbol };
        }
        // TradingView requires the seconds_resolution featureset in the widget
        // constructor. Adding resolution names to the Datafeed alone is insufficient.
        nextArgs[i] = withSecondsFeature(arg);
        widgetOptionsPatched = true;
      }
      return nextArgs;
    }

    let proxy;
    proxy = new Proxy(original, {
      construct(target, args, newTarget) {
        const prepared = prepareArgs(args);
        return Reflect.construct(target, prepared, newTarget === proxy ? target : newTarget);
      },
      apply(target, thisArg, args) {
        const prepared = prepareArgs(args);
        return Reflect.apply(target, thisArg, prepared);
      }
    });
    try { Object.defineProperty(proxy, '__kcexTvWidgetFactoryV5__', { value: true }); } catch (_) {}
    return proxy;
  }

  function armTradingViewNamespace(namespace) {
    if (!namespace || (typeof namespace !== 'object' && typeof namespace !== 'function')) return;
    if (namespace.__kcexTvNamespaceHookV5__) return;
    try { Object.defineProperty(namespace, '__kcexTvNamespaceHookV5__', { value: true, configurable: true }); } catch (_) {}

    try {
      let current = namespace.widget;
      if (typeof current === 'function') {
        const wrapped = wrapWidgetConstructor(current);
        if (wrapped !== current) namespace.widget = wrapped;
        return;
      }

      const descriptor = Object.getOwnPropertyDescriptor(namespace, 'widget');
      if (descriptor && descriptor.configurable === false) return;
      Object.defineProperty(namespace, 'widget', {
        configurable: true,
        enumerable: descriptor ? descriptor.enumerable : true,
        get() { return current; },
        set(value) { current = wrapWidgetConstructor(value); }
      });
    } catch (_) {}
  }

  function installTradingViewFactoryHook() {
    try {
      const descriptor = Object.getOwnPropertyDescriptor(window, 'TradingView');
      if (descriptor && descriptor.configurable === false) {
        armTradingViewNamespace(window.TradingView);
        return;
      }

      let namespace = window.TradingView;
      armTradingViewNamespace(namespace);
      Object.defineProperty(window, 'TradingView', {
        configurable: true,
        enumerable: descriptor ? descriptor.enumerable : true,
        get() { return namespace; },
        set(value) {
          namespace = value;
          armTradingViewNamespace(namespace);
        }
      });
    } catch (_) {
      try { armTradingViewNamespace(window.TradingView); } catch (_) {}
    }
  }

  function findDatafeeds() {
    const out = [];
    const seen = new WeakSet();

    const add = (candidate, source, frameWindow) => {
      if (!candidate || (typeof candidate !== 'object' && typeof candidate !== 'function')) return;
      if (seen.has(candidate)) return;
      let valid = false;
      try {
        valid = typeof candidate.onReady === 'function' &&
          typeof candidate.resolveSymbol === 'function' &&
          typeof candidate.getBars === 'function' &&
          typeof candidate.subscribeBars === 'function';
      } catch (_) {}
      if (!valid) return;
      seen.add(candidate);
      out.push({ datafeed: candidate, source, frameWindow });
    };

    const inspectWindow = (win, source) => {
      if (!win) return;
      try { add(win.datafeed, source + '.datafeed', win); } catch (_) {}
      try { add(win.dataFeed, source + '.dataFeed', win); } catch (_) {}
      try { add(win._datafeed, source + '._datafeed', win); } catch (_) {}

      let names = [];
      try { names = Object.getOwnPropertyNames(win); } catch (_) {}
      for (const key of names) {
        if (!/^tradingview_/i.test(key)) continue;
        let instance;
        try { instance = win[key]; } catch (_) { continue; }
        add(instance, source + '.' + key, win);
        for (const prop of ['datafeed', 'dataFeed', '_datafeed']) {
          try { add(instance?.[prop], source + '.' + key + '.' + prop, win); } catch (_) {}
        }
      }

      // A few KCEX builds expose the feed on the TradingView namespace itself.
      try {
        const tv = win.TradingView;
        add(tv?.datafeed, source + '.TradingView.datafeed', win);
      } catch (_) {}
    };

    inspectWindow(window, 'window');
    for (const frame of document.querySelectorAll('iframe[id^="tradingview_"], iframe[title="Financial Chart"]')) {
      try { inspectWindow(frame.contentWindow, `iframe.${frame.id || 'Financial Chart'}`); } catch (_) {}
    }
    return out;
  }

  function safeCall(obj, method, args = []) {
    try {
      if (obj && typeof obj[method] === 'function') return obj[method](...args);
    } catch (_) {}
    return null;
  }

  function discoverChartApis() {
    const frame = getTradingViewFrame();
    if (!frame) return { apis: [], inspected: [] };
    let fw;
    try { fw = frame.contentWindow; } catch (_) { return { apis: [], inspected: [] }; }
    if (!fw) return { apis: [], inspected: [] };

    const roots = [
      ['iframe.window', fw],
      ['iframe.tradingViewApi', safeCall(fw, 'tradingViewApi') || fw.tradingViewApi],
      ['iframe.TradingViewApi', fw.TradingViewApi],
      ['iframe.chartWidget', fw.chartWidget],
      ['iframe.chartWidgetCollection', fw.chartWidgetCollection],
      ['iframe.tvWidget', fw.tvWidget],
      ['iframe.widget', fw.widget]
    ];

    const queue = roots.filter(x => x[1] && (typeof x[1] === 'object' || typeof x[1] === 'function'))
      .map(([source, obj]) => ({ source, obj, depth: 0 }));
    const visited = new WeakSet();
    const apis = [];
    const inspected = [];
    const addApi = (obj, source, trustedPublicApi = false) => {
      if (!obj || (typeof obj !== 'object' && typeof obj !== 'function')) return;
      let hasResolutionGetter = false;
      try { hasResolutionGetter = typeof obj.resolution === 'function'; } catch (_) {}
      const privatePath = /\.model\(\)|chartWidgetCollection|iframe\.chartWidget(?:$|\.)/.test(source);
      if (typeof obj.setResolution === 'function' && (trustedPublicApi || (hasResolutionGetter && !privatePath))) {
        const entry = { api: obj, source, trustedPublicApi };
        if (!apis.some(x => x.api === obj)) apis.push(entry);
      }
    };

    let inspectedCount = 0;
    while (queue.length && inspectedCount < 500) {
      const item = queue.shift();
      inspectedCount++;
      const obj = item.obj;
      if (!obj || (typeof obj !== 'object' && typeof obj !== 'function') || visited.has(obj)) continue;
      visited.add(obj);

      const source = item.source;
      const methodNames = [];
      for (const method of ['activeChart', 'chart', 'setResolution', 'resolution', 'getActiveChartWidget', 'getChartWidgetAtIndex', 'model']) {
        try { if (typeof obj[method] === 'function') methodNames.push(method); } catch (_) {}
      }
      if (methodNames.length) inspected.push({ source, constructor: obj.constructor?.name || 'unknown', methods: methodNames });
      addApi(obj, source);

      // Standard public Charting Library API: widget.activeChart().setResolution().
      const activeChart = safeCall(obj, 'activeChart');
      if (activeChart && activeChart !== obj) {
        addApi(activeChart, source + '.activeChart()', true);
        queue.push({ source: source + '.activeChart()', obj: activeChart, depth: item.depth + 1 });
      }
      const chart = safeCall(obj, 'chart', [0]) || safeCall(obj, 'chart');
      if (chart && chart !== obj) {
        addApi(chart, source + '.chart(0)', true);
        queue.push({ source: source + '.chart(0)', obj: chart, depth: item.depth + 1 });
      }
      const activeWidget = safeCall(obj, 'getActiveChartWidget');
      if (activeWidget && activeWidget !== obj) {
        queue.push({ source: source + '.getActiveChartWidget()', obj: activeWidget, depth: item.depth + 1 });
      }
      const chartAtZero = safeCall(obj, 'getChartWidgetAtIndex', [0]);
      if (chartAtZero && chartAtZero !== obj) {
        queue.push({ source: source + '.getChartWidgetAtIndex(0)', obj: chartAtZero, depth: item.depth + 1 });
      }
      const model = safeCall(obj, 'model');
      if (model && model !== obj) {
        // Inspect model internals for diagnostics, but never call their private
        // setResolution methods; only the documented Chart API is used to switch.
        queue.push({ source: source + '.model()', obj: model, depth: item.depth + 1 });
      }

      if (item.depth < 3) {
        let keys = [];
        try { keys = Object.keys(obj); } catch (_) {}
        for (const key of keys.slice(0, 100)) {
          if (!/chart|widget|api|model|active|collection/i.test(key)) continue;
          let child;
          try { child = obj[key]; } catch (_) { continue; }
          if (child && (typeof child === 'object' || typeof child === 'function')) {
            queue.push({ source: source + '.' + key, obj: child, depth: item.depth + 1 });
          }
        }
      }
    }
    return { apis, inspected };
  }

  function getCachedChartDiscovery(force = false) {
    const now = Date.now();
    if (force || !chartApiCache || now - chartApiCacheAt > CHART_API_CACHE_MS) {
      chartApiCache = discoverChartApis();
      chartApiCacheAt = now;
    }
    return chartApiCache;
  }

  function readChartResolution(foundApis) {
    const apis = Array.isArray(foundApis) ? foundApis : getCachedChartDiscovery().apis;
    for (const item of apis) {
      try {
        if (typeof item.api.resolution === 'function') {
          const value = item.api.resolution();
          if (value !== undefined && value !== null) return String(value).toUpperCase();
        }
      } catch (_) {}
    }
    return null;
  }

  async function setTradingViewResolution(resolution) {
    const step = secondsFromResolution(resolution);
    if (!step) throw new Error('Unsupported seconds resolution: ' + resolution);

    // Re-scan and patch the active frame Datafeed before asking TradingView to switch.
    for (const item of findDatafeeds()) patchDatafeed(item.datafeed, item.source);

    let found = { apis: [], inspected: [] };
    for (let attempt = 0; attempt < 25; attempt++) {
      found = discoverChartApis();
      if (found.apis.length) break;
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    if (!found.apis.length) {
      const detail = found.inspected.slice(0, 20);
      throw new Error('TradingView public setResolution API not found. Inspected: ' + JSON.stringify(detail));
    }

    const errors = [];
    for (const item of found.apis) {
      try {
        const result = await Promise.resolve(item.api.setResolution(resolution));
        if (result === false) {
          errors.push(item.source + ': setResolution returned false');
          continue;
        }

        // Confirm the active chart really changed; do not claim success from menu color alone.
        let confirmed = false;
        for (let i = 0; i < 25; i++) {
          const current = readChartResolution(found.apis);
          if (current === resolution) { confirmed = true; break; }
          await new Promise(resolve => setTimeout(resolve, 80));
        }

        if (!confirmed && result !== true) {
          errors.push(item.source + ': request did not confirm chart resolution; current=' + (readChartResolution(found.apis) || 'unknown'));
          continue;
        }

        setResolution(resolution, 'toolbar-click');
        markSecondResolutionSelected(resolution);
        lastSetResolutionResult = {
          requested: resolution,
          confirmed,
          source: item.source,
          apiResult: result === undefined ? 'undefined' : result
        };
        lastSetResolutionError = null;
        updateBadge();
        return lastSetResolutionResult;
      } catch (error) {
        errors.push(item.source + ': ' + String(error));
      }
    }

    throw new Error(errors.join(' | ') || 'No usable TradingView API accepted the requested resolution');
  }

  function handleSecondIntervalClick(event) {
    if (!isTradingViewActive()) return;
    const resolution = getResolutionFromElement(event.target);
    if (!resolution) return;

    // The Original chart engine also adds these menu entries. When TradingView is
    // visible, route the click to its own Charting Library API and prevent the
    // Original KLineCharts click handler from consuming it.
    event.preventDefault();
    event.stopPropagation();
    if (typeof event.stopImmediatePropagation === 'function') event.stopImmediatePropagation();

    const previousResolution = activeResolution || readChartResolution() || '1';
    setResolution(resolution, 'toolbar-click-pending');
    markSecondResolutionSelected(resolution);
    updateBadge();
    setTradingViewResolution(resolution).catch(error => {
      lastSetResolutionError = String(error);
      lastSetResolutionResult = { requested: resolution, confirmed: false, error: lastSetResolutionError };
      currentBadge && (currentBadge.title = 'TradingView resolution switch failed: ' + lastSetResolutionError);
      console.warn('[KCEX Enhancer TV] Could not switch resolution:', error);
      // Keep the timer honest by restoring the chart's actual interval when readable.
      const actual = readChartResolution();
      if (actual) setResolution(actual, 'chart-readback');
      else setResolution(previousResolution, 'restore-after-failed-switch');
      markSecondResolutionSelected(actual || previousResolution);
      updateBadge();
    });
  }

  function installSecondIntervalClickBridge() {
    document.addEventListener('click', handleSecondIntervalClick, true);
  }

  function normalizeServerTime(value) {
    if (typeof value === 'string' && !/^\d+(\.\d+)?$/.test(value)) {
      const parsed = Date.parse(value);
      return Number.isFinite(parsed) ? parsed : null;
    }
    const n = Number(value);
    if (!Number.isFinite(n) || n <= 0) return null;
    return n < 1e12 ? n * 1000 : n;
  }

  function syncServerClock(datafeed) {
    if (!datafeed || typeof datafeed.getServerTime !== 'function') return;
    const now = Date.now();
    if (now - lastServerSyncAt < SERVER_SYNC_MS) return;
    lastServerSyncAt = now;
    let settled = false;
    const accept = value => {
      if (settled) return;
      const serverMs = normalizeServerTime(value);
      if (!Number.isFinite(serverMs)) return;
      settled = true;
      const offset = serverMs - Date.now();
      if (Math.abs(offset) < 10 * 60 * 1000) clockOffsetMs = offset;
    };
    try {
      const returned = datafeed.getServerTime(accept);
      if (typeof returned === 'number' || typeof returned === 'string') accept(returned);
    } catch (_) {}
  }

  // ---------- Countdown UI: independent from the Original chart ----------
  function isVisible(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 150 || rect.height < 100) return false;
    const style = getComputedStyle(el);
    return style.display !== 'none' && style.visibility !== 'hidden' && Number(style.opacity || 1) > 0;
  }

  function findTradingViewHost() {
    const frame = getTradingViewFrame();
    if (!frame) return null;
    return document.getElementById('tv_chart_container') || frame.parentElement ||
      document.querySelector('[class*="tradingView_chartContainer"]');
  }

  function getMainSeriesPriceAndCoordinate(found = getCachedChartDiscovery()) {
    const frame = getTradingViewFrame();
    const host = findTradingViewHost();
    if (!frame || !host) return null;

    const store = stores.get(normalizeSymbol(
      (location.pathname.match(/\/exchange\/([A-Z0-9_]+)/i) || [])[1]
    ));
    let price = Number(store?.lastPrice);
    if (!Number.isFinite(price) || price <= 0) {
      const secs = store?.sortedSecs || [];
      const last = secs.length ? store.liveSecMap.get(secs[secs.length - 1]) : null;
      price = Number(last?.close);
    }
    if (!Number.isFinite(price) || price <= 0) return null;

    for (const item of (found?.apis || [])) {
      try {
        const panes = typeof item.api.getPanes === 'function' ? item.api.getPanes() : [];
        if (!Array.isArray(panes) || !panes.length) continue;
        const pane = panes.find(p => typeof p.getMainSourcePriceScale === 'function') || panes[0];
        const scale = typeof pane.getMainSourcePriceScale === 'function'
          ? pane.getMainSourcePriceScale()
          : (typeof pane.getRightPriceScales === 'function' ? pane.getRightPriceScales()[0] : null);
        if (!scale || typeof scale.priceToCoordinate !== 'function') continue;
        const coordinate = Number(scale.priceToCoordinate(price));
        if (!Number.isFinite(coordinate)) continue;

        const frameRect = frame.getBoundingClientRect();
        const hostRect = host.getBoundingClientRect();
        const paneHeight = typeof pane.getHeight === 'function' ? Number(pane.getHeight()) : NaN;
        let paneTopInFrame = 0;

        // The public API returns a coordinate relative to the pane top. Find
        // the matching TradingView plot canvas so the overlay shares that origin.
        try {
          const doc = frame.contentDocument;
          if (doc) {
            const nodes = [...doc.querySelectorAll('canvas, [class*="chart-markup-table"], [class*="pane"]')];
            const matches = nodes.map(el => ({
              rect: el.getBoundingClientRect(),
              el
            })).filter(x => x.rect.width > 180 && x.rect.height > 80 &&
              (!Number.isFinite(paneHeight) || Math.abs(x.rect.height - paneHeight) <= Math.max(18, paneHeight * 0.22)));
            if (matches.length) {
              matches.sort((a, b) => {
                const ah = Number.isFinite(paneHeight) ? Math.abs(a.rect.height - paneHeight) : 0;
                const bh = Number.isFinite(paneHeight) ? Math.abs(b.rect.height - paneHeight) : 0;
                return ah - bh || a.rect.top - b.rect.top;
              });
              paneTopInFrame = matches[0].rect.top;
            }
          }
        } catch (_) {}

        return {
          top: frameRect.top - hostRect.top + paneTopInFrame + coordinate,
          price,
          coordinate,
          paneTopInFrame,
          source: item.source
        };
      } catch (_) {}
    }
    return null;
  }

  function ensureBadge() {
    const host = findTradingViewHost();
    if (!host) {
      if (currentBadge) currentBadge.style.display = 'none';
      currentHost = null;
      return;
    }
    if (currentHost !== host || !currentBadge || !currentBadge.isConnected) {
      currentHost = host;
      if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
      let badge = host.querySelector(`#${BADGE_ID}`);
      if (!badge) {
        badge = document.createElement('div');
        badge.id = BADGE_ID;
        badge.setAttribute('aria-label', 'KCEX TradingView candle close countdown');
        badge.style.cssText = [
          'position:absolute','top:8px','right:12px','z-index:2147483000',
          'display:flex','align-items:center','gap:7px','padding:5px 9px',
          'border:1px solid rgba(14,203,129,.35)','border-radius:5px',
          'background:rgba(15,19,25,.88)','color:#eaecef',
          'font:600 11px/1.2 Arial,sans-serif','letter-spacing:.2px',
          'pointer-events:none','user-select:none','white-space:nowrap',
          'box-shadow:0 2px 8px rgba(0,0,0,.22)'
        ].join(';');
        host.appendChild(badge);
      }
      currentBadge = badge;
      lastBadgeText = '';
    }
    currentBadge.style.display = 'flex';
  }

  function formatCountdown(remainingMs, intervalMs) {
    const totalSeconds = Math.max(0, Math.ceil(remainingMs / 1000));
    if (intervalMs < 60000) return `${String(totalSeconds).padStart(2, '0')}s`;
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    if (hours > 0) return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  function updateBadge() {
    ensureBadge();
    if (!currentBadge) return;
    const chartDiscovery = getCachedChartDiscovery();
    const actualResolution = readChartResolution(chartDiscovery.apis);
    if (actualResolution) {
      setResolution(actualResolution, 'chart-readback');
      markSecondResolutionSelected(secondsFromResolution(actualResolution) ? actualResolution : '');
    }
    const resolution = activeResolution || resolutionFromUrl();
    const intervalMs = resolutionToMs(resolution);
    if (!intervalMs) {
      const text = 'TV TIMER  --:--';
      if (text !== lastBadgeText) {
        currentBadge.textContent = text;
        currentBadge.style.borderColor = 'rgba(240,185,11,.35)';
        currentBadge.style.color = '#f0b90b';
        lastBadgeText = text;
      }
      return;
    }
    const now = nowMs();
    const elapsed = ((now % intervalMs) + intervalMs) % intervalMs;
    let remaining = intervalMs - elapsed;
    if (remaining < 80) remaining = intervalMs;
    const resolutionLabel = secondsFromResolution(resolution)
      ? resolution.replace('S', 's')
      : (/^\d+$/.test(resolution) ? `${resolution}m` : resolution);
    const text = `${resolution}  CLOSE  ${formatCountdown(remaining, intervalMs)}`;
    if (text !== lastBadgeText) {
      currentBadge.textContent = text;
      const urgent = remaining <= Math.min(2000, intervalMs * 0.25);
      currentBadge.style.borderColor = urgent ? 'rgba(246,70,93,.55)' : 'rgba(14,203,129,.35)';
      currentBadge.style.color = urgent ? '#f6465d' : '#0ecb81';
      lastBadgeText = text;
    }
  }

  function scan() {
    try { armTradingViewNamespace(window.TradingView); } catch (_) {}
    for (const item of findDatafeeds()) {
      patchDatafeed(item.datafeed, item.source);
      syncServerClock(item.datafeed);
    }
    if (!activeResolution) {
      const fromUrl = resolutionFromUrl();
      if (fromUrl) setResolution(fromUrl, 'url');
    }
    window.__KCEX_TV_SECONDS_ENGINE_STATUS__ = {
      version: '2.9',
      activeResolution,
      resolutionSource,
      datafeedsPatched: patchedDatafeedCount,
      datafeedSources: [...datafeedSourcesSeen],
      widgetOptionsPatched,
      lastSetResolutionResult,
      lastSetResolutionError,
      lastResolveSymbolRequest,
      lastResolvedMarketSymbol,
      lastGetBarsSymbol,
      lastSubscribeSymbol,
      subscriptions: [...subscriptions.values()].map(x => ({ symbol: x.symbol, step: x.step, uid: x.uid })),
      stores: [...stores.values()].map(store => ({
        symbol: store.symbol,
        dbLoaded: store.dbLoaded,
        buckets: store.sortedSecs.length,
        firstBucket: store.sortedSecs[0] ?? null,
        lastBucket: store.sortedSecs[store.sortedSecs.length - 1] ?? null,
        acceptedTrades: store.acceptedTrades || 0,
        restAcceptedTrades: store.restAcceptedTrades || 0,
        wsAcceptedTrades: store.wsAcceptedTrades || 0,
        rejectedCutoverTrades: store.rejectedCutoverTrades || 0,
        socketReadyState: store.socket?.readyState ?? null,
        lastWsMessageAt: store.lastWsMessageAt || null,
        lastWsChannel: store.lastWsChannel,
        lastRestBackfillAt: store.lastRestBackfillAt || null,
        lastGetBarsAt: store.lastGetBarsAt || null,
        lastGetBarsResolution: store.lastGetBarsResolution,
        lastGetBarsCount: store.lastGetBarsCount,
        lastError: store.lastError
      }))
    };
    ensureBadge();
  }

  function start() {
    if (uiPollTimer) clearInterval(uiPollTimer);
    if (timerTickTimer) clearInterval(timerTickTimer);
    uiPollTimer = setInterval(scan, UI_POLL_MS);
    timerTickTimer = setInterval(updateBadge, TIMER_TICK_MS);
    scan();
    updateBadge();
  }

  installTradingViewFactoryHook();
  installSecondIntervalClickBridge();
  start();

  window.addEventListener('pagehide', () => {
    document.removeEventListener('click', handleSecondIntervalClick, true);
    if (uiPollTimer) clearInterval(uiPollTimer);
    if (timerTickTimer) clearInterval(timerTickTimer);
    if (dataPollTimer) clearInterval(dataPollTimer);
    if (dbFlushTimer) clearTimeout(dbFlushTimer);
    for (const store of stores.values()) {
      store.socketGeneration++;
      if (store.socketReconnectTimer) clearTimeout(store.socketReconnectTimer);
      if (store.socketPingTimer) clearInterval(store.socketPingTimer);
      try { store.socket?.close(1000, 'pagehide'); } catch (_) {}
    }
    if (pendingDbWrites.size) flushPendingDbWrites();
  }, { once: true });
})();
