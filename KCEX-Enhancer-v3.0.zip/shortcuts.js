(() => {
  'use strict';
  if (window.__KCEX_SHORTCUTS_V3__) return;
  window.__KCEX_SHORTCUTS_V3__ = true;

  const KEY = 'kcex_v3_settings';
  const SEL = {
    long: '[data-testid="futures-exchange-order-form-open-long-button"]',
    short: '[data-testid="futures-exchange-order-form-open-short-button"]',
    close: '[data-testid="futures-exchange-position-current-market-close-button"]',
    slider: '.component_vOpenPosition__iGi9N .ant-slider [role="slider"]',
    tpSlToggle: '[data-testid="futures-exchange-order-form-tpsl-enable-checkbox"]'
  };
  const DEFAULTS = {
    tradeSettingsEnabled: false,
    sizeEnabled: false,
    sizePercent: 40,
    slEnabled: false,
    slTicks: 10,
    tpEnabled: false,
    tpTicks: 100,
    autoConfirm: true
  };
  let settings = { ...DEFAULTS };
  let pendingSide = null;
  let pendingAt = 0;
  let actionLock = false;
  let lastHotkeyAt = 0;
  let sliderSyncTimer = 0;
  let currentSymbol = '';
  let cachedLastPrice = NaN;
  let tickerTimer = 0;
  let pendingExistingDialogs = new Set();
  const contractCache = new Map();
  const pageDoc = (() => { try { return window.top.document; } catch (_) { return document; } })();

  const storageGet = () => new Promise(resolve => {
    try { chrome.storage.local.get(KEY, r => resolve({ ...DEFAULTS, ...(r?.[KEY] || {}) })); }
    catch (_) { resolve({ ...DEFAULTS }); }
  });
  const storageListen = () => {
    try { chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[KEY]) {
        settings = { ...DEFAULTS, ...(changes[KEY].newValue || {}) };
        scheduleSliderSync();
        startTickerRefresh();
        ensureContractMeta(getSymbol());
      }
    }); } catch (_) {}
  };

  function isTyping(target) {
    if (!target) return false;
    const el = target.nodeType === 1 ? target : target.parentElement;
    return !!el?.closest('input, textarea, select, [contenteditable="true"], [role="textbox"]');
  }
  function getSymbol() {
    let href = ''; try { href = pageDoc.defaultView.location.href; } catch (_) { href = location.href; }
    const m = href.match(/([A-Z0-9]{2,}_[A-Z0-9]{2,})/i);
    if (m) return m[1].toUpperCase();
    const text = pageDoc.querySelector('[class*="symbol"], [data-testid*="symbol"]')?.textContent || '';
    const n = text.match(/[A-Z0-9]{2,}_[A-Z0-9]{2,}/i);
    return n ? n[0].toUpperCase() : '';
  }
  function findSlider() { return pageDoc.querySelector(SEL.slider); }
  function setSliderPercent(percent) {
    const handle = findSlider();
    if (!handle) return false;
    const value = Math.max(0, Math.min(100, Number(percent) || 0));
    if (Number(handle.getAttribute('aria-valuenow')) === value) return true;
    const fiberKey = Object.keys(handle).find(k => k.startsWith('__reactProps$'));
    const parent = handle.parentElement;
    const parentFiberKey = parent && Object.keys(parent).find(k => k.startsWith('__reactProps$'));
    const props = (fiberKey && handle[fiberKey]) || (parentFiberKey && parent[parentFiberKey]);
    if (props && typeof props.onChange === 'function') {
      try { props.onChange(value); return true; } catch (_) {}
    }
    const track = handle.closest('.ant-slider');
    if (!track) return false;
    const rect = track.getBoundingClientRect();
    const x = rect.left + rect.width * value / 100;
    const y = rect.top + rect.height / 2;
    track.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, buttons: 1 }));
    pageDoc.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y }));
    return true;
  }
  function scheduleSliderSync() {
    if (!settings.tradeSettingsEnabled || !settings.sizeEnabled) return;
    clearTimeout(sliderSyncTimer);
    sliderSyncTimer = setTimeout(() => setSliderPercent(settings.sizePercent), 80);
  }
  function getLastPrice() {
    const sharedPrice = Number(pageDoc.documentElement?.dataset?.kcexV3LastPrice);
    if (sharedPrice > 0) cachedLastPrice = sharedPrice;
    if (Number.isFinite(cachedLastPrice) && cachedLastPrice > 0) return cachedLastPrice;
    const candidates = [...pageDoc.querySelectorAll('[class*="lastPrice"], [class*="last-price"], [data-testid*="last-price"]')];
    for (const el of candidates) {
      const t = (el.textContent || '').trim().replace(/,/g, '');
      if (/^\d+(?:\.\d+)?$/.test(t) && Number(t) > 0) return Number(t);
    }
    return NaN;
  }
  async function refreshTicker(symbol) {
    if (!symbol || window !== window.top) return;
    try {
      const r = await fetch(`/fapi/v1/contract/ticker?symbol=${encodeURIComponent(symbol)}`, { credentials: 'include' });
      if (!r.ok) return;
      const j = await r.json();
      const rows = Array.isArray(j) ? j : (Array.isArray(j?.data) ? j.data : [j?.data || j]);
      const row = rows.find(x => (x?.symbol || '').toUpperCase() === symbol) || rows[0];
      const price = Number(row?.lastPrice ?? row?.last ?? row?.price);
      if (price > 0) { cachedLastPrice = price; pageDoc.documentElement.dataset.kcexV3LastPrice = String(price); }
    } catch (_) {}
  }
  function startTickerRefresh() {
    clearInterval(tickerTimer);
    if (!settings.tradeSettingsEnabled || (!settings.slEnabled && !settings.tpEnabled)) return;
    refreshTicker(getSymbol());
    tickerTimer = setInterval(() => refreshTicker(getSymbol()), 650);
  }
  async function loadContractMeta(symbol) {
    if (!symbol) return null;
    const urls = [
      `/fapi/v1/contract/detail?symbol=${encodeURIComponent(symbol)}`,
      `/fapi/v1/contract/detail`
    ];
    for (const url of urls) {
      try {
        const r = await fetch(url, { credentials: 'include' });
        if (!r.ok) continue;
        const j = await r.json();
        const rows = Array.isArray(j) ? j : (Array.isArray(j?.data) ? j.data : [j?.data || j]);
        const row = rows.find(x => (x?.symbol || x?.contractCode || '').toUpperCase() === symbol) || rows[0];
        const pu = Number(row?.pu ?? row?.priceUnit ?? row?.tickSize);
        if (pu > 0) return { pu, raw: row };
      } catch (_) {}
    }
    return null;
  }
  function ensureContractMeta(symbol) {
    if (!symbol || contractCache.has(symbol)) return;
    const sharedPu = Number(pageDoc.documentElement?.dataset?.kcexV3Pu);
    if (sharedPu > 0) { contractCache.set(symbol, { pu: sharedPu }); return; }
    if (window !== window.top) return;
    contractCache.set(symbol, null);
    loadContractMeta(symbol).then(meta => {
      contractCache.set(symbol, meta);
      if (meta?.pu) pageDoc.documentElement.dataset.kcexV3Pu = String(meta.pu);
    });
  }
  function setInputValue(input, value) {
    if (!input) return false;
    const proto = Object.getPrototypeOf(input);
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) setter.call(input, String(value)); else input.value = String(value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function prepareTPSL(side) {
    if (!settings.tradeSettingsEnabled) return true;
    const wantSL = !!settings.slEnabled;
    const wantTP = !!settings.tpEnabled;
    const toggle = pageDoc.querySelector(SEL.tpSlToggle);
    const wantTPSL = wantSL || wantTP;
    if (toggle && !!toggle.checked !== wantTPSL) toggle.click();
    if (!wantTPSL) return true;
    const symbol = getSymbol();
    const meta = contractCache.get(symbol) || (Number(pageDoc.documentElement?.dataset?.kcexV3Pu) > 0 ? { pu: Number(pageDoc.documentElement.dataset.kcexV3Pu) } : null);
    const last = getLastPrice();
    if (!meta?.pu || !Number.isFinite(last)) return false;
    const decimals = Math.min(14, Math.max(0, (String(meta.pu).split('.')[1] || '').length));
    const tp = pageDoc.querySelector('input[placeholder*="TP Price"], input[placeholder="TP Price"]');
    const sl = pageDoc.querySelector('input[placeholder*="SL Price"], input[placeholder="SL Price"]');
    if ((wantSL && !sl) || (wantTP && !tp)) return false;
    if (wantSL) {
      const p = last + (side === 'long' ? -1 : 1) * meta.pu * Math.max(1, Number(settings.slTicks) || 1);
      setInputValue(sl, p.toFixed(decimals));
    }
    if (wantTP) {
      const p = last + (side === 'long' ? 1 : -1) * meta.pu * Math.max(1, Number(settings.tpTicks) || 1);
      setInputValue(tp, p.toFixed(decimals));
    }
    return true;
  }
  function findConfirmDialog() {
    const dialogs = [...pageDoc.querySelectorAll('.ant-modal[role="dialog"], [role="dialog"].ant-modal')];
    for (const dialog of dialogs) {
      if (!dialog.isConnected || dialog.getAttribute('aria-hidden') === 'true' || pendingExistingDialogs.has(dialog)) continue;
      const confirm = dialog.querySelector('button.ant-btn-primary:not([disabled])');
      if (confirm) return confirm;
    }
    return null;
  }
  const observer = new MutationObserver(() => {
    if (!pendingSide || !settings.autoConfirm) return;
    if (Date.now() - pendingAt > 12000) { pendingSide = null; return; }
    const btn = findConfirmDialog();
    if (btn && !btn.dataset.kcexAutoConfirmed) {
      btn.dataset.kcexAutoConfirmed = '1';
      btn.click();
      pendingSide = null;
    }
    scheduleSliderSync();
  });
  try { observer.observe(pageDoc.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'aria-hidden'] }); } catch (_) {}

  function openPosition(side) {
    if (actionLock) return;
    actionLock = true;
    pendingSide = null;
    try {
      if (settings.tradeSettingsEnabled && settings.sizeEnabled) scheduleSliderSync();
      if (!prepareTPSL(side)) { actionLock = false; return; }
      pendingExistingDialogs = new Set(pageDoc.querySelectorAll('.ant-modal[role="dialog"], [role="dialog"].ant-modal'));
      const button = pageDoc.querySelector(side === 'long' ? SEL.long : SEL.short);
      if (button && !button.disabled) {
        button.click();
        pendingSide = side;
        pendingAt = Date.now();
      }
    } finally {
      setTimeout(() => { actionLock = false; }, 350);
    }
  }
  function onKeyDown(e) {
    if (!e.ctrlKey || e.altKey || e.shiftKey || e.metaKey || e.repeat || isTyping(e.target)) return;
    const now = Date.now();
    if (now - lastHotkeyAt < 180) return;
    let action = null;
    if (e.code === 'ArrowUp') action = 'long';
    else if (e.code === 'ArrowDown') action = 'short';
    else if (e.code === 'ArrowRight') action = 'close';
    if (!action) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    lastHotkeyAt = now;
    if (action === 'long' || action === 'short') openPosition(action);
    else {
      const btn = pageDoc.querySelector(SEL.close);
      if (btn && !btn.disabled) btn.click();
    }
  }
  window.addEventListener('keydown', onKeyDown, true);
  pageDoc.addEventListener('visibilitychange', () => { if (!pageDoc.hidden) { scheduleSliderSync(); startTickerRefresh(); } });
  const routeObserver = new MutationObserver(() => {
    const s = getSymbol();
    if (s && s !== currentSymbol) { currentSymbol = s; ensureContractMeta(s); refreshTicker(s); scheduleSliderSync(); }
  });
  routeObserver.observe(pageDoc.documentElement, { childList: true, subtree: true });
  currentSymbol = getSymbol();
  ensureContractMeta(currentSymbol);

  storageGet().then(s => { settings = s; storageListen(); scheduleSliderSync(); ensureContractMeta(getSymbol()); startTickerRefresh(); });
})();
