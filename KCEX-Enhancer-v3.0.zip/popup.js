(() => {
  const KEY='kcex_v3_settings';
  const defaults={tradeSettingsEnabled:false,sizeEnabled:false,sizePercent:40,slEnabled:false,slTicks:10,tpEnabled:false,tpTicks:100,autoConfirm:true};
  const ids=Object.keys(defaults); const el=id=>document.getElementById(id);
  function save(){const v={};for(const id of ids){const node=el(id);v[id]=node.type==='checkbox'?node.checked:(node.type==='range'||node.type==='number'?Number(node.value):node.value)}chrome.storage.local.set({[KEY]:v});el('tradeFields').classList.toggle('disabled',!v.tradeSettingsEnabled);el('sizeOut').textContent=v.sizePercent+'%'}
  chrome.storage.local.get(KEY,r=>{const v={...defaults,...(r[KEY]||{})};for(const id of ids){const node=el(id);if(node.type==='checkbox')node.checked=!!v[id];else node.value=v[id]}el('tradeFields').classList.toggle('disabled',!v.tradeSettingsEnabled);el('sizeOut').textContent=v.sizePercent+'%'});
  for(const id of ids)el(id).addEventListener('input',save);
  for(const id of ids)el(id).addEventListener('change',save);
})();
