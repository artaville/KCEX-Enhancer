const DEFAULT_STATE = {
  positionSize: "",
  tpEnabled: false,
  slEnabled: false,
  tpValue: "",
  slValue: "",
  tpType: "%",
  slType: "%",
  sizeType: "%",
  showPanel: true
};

chrome.storage.local.get(DEFAULT_STATE, state => {
  posSize.value = state.positionSize;
  tpCheck.checked = state.tpEnabled;
  slCheck.checked = state.slEnabled;
  tpVal.value = state.tpValue;
  slVal.value = state.slValue;
  tpType.value = state.tpType;
  slType.value = state.slType;
  sizeType.value = state.sizeType;
  showPanel.checked = state.showPanel;
});

["posSize", "tpVal", "slVal", "tpCheck", "slCheck", "showPanel"].forEach(id => {
  document.getElementById(id).addEventListener("input", () => {
    chrome.storage.local.set({
      positionSize: posSize.value,
      tpEnabled: tpCheck.checked,
      slEnabled: slCheck.checked,
      tpValue: tpVal.value,
      slValue: slVal.value,
      slType: slType.value,
      tpType: tpType.value,
      sizeType: sizeType.value,
      showPanel: showPanel.checked
    });
  });
});

["tpType"].forEach(id => {
  document.getElementById(id).addEventListener("click", () => {
    chrome.storage.local.set({
      positionSize: posSize.value,
      tpEnabled: tpCheck.checked,
      slEnabled: slCheck.checked,
      tpValue: tpVal.value,
      slValue: slVal.value,
      slType: slType.value,
      tpType: tpType.value == "%" ? "$":"%",
      sizeType: sizeType.value,
      showPanel: showPanel.checked
    });
  });
});

["slType"].forEach(id => {
  document.getElementById(id).addEventListener("click", () => {
    chrome.storage.local.set({
      positionSize: posSize.value,
      tpEnabled: tpCheck.checked,
      slEnabled: slCheck.checked,
      tpValue: tpVal.value,
      slValue: slVal.value,
      slType: slType.value == "%" ? "$":"%",
      tpType: tpType.value,
      sizeType: sizeType.value,
      showPanel: showPanel.checked
    });
  });
});

["sizeType"].forEach(id => {
  document.getElementById(id).addEventListener("click", () => {
    chrome.storage.local.set({
      positionSize: posSize.value,
      tpEnabled: tpCheck.checked,
      slEnabled: slCheck.checked,
      tpValue: tpVal.value,
      slValue: slVal.value,
      slType: slType.value,
      tpType: tpType.value,
      sizeType: sizeType.value == "%" ? "$":"%",
      showPanel: showPanel.checked
    });
  });
});

document.getElementById("slType").addEventListener("click", () => {
        if(document.getElementById("slType").value == "%")
            document.getElementById("slType").value = "$";
        else
            document.getElementById("slType").value = "%";
    });

document.getElementById("tpType").addEventListener("click", () => {
        if(document.getElementById("tpType").value == "%")
            document.getElementById("tpType").value = "$";
        else
            document.getElementById("tpType").value = "%";
    });

document.getElementById("sizeType").addEventListener("click", () => {
    if(document.getElementById("sizeType").value == "%")
        document.getElementById("sizeType").value = "$";
    else
        document.getElementById("sizeType").value = "%";
  });