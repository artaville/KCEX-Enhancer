(() => {
  /**********************
   * STORAGE
   **********************/
  const DEFAULT_STATE = {
    positionSize: "",
    tpEnabled: false,
    slEnabled: false,
    tpValue: "",
    slValue: "",
    tpType: "%",
    slType: "%",
    sizeType: "%",
    panelX: null,
    panelY: null,
    showPanel: true
  };

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;

    if (changes.positionSize)
        posSize.value = changes.positionSize.newValue ?? "";

    if (changes.tpEnabled)
        tpCheck.checked = changes.tpEnabled.newValue;

    if (changes.slEnabled)
        slCheck.checked = changes.slEnabled.newValue;

    if (changes.tpValue)
        tpVal.textContent = changes.tpValue.newValue ?? "";

    if (changes.slValue)
        slVal.textContent = changes.slValue.newValue ?? "";

    if (changes.slType)
        slType.textContent = changes.slType.newValue ?? "";

    if (changes.tpType)
        tpType.textContent = changes.tpType.newValue ?? "";

    if (changes.sizeType)
        sizeType.textContent = changes.sizeType.newValue ?? "";

    if ("showPanel" in changes) {
        panel.style.setProperty(
          "display",
          changes.showPanel.newValue ? "flex" : "none",
          "important"
        );
    }
  });

  const loadState = () =>
    new Promise(res => chrome.storage.local.get(DEFAULT_STATE, res));

  const saveState = data => chrome.storage.local.set(data);

  /**********************
   * UI PANEL
   **********************/
  // const parentpanel = document.createElement("div");
  // parentpanel.id = "mexcc";
  const panel = document.createElement("div");
  panel.id = "mexc-bar";
  panel.innerHTML = `
  <span class="title">MEXC</span>

<div class="grp">
  <span>Size</span>
  <span id="posSize"></span>
  <span id="sizeType">%</span>
</div>

<div class="grp">
  <input id="tpCheck" type="checkbox">
  <span>TP</span>
  <span id="tpVal"></span>
  <span id="tpType">%</span>
</div>

<div class="grp">
  <input id="slCheck" type="checkbox">
  <span>SL</span>
  <span id="slVal"></span>
  <span id="slType">%</span>
</div>

<button id="applybt">Apply</button>


  `;
  // parentpanel.appendChild(panel)
  document.body.appendChild(panel);

   document.getElementById("applybt").addEventListener("click", () => {
    fill()
  });

  loadState().then(s => {
    panel.style.setProperty(
      "display",
      s.showPanel ? "flex" : "none",
      "important"
    );
    posSize.textContent = s.positionSize;
    tpCheck.checked = s.tpEnabled;
    slCheck.checked = s.slEnabled;
    tpVal.textContent = s.tpValue;
    slVal.textContent = s.slValue;
    tpType.textContent = s.tpType;
    slType.textContent = s.slType;
    sizeType.textContent = s.sizeType;

    if (s.panelX !== null) {
      panel.style.left = s.panelX + "px";
      panel.style.top = s.panelY + "px";
      panel.style.transform = "none";
    }
  });


  ["tpCheck", "slCheck"].forEach(id => {
    document.getElementById(id).addEventListener("input", () => {
      chrome.storage.local.set({
        tpEnabled: tpCheck.checked,
        slEnabled: slCheck.checked,
      });
    });
  });

  /**********************
   * DRAGGABLE PANEL
   **********************/
  let dragging = false, dx = 0, dy = 0;
  const DRAG_HEIGHT = 60;

  panel.addEventListener("mousedown", e => {
    const rect = panel.getBoundingClientRect();
    // if (e.clientY - rect.top > DRAG_HEIGHT) return;
    panel.style.transform = "none"; // 🔥 important
    dragging = true;
    dx = e.clientX - panel.offsetLeft;
    dy = e.clientY - panel.offsetTop;
  });

  document.addEventListener("mousemove", e => {
    if (!dragging) return;
    panel.style.left = e.clientX - dx + "px";
    panel.style.top = e.clientY - dy + "px";
  });

  document.addEventListener("mouseup", () => {
    if (!dragging) return;
    dragging = false;
    saveState({
      panelX: panel.offsetLeft,
      panelY: panel.offsetTop
    });
  });

  /**********************
   * DOM HELPERS
   **********************/
  const waitFor = (fn, t = 4000) =>
    new Promise((res, rej) => {
      const start = Date.now();
      const i = setInterval(() => {
        const r = fn();
        if (r) {
          clearInterval(i);
          res(r);
        }
        if (Date.now() - start > t) {
          clearInterval(i);
          rej();
        }
      }, 100);
    });

  const findButton = txt =>
    [...document.querySelectorAll("button")]
      .find(b => b.innerText.trim().includes(txt));

  const findInputByPlaceholder = txt =>
    [...document.querySelectorAll("input")]
      .find(i => i.placeholder && i.placeholder.includes(txt));
    
  const findInputByPlaceholderLast = txt =>
    [...document.querySelectorAll("input")]
      .findLast(i => i.placeholder && i.placeholder.includes(txt));

  const findInputByLabel = txt =>
    [...document.querySelectorAll("input")]
      .find(i => i.parentElement.parentElement.parentElement.parentElement.innerHTML.includes(txt));

  const click = el => el.click();//el => el && el.dispatchEvent(new MouseEvent("click", { bubbles: true }));

  const setInput = (el, val) => {
    if (!el) return;
    el.value = val;
    el.dispatchEvent(new Event("input", { bubbles: true }));
  };

  function changeTag(element, newTag) {
      // Create the new element
      const newElement = document.createElement(newTag);

      // Copy attributes
      for (let attr of element.attributes) {
          newElement.setAttribute(attr.name, attr.value);
      }

      // Move all child nodes
      while (element.firstChild) {
          newElement.appendChild(element.firstChild);
      }

      // Replace the old element with the new one in the DOM
      element.parentNode.replaceChild(newElement, element);

      return newElement; // in case you want to use it
  }
  async function fill(direction)
  {
    try
    {
      const state = await loadState();

      const balance = parseFloat(document.querySelector('span[class*="AssetsItem_num"]').innerText.replace(",", "").replace(" ", "").replace("USDT", "").substring(1));

      var leverage = document.querySelectorAll('span[class*="LeverageEdit_leverageTextWrapper"]')[1].innerText;
      leverage = parseInt(leverage.substring(0, leverage.length-1));


      const qty = await waitFor(() =>
        findInputByLabel("<span>Quantity")
      );

      if(state.sizeType == "$")
          setInput(qty, state.positionSize);
      if(state.sizeType == "%")
          setInput(qty, state.positionSize / 100  * 0.98 * leverage * balance);

      const toggle = await waitFor(() =>
        [...document.querySelectorAll("input")]
          .find(l => l.parentElement.parentElement.innerText.includes("TP/SL"))
      );
      if (state.tpEnabled || state.slEnabled) {
        if (!toggle.checked) 
          {
            click(toggle);
            await new Promise(r => setTimeout(r, 50));
          }
          else
          {
            click(toggle);
            await new Promise(r => setTimeout(r, 50));
            click(toggle);
            await new Promise(r => setTimeout(r, 50));
          }

        const dropdowns = [...document.querySelectorAll('div[class*="ant-dropdown-trigger"')]
                  .filter(li => li.textContent.includes('Price') || li.textContent.includes('ROE') || li.textContent.includes('PNL'));
          
          try {
              dropdowns[0].dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
              dropdowns[1].dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
              await new Promise(r => setTimeout(r, 200));
              dropdowns[0].dispatchEvent(new MouseEvent('mouseout', { bubbles: true }));
              dropdowns[1].dispatchEvent(new MouseEvent('mouseout', { bubbles: true }));
          } catch (error) {
        
        }
      }
      else
      {
        if (toggle.checked) 
          {
            click(toggle);
          }
      }

      if (state.tpEnabled) {
        
        if(state.tpType == "%")
        {
          // var ttp = (parseFloat(cprice) + (direction == "long" ? +1 : -1) * parseFloat(state.tpValue) / 100 * parseFloat(cprice)).toString();
          var ttp = parseFloat(state.tpValue);

          const roes = [...document.querySelectorAll('li')]
              .filter(li => li.textContent.includes('ROE'));
          var roe = roes[0];
          roe.click();
          var tp = await waitFor(() =>
            document.querySelectorAll('input[class="ant-input"]')[0]
          );
          setInput(tp, ttp);
          changeTag(tp, "inputa");
          await new Promise(r => setTimeout(r, 50));
          var tp = await waitFor(() =>
            document.querySelectorAll('inputa[class="ant-input"]')[0]
          );
          changeTag(tp, "input");
        }
        if(state.tpType == "$")
        {
          const prices = [...document.querySelectorAll('li')]
          .filter(li => li.textContent.includes('Price'));
          var price = prices[0];
          price.click();
        }
      }

      if (state.slEnabled) {

        if(state.slType == "%")
        {
          // var ssl = (parseFloat(cprice) + (direction == "short" ? +1 : -1) * parseFloat(state.slValue) / 100 * parseFloat(cprice)).toString();
          var ssl = parseFloat(state.slValue);
          const roes = [...document.querySelectorAll('li')]
              .filter(li => li.textContent.includes('ROE'));
          var roe = roes[1];
          roe.click();
          var sl = await waitFor(() =>
            document.querySelectorAll('input[class="ant-input"]')[1]
          );
          setInput(sl, ssl);
          changeTag(sl, "inputa");
          await new Promise(r => setTimeout(r, 50));
          var sl = await waitFor(() =>
            document.querySelectorAll('inputa[class="ant-input"]')[0]
          );
          changeTag(sl, "input");
        }
        if(state.slType == "$")
        {
          const prices = [...document.querySelectorAll('li')]
              .filter(li => li.textContent.includes('Price'));
          var price = prices[1];
          price.click();
        }
      }
    }
    catch(aa)
    {
      

    }
    
  }
  
  async function placeOrder(direction) {
    try
    {
        const start = performance.now();

      console.log("started");
      const state = await loadState();

      const cprice = document.querySelector('span[class*="PriceText_text"]').innerText.replace(",", "").substring(1);

      if (state.tpEnabled) {
        if(state.tpType == "$")
        {
          var ttp = (parseFloat(cprice) + (direction == "long" ? +1 : -1) * parseFloat(state.tpValue)).toString();
          const tp = await waitFor(() =>
            findInputByPlaceholder("Trigger Price")
          );
          setInput(tp, ttp);
        }
      }

      if (state.slEnabled) {
        if(state.slType == "$")
        {
          var ssl = (parseFloat(cprice) + (direction == "short" ? +1 : -1) * parseFloat(state.slValue)).toString();
          const sl = await waitFor(() =>
            findInputByPlaceholderLast("Trigger Price")
          );
          setInput(sl, ssl);
        }
      }

      const btn = await waitFor(() =>
        findButton(direction === "long" ? "Open Long" : "Open Short")
      );
      click(btn);

      setTimeout(async () => {
        click(await waitFor(() => findButton("Confirm")));
      }, 50);
      const end = performance.now();
      console.log(`Time: ${(end - start).toFixed(2)} ms`);
      await new Promise(r => setTimeout(r, 500));
      fill();
    }
    catch(bb)
    {      

    }
    
  }

  async function reversePosition() {
    click(await waitFor(() => findButton("Reverse")));
    setTimeout(async () => {
      click(await waitFor(() => findButton("Confirm")));
    }, 200);
  }

  async function flashClose() {
    click(await waitFor(() => findButton("Flash")));
  }

  /**********************
   * HOTKEYS
   **********************/
  document.addEventListener("keydown", e => {
    if (!e.ctrlKey) return;

    if (e.code === "ArrowUp") placeOrder("long");
    if (e.code === "ArrowDown") placeOrder("short");
    if (e.code === "ArrowLeft") reversePosition();
    if (e.code === "ArrowRight") flashClose();
  });

})();
